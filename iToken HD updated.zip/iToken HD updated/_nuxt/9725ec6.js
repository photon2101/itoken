(window.webpackJsonp = window.webpackJsonp || []).push([
    [16],
    [function(n, t, e) {
        "use strict";
        e.d(t, "k", (function() {
            return v
        })), e.d(t, "m", (function() {
            return y
        })), e.d(t, "l", (function() {
            return k
        })), e.d(t, "e", (function() {
            return A
        })), e.d(t, "b", (function() {
            return C
        })), e.d(t, "s", (function() {
            return j
        })), e.d(t, "g", (function() {
            return D
        })), e.d(t, "h", (function() {
            return S
        })), e.d(t, "d", (function() {
            return O
        })), e.d(t, "r", (function() {
            return M
        })), e.d(t, "j", (function() {
            return T
        })), e.d(t, "t", (function() {
            return P
        })), e.d(t, "o", (function() {
            return E
        })), e.d(t, "q", (function() {
            return L
        })), e.d(t, "f", (function() {
            return N
        })), e.d(t, "c", (function() {
            return B
        })), e.d(t, "i", (function() {
            return R
        })), e.d(t, "p", (function() {
            return z
        })), e.d(t, "a", (function() {
            return Y
        })), e.d(t, "v", (function() {
            return Z
        })), e.d(t, "n", (function() {
            return V
        })), e.d(t, "u", (function() {
            return K
        }));
        e(19), e(69), e(33), e(34);
        var o = e(11),
            r = e(2),
            c = e(7),
            l = e(22),
            d = (e(31), e(24), e(297), e(20), e(58), e(71), e(16), e(72), e(73), e(68), e(25), e(185), e(186), e(130), e(100), e(101), e(301), e(70), e(62), e(1)),
            f = e(35);

        function h(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }

        function m(n) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? h(Object(source), !0).forEach((function(t) {
                    Object(c.a)(n, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : h(Object(source)).forEach((function(t) {
                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return n
        }

        function x(n, t) {
            var e = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
            if (!e) {
                if (Array.isArray(n) || (e = function(n, t) {
                        if (!n) return;
                        if ("string" == typeof n) return w(n, t);
                        var e = Object.prototype.toString.call(n).slice(8, -1);
                        "Object" === e && n.constructor && (e = n.constructor.name);
                        if ("Map" === e || "Set" === e) return Array.from(n);
                        if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return w(n, t)
                    }(n)) || t && n && "number" == typeof n.length) {
                    e && (n = e);
                    var i = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return i >= n.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: n[i++]
                            }
                        },
                        e: function(n) {
                            throw n
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0,
                l = !1;
            return {
                s: function() {
                    e = e.call(n)
                },
                n: function() {
                    var n = e.next();
                    return c = n.done, n
                },
                e: function(n) {
                    l = !0, r = n
                },
                f: function() {
                    try {
                        c || null == e.return || e.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function w(n, t) {
            (null == t || t > n.length) && (t = n.length);
            for (var i = 0, e = new Array(t); i < t; i++) e[i] = n[i];
            return e
        }

        function v(n) {
            d.a.config.errorHandler && d.a.config.errorHandler(n)
        }

        function y(n) {
            return n.then((function(n) {
                return n.default || n
            }))
        }

        function k(n) {
            return n.$options && "function" == typeof n.$options.fetch && !n.$options.fetch.length
        }

        function A(n) {
            var t, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                o = x(n.$children || []);
            try {
                for (o.s(); !(t = o.n()).done;) {
                    var r = t.value;
                    r.$fetch && e.push(r), r.$children && A(r, e)
                }
            } catch (n) {
                o.e(n)
            } finally {
                o.f()
            }
            return e
        }

        function C(n, t) {
            if (t || !n.options.__hasNuxtData) {
                var e = n.options._originDataFn || n.options.data || function() {
                    return {}
                };
                n.options._originDataFn = e, n.options.data = function() {
                    var data = e.call(this, this);
                    return this.$ssrContext && (t = this.$ssrContext.asyncData[n.cid]), m(m({}, data), t)
                }, n.options.__hasNuxtData = !0, n._Ctor && n._Ctor.options && (n._Ctor.options.data = n.options.data)
            }
        }

        function j(n) {
            return n.options && n._Ctor === n || (n.options ? (n._Ctor = n, n.extendOptions = n.options) : (n = d.a.extend(n))._Ctor = n, !n.options.name && n.options.__file && (n.options.name = n.options.__file)), n
        }

        function D(n) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "components";
            return Array.prototype.concat.apply([], n.matched.map((function(n, o) {
                return Object.keys(n[e]).map((function(r) {
                    return t && t.push(o), n[e][r]
                }))
            })))
        }

        function S(n) {
            return D(n, arguments.length > 1 && void 0 !== arguments[1] && arguments[1], "instances")
        }

        function O(n, t) {
            return Array.prototype.concat.apply([], n.matched.map((function(n, e) {
                return Object.keys(n.components).reduce((function(o, r) {
                    return n.components[r] ? o.push(t(n.components[r], n.instances[r], n, r, e)) : delete n.components[r], o
                }), [])
            })))
        }

        function M(n, t) {
            return Promise.all(O(n, function() {
                var n = Object(r.a)(regeneratorRuntime.mark((function n(e, o, r, c) {
                    var l, d;
                    return regeneratorRuntime.wrap((function(n) {
                        for (;;) switch (n.prev = n.next) {
                            case 0:
                                if ("function" != typeof e || e.options) {
                                    n.next = 11;
                                    break
                                }
                                return n.prev = 1, n.next = 4, e();
                            case 4:
                                e = n.sent, n.next = 11;
                                break;
                            case 7:
                                throw n.prev = 7, n.t0 = n.catch(1), n.t0 && "ChunkLoadError" === n.t0.name && "undefined" != typeof window && window.sessionStorage && (l = Date.now(), (!(d = parseInt(window.sessionStorage.getItem("nuxt-reload"))) || d + 6e4 < l) && (window.sessionStorage.setItem("nuxt-reload", l), window.location.reload(!0))), n.t0;
                            case 11:
                                return r.components[c] = e = j(e), n.abrupt("return", "function" == typeof t ? t(e, o, r, c) : e);
                            case 13:
                            case "end":
                                return n.stop()
                        }
                    }), n, null, [
                        [1, 7]
                    ])
                })));
                return function(t, e, o, r) {
                    return n.apply(this, arguments)
                }
            }()))
        }

        function T(n) {
            return I.apply(this, arguments)
        }

        function I() {
            return (I = Object(r.a)(regeneratorRuntime.mark((function n(t) {
                return regeneratorRuntime.wrap((function(n) {
                    for (;;) switch (n.prev = n.next) {
                        case 0:
                            if (t) {
                                n.next = 2;
                                break
                            }
                            return n.abrupt("return");
                        case 2:
                            return n.next = 4, M(t);
                        case 4:
                            return n.abrupt("return", m(m({}, t), {}, {
                                meta: D(t).map((function(n, e) {
                                    return m(m({}, n.options.meta), (t.matched[e] || {}).meta)
                                }))
                            }));
                        case 5:
                        case "end":
                            return n.stop()
                    }
                }), n)
            })))).apply(this, arguments)
        }

        function P(n, t) {
            return _.apply(this, arguments)
        }

        function _() {
            return (_ = Object(r.a)(regeneratorRuntime.mark((function n(t, e) {
                var r, c, d, h;
                return regeneratorRuntime.wrap((function(n) {
                    for (;;) switch (n.prev = n.next) {
                        case 0:
                            return t.context || (t.context = {
                                isStatic: !1,
                                isDev: !1,
                                isHMR: !1,
                                app: t,
                                store: t.store,
                                payload: e.payload,
                                error: e.error,
                                base: t.router.options.base,
                                env: {
                                    HOST_URL: "http://127.0.0.1:8080"
                                }
                            }, e.req && (t.context.req = e.req), e.res && (t.context.res = e.res), e.ssrContext && (t.context.ssrContext = e.ssrContext), t.context.redirect = function(n, path, e) {
                                if (n) {
                                    t.context._redirected = !0;
                                    var r = Object(o.a)(path);
                                    if ("number" == typeof n || "undefined" !== r && "object" !== r || (e = path || {}, path = n, r = Object(o.a)(path), n = 302), "object" === r && (path = t.router.resolve(path).route.fullPath), !/(^[.]{1,2}\/)|(^\/(?!\/))/.test(path)) throw path = Object(f.d)(path, e), window.location.assign(path), new Error("ERR_REDIRECT");
                                    t.context.next({
                                        path: path,
                                        query: e,
                                        status: n
                                    })
                                }
                            }, t.context.nuxtState = window.__NUXT__), n.next = 3, Promise.all([T(e.route), T(e.from)]);
                        case 3:
                            r = n.sent, c = Object(l.a)(r, 2), d = c[0], h = c[1], e.route && (t.context.route = d), e.from && (t.context.from = h), e.error && (t.context.error = e.error), t.context.next = e.next, t.context._redirected = !1, t.context._errored = !1, t.context.isHMR = !1, t.context.params = t.context.route.params || {}, t.context.query = t.context.route.query || {};
                        case 16:
                        case "end":
                            return n.stop()
                    }
                }), n)
            })))).apply(this, arguments)
        }

        function E(n, t, e) {
            return !n.length || t._redirected || t._errored || e && e.aborted ? Promise.resolve() : L(n[0], t).then((function() {
                return E(n.slice(1), t, e)
            }))
        }

        function L(n, t) {
            var e;
            return (e = 2 === n.length ? new Promise((function(e) {
                n(t, (function(n, data) {
                    n && t.error(n), e(data = data || {})
                }))
            })) : n(t)) && e instanceof Promise && "function" == typeof e.then ? e : Promise.resolve(e)
        }

        function N(base, n) {
            if ("hash" === n) return window.location.hash.replace(/^#\//, "");
            base = decodeURI(base).slice(0, -1);
            var path = decodeURI(window.location.pathname);
            base && path.startsWith(base) && (path = path.slice(base.length));
            var t = (path || "/") + window.location.search + window.location.hash;
            return Object(f.c)(t)
        }

        function B(n, t) {
            return function(n, t) {
                for (var e = new Array(n.length), i = 0; i < n.length; i++) "object" === Object(o.a)(n[i]) && (e[i] = new RegExp("^(?:" + n[i].pattern + ")$", Q(t)));
                return function(t, o) {
                    for (var path = "", data = t || {}, r = (o || {}).pretty ? F : encodeURIComponent, c = 0; c < n.length; c++) {
                        var l = n[c];
                        if ("string" != typeof l) {
                            var d = data[l.name || "pathMatch"],
                                f = void 0;
                            if (null == d) {
                                if (l.optional) {
                                    l.partial && (path += l.prefix);
                                    continue
                                }
                                throw new TypeError('Expected "' + l.name + '" to be defined')
                            }
                            if (Array.isArray(d)) {
                                if (!l.repeat) throw new TypeError('Expected "' + l.name + '" to not repeat, but received `' + JSON.stringify(d) + "`");
                                if (0 === d.length) {
                                    if (l.optional) continue;
                                    throw new TypeError('Expected "' + l.name + '" to not be empty')
                                }
                                for (var h = 0; h < d.length; h++) {
                                    if (f = r(d[h]), !e[c].test(f)) throw new TypeError('Expected all "' + l.name + '" to match "' + l.pattern + '", but received `' + JSON.stringify(f) + "`");
                                    path += (0 === h ? l.prefix : l.delimiter) + f
                                }
                            } else {
                                if (f = l.asterisk ? U(d) : r(d), !e[c].test(f)) throw new TypeError('Expected "' + l.name + '" to match "' + l.pattern + '", but received "' + f + '"');
                                path += l.prefix + f
                            }
                        } else path += l
                    }
                    return path
                }
            }(function(n, t) {
                var e, o = [],
                    r = 0,
                    c = 0,
                    path = "",
                    l = t && t.delimiter || "/";
                for (; null != (e = H.exec(n));) {
                    var d = e[0],
                        f = e[1],
                        h = e.index;
                    if (path += n.slice(c, h), c = h + d.length, f) path += f[1];
                    else {
                        var m = n[c],
                            x = e[2],
                            w = e[3],
                            v = e[4],
                            y = e[5],
                            k = e[6],
                            A = e[7];
                        path && (o.push(path), path = "");
                        var C = null != x && null != m && m !== x,
                            j = "+" === k || "*" === k,
                            D = "?" === k || "*" === k,
                            S = e[2] || l,
                            pattern = v || y;
                        o.push({
                            name: w || r++,
                            prefix: x || "",
                            delimiter: S,
                            optional: D,
                            repeat: j,
                            partial: C,
                            asterisk: Boolean(A),
                            pattern: pattern ? G(pattern) : A ? ".*" : "[^" + W(S) + "]+?"
                        })
                    }
                }
                c < n.length && (path += n.substr(c));
                path && o.push(path);
                return o
            }(n, t), t)
        }

        function R(n, t) {
            var e = {},
                o = m(m({}, n), t);
            for (var r in o) String(n[r]) !== String(t[r]) && (e[r] = !0);
            return e
        }

        function z(n) {
            var t;
            if (n.message || "string" == typeof n) t = n.message || n;
            else try {
                t = JSON.stringify(n, null, 2)
            } catch (e) {
                t = "[".concat(n.constructor.name, "]")
            }
            return m(m({}, n), {}, {
                message: t,
                statusCode: n.statusCode || n.status || n.response && n.response.status || 500
            })
        }
        window.onNuxtReadyCbs = [], window.onNuxtReady = function(n) {
            window.onNuxtReadyCbs.push(n)
        };
        var H = new RegExp(["(\\\\.)", "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"].join("|"), "g");

        function F(n, t) {
            var e = t ? /[?#]/g : /[/?#]/g;
            return encodeURI(n).replace(e, (function(n) {
                return "%" + n.charCodeAt(0).toString(16).toUpperCase()
            }))
        }

        function U(n) {
            return F(n, !0)
        }

        function W(n) {
            return n.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1")
        }

        function G(n) {
            return n.replace(/([=!:$/()])/g, "\\$1")
        }

        function Q(n) {
            return n && n.sensitive ? "" : "i"
        }

        function Y(n, t, e) {
            n.$options[t] || (n.$options[t] = []), n.$options[t].includes(e) || n.$options[t].push(e)
        }
        var Z = f.b,
            V = (f.e, f.a);

        function K(n) {
            try {
                window.history.scrollRestoration = n
            } catch (n) {}
        }
    }, , , , , , , , , function(n) {
        n.exports = JSON.parse('{"source":"abcedfghigklmnopqrstuvwxyzABCEDFGHIGKLMNOPQRSTUVWXYZ0123456789.,\'@#：。","chinaStrict":"由于中国区App Store政策限制，下载iToken需要使用海外账户登录海外App Store 下载","freeAccount":"以下是免费的海外App Store账号供您使用","hkAccount":"香港账户：","usAccount":"美国账户：","pwd":"密码：","jingICP":"京ICP备18042578号-2","copyRightDes":"京公网安备 11010802028094号 北京亿源通科技有限公司","copyRight":"Copyright © 2018-{} iToken","DappTitle1":"Fishing Master","DappTitle2":"PRA CandyBox","DappTitle3":"Newdex","DappTitle4":"CPU Emergency","DappTitle5":"Xpet","DappTitle6":"iGuess","DappTitle7":"EOSPark","dapp":"DApp","t1":"活动规则","t2":"2月11日23:59，iToken进行快照， 持有量在500枚以上的用户即可分别参与瓜分20万枚TRX，及对应的BTT","t3":"发放时间","t4":"2月18日前","t5":"参与方式","t6":"立即下载安装iToken并存入500枚以上TRX","t7":"下载iToken","t8":"特别说明","t9":"1. 每个设备ID有且仅有一次空投机会","t10":"2. 最终BTT数量按Tron及BitTorrent规定空投比例执行","t11":"3. 活动最终解释权归属iToken所有","t12":"活动咨询请添加官方助手微信iToken君","t13":"微信ID：huobiwallet","t14":"iToken | TRX空投","hbChina1":"iToken中国","dangerousNotice":"安全提示：提供的Apple ID 仅用于App StoreiToken下载，下载完成后请切回用户个人账户，切记不要使用iCloud等其他平台，更不要把重要信息例如私钥、助记词等存储至iCloud"}')
    }, , , , , , , , function(n, t, e) {
        "use strict";
        e(16), e(19), e(24), e(33), e(34);
        var o = e(7);

        function r(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }
        t.a = {
            data: function() {
                return {}
            },
            created: function() {},
            methods: {
                reqBuriedData: function(n) {
                    var param = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    sa.track(n, function(n) {
                        for (var i = 1; i < arguments.length; i++) {
                            var source = null != arguments[i] ? arguments[i] : {};
                            i % 2 ? r(Object(source), !0).forEach((function(t) {
                                Object(o.a)(n, t, source[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : r(Object(source)).forEach((function(t) {
                                Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                            }))
                        }
                        return n
                    }({
                        Page_name: this.$getCurrPageName(),
                        WhetherToClick: !0,
                        $browser: this.$browser,
                        $browser_version: this.$browserVer
                    }, param))
                }
            }
        }
    }, , , , , , , , , , , , , , , , , , , function(n, t, e) {
        "use strict";
        e.d(t, "b", (function() {
            return Fn
        })), e.d(t, "a", (function() {
            return R
        }));
        e(16), e(19), e(24), e(33), e(34);
        var o = e(2),
            r = e(7),
            c = (e(31), e(58), e(71), e(20), e(25), e(1)),
            l = e(89),
            d = e(223),
            f = e(142),
            h = e.n(f),
            m = e(76),
            x = e.n(m),
            w = e(143),
            v = e(35),
            y = e(0);
        e(188);
        "scrollRestoration" in window.history && (Object(y.u)("manual"), window.addEventListener("beforeunload", (function() {
            Object(y.u)("auto")
        })), window.addEventListener("load", (function() {
            Object(y.u)("manual")
        })));

        function k(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }

        function A(n) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? k(Object(source), !0).forEach((function(t) {
                    Object(r.a)(n, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : k(Object(source)).forEach((function(t) {
                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return n
        }
        var C = function() {};
        c.a.use(w.a);
        var j = {
            mode: "history",
            base: "/",
            linkActiveClass: "nuxt-link-active",
            linkExactActiveClass: "nuxt-link-exact-active",
            scrollBehavior: function(n, t, e) {
                var o = !1,
                    r = n !== t;
                e ? o = e : r && function(n) {
                    var t = Object(y.g)(n);
                    if (1 === t.length) {
                        var e = t[0].options;
                        return !1 !== (void 0 === e ? {} : e).scrollToTop
                    }
                    return t.some((function(n) {
                        var t = n.options;
                        return t && t.scrollToTop
                    }))
                }(n) && (o = {
                    x: 0,
                    y: 0
                });
                var c = window.$nuxt;
                return (!r || n.path === t.path && n.hash !== t.hash) && c.$nextTick((function() {
                    return c.$emit("triggerScroll")
                })), new Promise((function(t) {
                    c.$once("triggerScroll", (function() {
                        if (n.hash) {
                            var e = n.hash;
                            void 0 !== window.CSS && void 0 !== window.CSS.escape && (e = "#" + window.CSS.escape(e.substr(1)));
                            try {
                                var r = document.querySelector(e);
                                if (r) {
                                    var c;
                                    o = {
                                        selector: e
                                    };
                                    var l = Number(null === (c = getComputedStyle(r)["scroll-margin-top"]) || void 0 === c ? void 0 : c.replace("px", ""));
                                    l && (o.offset = {
                                        y: l
                                    })
                                }
                            } catch (n) {
                                console.warn("Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).")
                            }
                        }
                        t(o)
                    }))
                }))
            },
            routes: [{
                path: "/about",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(7), e.e(51)]).then(e.bind(null, 1110)))
                },
                name: "about"
            }, {
                path: "/bip39helper",
                component: function() {
                    return Object(y.m)(e.e(52).then(e.bind(null, 1111)))
                },
                name: "bip39helper"
            }, {
                path: "/blog",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(8), e.e(53)]).then(e.bind(null, 1112)))
                },
                name: "blog"
            }, {
                path: "/buyBTC",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(4), e.e(54)]).then(e.bind(null, 1113)))
                },
                name: "buyBTC"
            }, {
                path: "/dapp",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(9), e.e(56)]).then(e.bind(null, 1114)))
                },
                name: "dapp"
            }, {
                path: "/download",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(3), e.e(57)]).then(e.bind(null, 1115)))
                },
                name: "download"
            }, {
                path: "/install",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(11), e.e(59)]).then(e.bind(null, 1116)))
                },
                name: "install"
            }, {
                path: "/ios-install",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(12), e.e(60)]).then(e.bind(null, 1117)))
                },
                name: "ios-install"
            }, {
                path: "/join",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(13), e.e(61)]).then(e.bind(null, 1118)))
                },
                name: "join"
            }, {
                path: "/mdxActivity",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(14), e.e(62)]).then(e.bind(null, 1119)))
                },
                name: "mdxActivity"
            }, {
                path: "/staking",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(6), e.e(63)]).then(e.bind(null, 1120)))
                },
                name: "staking"
            }, {
                path: "/stakingDetail",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(15), e.e(64)]).then(e.bind(null, 1121)))
                },
                name: "stakingDetail"
            }, {
                path: "/channels/0330310001",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(3), e.e(55)]).then(e.bind(null, 1122)))
                },
                name: "channels-0330310001"
            }, {
                path: "/",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(10), e.e(58)]).then(e.bind(null, 1123)))
                },
                name: "index"
            }, {
                path: "/:lang",
                component: function() {
                    return Object(y.m)(e.e(10).then(e.bind(null, 1074)))
                },
                name: "lang"
            }, {
                path: "/:lang/about",
                component: function() {
                    return Object(y.m)(e.e(7).then(e.bind(null, 1076)))
                },
                name: "lang-about"
            }, {
                path: "/:lang/activelandpage",
                component: function() {
                    return Object(y.m)(e.e(18).then(e.bind(null, 1084)))
                },
                name: "lang-activelandpage"
            }, {
                path: "/:lang/bip39helper",
                component: function() {
                    return Object(y.m)(e.e(19).then(e.bind(null, 845)))
                },
                name: "lang-bip39helper"
            }, {
                path: "/:lang/blog",
                component: function() {
                    return Object(y.m)(e.e(8).then(e.bind(null, 1077)))
                },
                name: "lang-blog"
            }, {
                path: "/:lang/buyBTC",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(4), e.e(20)]).then(e.bind(null, 846)))
                },
                name: "lang-buyBTC"
            }, {
                path: "/:lang/cloud-wallet",
                component: function() {
                    return Object(y.m)(e.e(22).then(e.bind(null, 1086)))
                },
                name: "lang-cloud-wallet"
            }, {
                path: "/:lang/dapp",
                component: function() {
                    return Object(y.m)(e.e(9).then(e.bind(null, 1078)))
                },
                name: "lang-dapp"
            }, {
                path: "/:lang/download",
                component: function() {
                    return Object(y.m)(e.e(3).then(e.bind(null, 738)))
                },
                name: "lang-download"
            }, {
                path: "/:lang/h5",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(5), e.e(31)]).then(e.bind(null, 1124)))
                },
                name: "lang-h5"
            }, {
                path: "/:lang/install",
                component: function() {
                    return Object(y.m)(e.e(11).then(e.bind(null, 1075)))
                },
                name: "lang-install"
            }, {
                path: "/:lang/ios-install",
                component: function() {
                    return Object(y.m)(e.e(12).then(e.bind(null, 1079)))
                },
                name: "lang-ios-install"
            }, {
                path: "/:lang/join",
                component: function() {
                    return Object(y.m)(e.e(13).then(e.bind(null, 1080)))
                },
                name: "lang-join"
            }, {
                path: "/:lang/landing-bid",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(2), e.e(44)]).then(e.bind(null, 1087)))
                },
                name: "lang-landing-bid"
            }, {
                path: "/:lang/landing-blind",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(2), e.e(45)]).then(e.bind(null, 1088)))
                },
                name: "lang-landing-blind"
            }, {
                path: "/:lang/landing-depth",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(2), e.e(46)]).then(e.bind(null, 1089)))
                },
                name: "lang-landing-depth"
            }, {
                path: "/:lang/landing-iBox",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(2), e.e(47)]).then(e.bind(null, 1090)))
                },
                name: "lang-landing-iBox"
            }, {
                path: "/:lang/landing-integral",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(2), e.e(48)]).then(e.bind(null, 1091)))
                },
                name: "lang-landing-integral"
            }, {
                path: "/:lang/mdxActivity",
                component: function() {
                    return Object(y.m)(e.e(14).then(e.bind(null, 1081)))
                },
                name: "lang-mdxActivity"
            }, {
                path: "/:lang/mindex",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(5), e.e(49)]).then(e.bind(null, 844)))
                },
                name: "lang-mindex"
            }, {
                path: "/:lang/staking",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(6), e.e(50)]).then(e.bind(null, 847)))
                },
                name: "lang-staking"
            }, {
                path: "/:lang/stakingDetail",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(15)]).then(e.bind(null, 1082)))
                },
                name: "lang-stakingDetail"
            }, {
                path: "/:lang/channels/0330310001",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(3), e.e(21)]).then(e.bind(null, 848)))
                },
                name: "lang-channels-0330310001"
            }, {
                path: "/:lang/h5/about",
                component: function() {
                    return Object(y.m)(e.e(23).then(e.bind(null, 1092)))
                },
                name: "lang-h5-about"
            }, {
                path: "/:lang/h5/activelandpage",
                component: function() {
                    return Object(y.m)(e.e(24).then(e.bind(null, 1083)))
                },
                name: "lang-h5-activelandpage"
            }, {
                path: "/:lang/h5/bip39helper",
                component: function() {
                    return Object(y.m)(e.e(25).then(e.bind(null, 1093)))
                },
                name: "lang-h5-bip39helper"
            }, {
                path: "/:lang/h5/blog",
                component: function() {
                    return Object(y.m)(e.e(26).then(e.bind(null, 1094)))
                },
                name: "lang-h5-blog"
            }, {
                path: "/:lang/h5/buyBTC",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(4), e.e(27)]).then(e.bind(null, 1095)))
                },
                name: "lang-h5-buyBTC"
            }, {
                path: "/:lang/h5/cloud-wallet",
                component: function() {
                    return Object(y.m)(e.e(28).then(e.bind(null, 1096)))
                },
                name: "lang-h5-cloud-wallet"
            }, {
                path: "/:lang/h5/dapp",
                component: function() {
                    return Object(y.m)(e.e(29).then(e.bind(null, 1097)))
                },
                name: "lang-h5-dapp"
            }, {
                path: "/:lang/h5/download",
                component: function() {
                    return Object(y.m)(e.e(30).then(e.bind(null, 1098)))
                },
                name: "lang-h5-download"
            }, {
                path: "/:lang/h5/install",
                component: function() {
                    return Object(y.m)(e.e(32).then(e.bind(null, 1085)))
                },
                name: "lang-h5-install"
            }, {
                path: "/:lang/h5/ios-install",
                component: function() {
                    return Object(y.m)(e.e(33).then(e.bind(null, 1099)))
                },
                name: "lang-h5-ios-install"
            }, {
                path: "/:lang/h5/join",
                component: function() {
                    return Object(y.m)(e.e(34).then(e.bind(null, 1100)))
                },
                name: "lang-h5-join"
            }, {
                path: "/:lang/h5/landing-bid",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(1), e.e(35)]).then(e.bind(null, 1101)))
                },
                name: "lang-h5-landing-bid"
            }, {
                path: "/:lang/h5/landing-blind",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(1), e.e(36)]).then(e.bind(null, 1102)))
                },
                name: "lang-h5-landing-blind"
            }, {
                path: "/:lang/h5/landing-depth",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(1), e.e(37)]).then(e.bind(null, 1103)))
                },
                name: "lang-h5-landing-depth"
            }, {
                path: "/:lang/h5/landing-iBox",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(1), e.e(38)]).then(e.bind(null, 1104)))
                },
                name: "lang-h5-landing-iBox"
            }, {
                path: "/:lang/h5/landing-integral",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(1), e.e(39)]).then(e.bind(null, 1105)))
                },
                name: "lang-h5-landing-integral"
            }, {
                path: "/:lang/h5/mdxActivity",
                component: function() {
                    return Object(y.m)(e.e(40).then(e.bind(null, 1106)))
                },
                name: "lang-h5-mdxActivity"
            }, {
                path: "/:lang/h5/mindex",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(5), e.e(41)]).then(e.bind(null, 1107)))
                },
                name: "lang-h5-mindex"
            }, {
                path: "/:lang/h5/staking",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(6), e.e(42)]).then(e.bind(null, 1108)))
                },
                name: "lang-h5-staking"
            }, {
                path: "/:lang/h5/stakingDetail",
                component: function() {
                    return Object(y.m)(Promise.all([e.e(0), e.e(43)]).then(e.bind(null, 1109)))
                },
                name: "lang-h5-stakingDetail"
            }],
            fallback: !1
        };

        function D(n, t) {
            var base = t._app && t._app.basePath || j.base,
                e = new w.a(A(A({}, j), {}, {
                    base: base
                })),
                o = e.push;
            e.push = function(n) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : C,
                    e = arguments.length > 2 ? arguments[2] : void 0;
                return o.call(this, n, t, e)
            };
            var r = e.resolve.bind(e);
            return e.resolve = function(n, t, e) {
                return "string" == typeof n && (n = Object(v.c)(n)), r(n, t, e)
            }, e
        }
        var S = {
                name: "NuxtChild",
                functional: !0,
                props: {
                    nuxtChildKey: {
                        type: String,
                        default: ""
                    },
                    keepAlive: Boolean,
                    keepAliveProps: {
                        type: Object,
                        default: void 0
                    }
                },
                render: function(n, t) {
                    var e = t.parent,
                        data = t.data,
                        o = t.props,
                        r = e.$createElement;
                    data.nuxtChild = !0;
                    for (var c = e, l = e.$nuxt.nuxt.transitions, d = e.$nuxt.nuxt.defaultTransition, f = 0; e;) e.$vnode && e.$vnode.data.nuxtChild && f++, e = e.$parent;
                    data.nuxtChildDepth = f;
                    var h = l[f] || d,
                        m = {};
                    O.forEach((function(n) {
                        void 0 !== h[n] && (m[n] = h[n])
                    }));
                    var x = {};
                    M.forEach((function(n) {
                        "function" == typeof h[n] && (x[n] = h[n].bind(c))
                    }));
                    var w = x.beforeEnter;
                    if (x.beforeEnter = function(n) {
                            if (window.$nuxt.$nextTick((function() {
                                    window.$nuxt.$emit("triggerScroll")
                                })), w) return w.call(c, n)
                        }, !1 === h.css) {
                        var v = x.leave;
                        (!v || v.length < 2) && (x.leave = function(n, t) {
                            v && v.call(c, n), c.$nextTick(t)
                        })
                    }
                    var y = r("routerView", data);
                    return o.keepAlive && (y = r("keep-alive", {
                        props: o.keepAliveProps
                    }, [y])), r("transition", {
                        props: m,
                        on: x
                    }, [y])
                }
            },
            O = ["name", "mode", "appear", "css", "type", "duration", "enterClass", "leaveClass", "appearClass", "enterActiveClass", "enterActiveClass", "leaveActiveClass", "appearActiveClass", "enterToClass", "leaveToClass", "appearToClass"],
            M = ["beforeEnter", "enter", "afterEnter", "enterCancelled", "beforeLeave", "leave", "afterLeave", "leaveCancelled", "beforeAppear", "appear", "afterAppear", "appearCancelled"],
            T = e(23),
            I = (e(146), e(148)),
            P = e(150),
            _ = e(147),
            E = e(149),
            L = e(114),
            N = (e(37), {
                name: "not-found",
                head: function() {
                    return {
                        htmlAttrs: {
                            lang: this.$i18n.locale
                        },
                        link: Object(T.a)(L.a.link),
                        script: Object(T.a)(L.a.script)
                    }
                },
                data: function() {
                    return {
                        isM: !1
                    }
                },
                mounted: function() {
                    this.isM = this.$isM(), document.body.scrollTop = document.documentElement.scrollTop = 0
                },
                components: {
                    Footer_web: I.a,
                    Footer_h5: P.a,
                    HeaderBar_web: _.a,
                    HeaderBar_h5: E.a
                }
            }),
            B = (e(334), e(3)),
            R = Object(B.a)(N, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", [t("div", {
                    staticClass: "header_top"
                }), n._v(" "), n.isM ? t("HeaderBar_h5") : t("HeaderBar_web"), n._v(" "), t("div", {
                    staticClass: "not-found"
                }, [t("div", {
                    staticClass: "not-found-inner"
                }, [t("img", {
                    staticClass: "pissa",
                    attrs: {
                        src: e(308)
                    }
                }), n._v(" "), t("div", {
                    staticClass: "not-found-detail"
                }, [t("div", {
                    staticClass: "desc"
                }, [n._v("\n          " + n._s(n.$t("404")) + "\n        ")]), n._v(" "), t("div", {
                    staticClass: "nav"
                }, [n.isM ? t("router-link", {
                    staticClass: "btn",
                    attrs: {
                        to: "/h5"
                    }
                }, [n._v(n._s(n.$t("returnHome")))]) : t("router-link", {
                    staticClass: "btn",
                    attrs: {
                        to: "/"
                    }
                }, [n._v(n._s(n.$t("returnHome")))]), n._v(" "), t("span", {
                    staticClass: "or"
                }, [n._v(n._s(n.$t("or")))]), n._v(" "), t("a", {
                    staticClass: "btn",
                    attrs: {
                        href: "https://support.huobiwallet.io",
                        target: "_blank"
                    }
                }, [n._v(n._s(n.$t("findHelp")))])], 1)])])]), n._v(" "), n.isM ? t("Footer_h5") : t("Footer_web")], 1)
            }), [], !1, null, null, null).exports,
            z = e(22),
            H = (e(100), e(101), {
                name: "Nuxt",
                components: {
                    NuxtChild: S,
                    NuxtError: R
                },
                props: {
                    nuxtChildKey: {
                        type: String,
                        default: void 0
                    },
                    keepAlive: Boolean,
                    keepAliveProps: {
                        type: Object,
                        default: void 0
                    },
                    name: {
                        type: String,
                        default: "default"
                    }
                },
                errorCaptured: function(n) {
                    this.displayingNuxtError && (this.errorFromNuxtError = n, this.$forceUpdate())
                },
                computed: {
                    routerViewKey: function() {
                        if (void 0 !== this.nuxtChildKey || this.$route.matched.length > 1) return this.nuxtChildKey || Object(y.c)(this.$route.matched[0].path)(this.$route.params);
                        var n = Object(z.a)(this.$route.matched, 1)[0];
                        if (!n) return this.$route.path;
                        var t = n.components.default;
                        if (t && t.options) {
                            var e = t.options;
                            if (e.key) return "function" == typeof e.key ? e.key(this.$route) : e.key
                        }
                        return /\/$/.test(n.path) ? this.$route.path : this.$route.path.replace(/\/$/, "")
                    }
                },
                beforeCreate: function() {
                    c.a.util.defineReactive(this, "nuxt", this.$root.$options.nuxt)
                },
                render: function(n) {
                    var t = this;
                    return this.nuxt.err ? this.errorFromNuxtError ? (this.$nextTick((function() {
                        return t.errorFromNuxtError = !1
                    })), n("div", {}, [n("h2", "An error occurred while showing the error page"), n("p", "Unfortunately an error occurred and while showing the error page another error occurred"), n("p", "Error details: ".concat(this.errorFromNuxtError.toString())), n("nuxt-link", {
                        props: {
                            to: "/"
                        }
                    }, "Go back to home")])) : (this.displayingNuxtError = !0, this.$nextTick((function() {
                        return t.displayingNuxtError = !1
                    })), n(R, {
                        props: {
                            error: this.nuxt.err
                        }
                    })) : n("NuxtChild", {
                        key: this.routerViewKey,
                        props: this.$props
                    })
                }
            }),
            F = (e(72), e(73), e(68), e(69), {
                name: "NuxtLoading",
                data: function() {
                    return {
                        percent: 0,
                        show: !1,
                        canSucceed: !0,
                        reversed: !1,
                        skipTimerCount: 0,
                        rtl: !1,
                        throttle: 200,
                        duration: 5e3,
                        continuous: !1
                    }
                },
                computed: {
                    left: function() {
                        return !(!this.continuous && !this.rtl) && (this.rtl ? this.reversed ? "0px" : "auto" : this.reversed ? "auto" : "0px")
                    }
                },
                beforeDestroy: function() {
                    this.clear()
                },
                methods: {
                    clear: function() {
                        clearInterval(this._timer), clearTimeout(this._throttle), clearTimeout(this._hide), this._timer = null
                    },
                    start: function() {
                        var n = this;
                        return this.clear(), this.percent = 0, this.reversed = !1, this.skipTimerCount = 0, this.canSucceed = !0, this.throttle ? this._throttle = setTimeout((function() {
                            return n.startTimer()
                        }), this.throttle) : this.startTimer(), this
                    },
                    set: function(n) {
                        return this.show = !0, this.canSucceed = !0, this.percent = Math.min(100, Math.max(0, Math.floor(n))), this
                    },
                    get: function() {
                        return this.percent
                    },
                    increase: function(n) {
                        return this.percent = Math.min(100, Math.floor(this.percent + n)), this
                    },
                    decrease: function(n) {
                        return this.percent = Math.max(0, Math.floor(this.percent - n)), this
                    },
                    pause: function() {
                        return clearInterval(this._timer), this
                    },
                    resume: function() {
                        return this.startTimer(), this
                    },
                    finish: function() {
                        return this.percent = this.reversed ? 0 : 100, this.hide(), this
                    },
                    hide: function() {
                        var n = this;
                        return this.clear(), this._hide = setTimeout((function() {
                            n.show = !1, n.$nextTick((function() {
                                n.percent = 0, n.reversed = !1
                            }))
                        }), 500), this
                    },
                    fail: function(n) {
                        return this.canSucceed = !1, this
                    },
                    startTimer: function() {
                        var n = this;
                        this.show || (this.show = !0), void 0 === this._cut && (this._cut = 1e4 / Math.floor(this.duration)), this._timer = setInterval((function() {
                            n.skipTimerCount > 0 ? n.skipTimerCount-- : (n.reversed ? n.decrease(n._cut) : n.increase(n._cut), n.continuous && (n.percent >= 100 || n.percent <= 0) && (n.skipTimerCount = 1, n.reversed = !n.reversed))
                        }), 100)
                    }
                },
                render: function(n) {
                    var t = n(!1);
                    return this.show && (t = n("div", {
                        staticClass: "nuxt-progress",
                        class: {
                            "nuxt-progress-notransition": this.skipTimerCount > 0, "nuxt-progress-failed": !this.canSucceed
                        },
                        style: {
                            width: this.percent + "%",
                            left: this.left
                        }
                    })), t
                }
            }),
            U = (e(336), Object(B.a)(F, undefined, undefined, !1, null, null, null).exports),
            W = (e(338), e(340), [function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    staticClass: "container"
                }, [t("div", {
                    staticClass: "desc"
                }, [t("div", {
                    staticClass: "logo-wrapper"
                }, [t("img", {
                    staticClass: "logo",
                    attrs: {
                        src: e(342),
                        alt: "Warning"
                    }
                })]), n._v(" "), t("p", [n._v("\n                    無法向中國大陸用戶提供產品或服務，請立即停止使用。點擊 “我同意”\n                    即表示您確認並承諾，您不是中國大陸用戶或未在中國大陸使用本服務。\n                ")]), n._v(" "), t("p", [n._v('\n                    Mainland China users are not eligible to use the products or services offered by current\n                    platform. By clicking "I Agree” you represent and warrant that you are not a Mainland China\n                    user, nor accessing the platform from Mainland China.\n                ')])])])
            }]),
            G = {
                props: {
                    show: {
                        type: Boolean,
                        default: !1
                    },
                    portal: {
                        type: Array,
                        default: function() {
                            return []
                        }
                    }
                },
                methods: {
                    closePop: function() {
                        this.$emit("close"), this.$emit("update:show", !1)
                    }
                }
            },
            Q = (e(343), Object(B.a)(G, (function() {
                var n = this,
                    t = n._self._c;
                return n.show ? t("div", {
                    staticClass: "mainland-tip"
                }, [t("div", {
                    staticClass: "content"
                }, [n._m(0), n._v(" "), t("div", {
                    staticClass: "button-content"
                }, [t("span", {
                    staticClass: "button",
                    on: {
                        click: n.closePop
                    }
                }, [n._v(n._s(n.$t("iAgree")) + " ")])])])]) : n._e()
            }), W, !1, null, "2b8ce2b8", null).exports),
            Y = e(30),
            Z = e.n(Y),
            V = {
                components: {
                    MainlandTip: Q
                },
                data: function() {
                    return {
                        isShowMainland: !1,
                        portal: []
                    }
                },
                mounted: function() {
                    this.getUserIP()
                },
                methods: {
                    getIps: function() {
                        var n = this;
                        this.$axios.get("/dgg/system/ips").then((function(t) {
                            var data = t.data;
                            0 === data.code && ("CN" !== data.data.country && "zh" != n.$i18n.locale || n.getPortal())
                        })).catch((function(n) {
                            console.log("请求失败1")
                        }))
                    },
                    getPortal: function() {
                        var n = this;
                        this.$axios.get("/dgg/system/conf/portal").then((function(t) {
                            var data = t.data,
                                e = "zh" === n.$i18n.locale ? "ch" : "en";
                            n.portal = data.data[e], n.isShowMainland = !0
                        })).catch((function(n) {
                            console.log("请求失败1")
                        }))
                    },
                    getUserIP: function() {
                        var n = this;
                        return Object(o.a)(regeneratorRuntime.mark((function t() {
                            var e;
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.prev = 0, t.next = 3, Z.a.get("https://ipinfo.io?token=9d3ce775faf896");
                                    case 3:
                                        e = t.sent, "CN" === e.data.country && (n.isShowMainland = !0), t.next = 11;
                                        break;
                                    case 8:
                                        t.prev = 8, t.t0 = t.catch(0), console.error("Error is:", t.t0);
                                    case 11:
                                    case "end":
                                        return t.stop()
                                }
                            }), t, null, [
                                [0, 8]
                            ])
                        })))()
                    }
                }
            },
            K = (e(345), Object(B.a)(V, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    attrs: {
                        id: "app"
                    }
                }, [n._m(0), n._v(" "), t("nuxt"), n._v(" "), n.isShowMainland ? t("MainlandTip", {
                    attrs: {
                        show: n.isShowMainland,
                        portal: n.portal
                    },
                    on: {
                        "update:show": function(t) {
                            n.isShowMainland = t
                        }
                    }
                }) : n._e()], 1)
            }), [function() {
                var n = this._self._c;
                return n("div", {
                    staticStyle: {
                        position: "absolute",
                        left: "-1000px",
                        top: "-1000px",
                        overflow: "hidden",
                        "z-index": "1"
                    }
                }, [n("img", {
                    attrs: {
                        src: "/thumbnail.png",
                        alt: ""
                    }
                })])
            }], !1, null, null, null).exports);

        function $(n, t) {
            var e = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
            if (!e) {
                if (Array.isArray(n) || (e = function(n, t) {
                        if (!n) return;
                        if ("string" == typeof n) return J(n, t);
                        var e = Object.prototype.toString.call(n).slice(8, -1);
                        "Object" === e && n.constructor && (e = n.constructor.name);
                        if ("Map" === e || "Set" === e) return Array.from(n);
                        if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return J(n, t)
                    }(n)) || t && n && "number" == typeof n.length) {
                    e && (n = e);
                    var i = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return i >= n.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: n[i++]
                            }
                        },
                        e: function(n) {
                            throw n
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0,
                l = !1;
            return {
                s: function() {
                    e = e.call(n)
                },
                n: function() {
                    var n = e.next();
                    return c = n.done, n
                },
                e: function(n) {
                    l = !0, r = n
                },
                f: function() {
                    try {
                        c || null == e.return || e.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function J(n, t) {
            (null == t || t > n.length) && (t = n.length);
            for (var i = 0, e = new Array(t); i < t; i++) e[i] = n[i];
            return e
        }
        var X = {
                _default: Object(y.s)(K)
            },
            nn = {
                render: function(n, t) {
                    var e = n("NuxtLoading", {
                            ref: "loading"
                        }),
                        o = n(this.layout || "nuxt"),
                        r = n("div", {
                            domProps: {
                                id: "__layout"
                            },
                            key: this.layoutName
                        }, [o]),
                        c = n("transition", {
                            props: {
                                name: "layout",
                                mode: "out-in"
                            },
                            on: {
                                beforeEnter: function(n) {
                                    window.$nuxt.$nextTick((function() {
                                        window.$nuxt.$emit("triggerScroll")
                                    }))
                                }
                            }
                        }, [r]);
                    return n("div", {
                        domProps: {
                            id: "__nuxt"
                        }
                    }, [e, c])
                },
                data: function() {
                    return {
                        isOnline: !0,
                        layout: null,
                        layoutName: "",
                        nbFetching: 0
                    }
                },
                beforeCreate: function() {
                    c.a.util.defineReactive(this, "nuxt", this.$options.nuxt)
                },
                created: function() {
                    this.$root.$options.$nuxt = this, window.$nuxt = this, this.refreshOnlineStatus(), window.addEventListener("online", this.refreshOnlineStatus), window.addEventListener("offline", this.refreshOnlineStatus), this.error = this.nuxt.error, this.context = this.$options.context
                },
                mounted: function() {
                    var n = this;
                    return Object(o.a)(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    n.$loading = n.$refs.loading;
                                case 1:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                },
                watch: {
                    "nuxt.err": "errorChanged"
                },
                computed: {
                    isOffline: function() {
                        return !this.isOnline
                    },
                    isFetching: function() {
                        return this.nbFetching > 0
                    }
                },
                methods: {
                    refreshOnlineStatus: function() {
                        void 0 === window.navigator.onLine ? this.isOnline = !0 : this.isOnline = window.navigator.onLine
                    },
                    refresh: function() {
                        var n = this;
                        return Object(o.a)(regeneratorRuntime.mark((function t() {
                            var e, r;
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if ((e = Object(y.h)(n.$route)).length) {
                                            t.next = 3;
                                            break
                                        }
                                        return t.abrupt("return");
                                    case 3:
                                        return n.$loading.start(), r = e.map(function() {
                                            var t = Object(o.a)(regeneratorRuntime.mark((function t(e) {
                                                var p, o, r, component;
                                                return regeneratorRuntime.wrap((function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                        case 0:
                                                            return p = [], e.$options.fetch && e.$options.fetch.length && p.push(Object(y.q)(e.$options.fetch, n.context)), e.$options.asyncData && p.push(Object(y.q)(e.$options.asyncData, n.context).then((function(n) {
                                                                for (var t in n) c.a.set(e.$data, t, n[t])
                                                            }))), t.next = 5, Promise.all(p);
                                                        case 5:
                                                            p = [], e.$fetch && p.push(e.$fetch()), o = $(Object(y.e)(e.$vnode.componentInstance));
                                                            try {
                                                                for (o.s(); !(r = o.n()).done;) component = r.value, p.push(component.$fetch())
                                                            } catch (n) {
                                                                o.e(n)
                                                            } finally {
                                                                o.f()
                                                            }
                                                            return t.abrupt("return", Promise.all(p));
                                                        case 10:
                                                        case "end":
                                                            return t.stop()
                                                    }
                                                }), t)
                                            })));
                                            return function(n) {
                                                return t.apply(this, arguments)
                                            }
                                        }()), t.prev = 5, t.next = 8, Promise.all(r);
                                    case 8:
                                        t.next = 15;
                                        break;
                                    case 10:
                                        t.prev = 10, t.t0 = t.catch(5), n.$loading.fail(t.t0), Object(y.k)(t.t0), n.error(t.t0);
                                    case 15:
                                        n.$loading.finish();
                                    case 16:
                                    case "end":
                                        return t.stop()
                                }
                            }), t, null, [
                                [5, 10]
                            ])
                        })))()
                    },
                    errorChanged: function() {
                        if (this.nuxt.err) {
                            this.$loading && (this.$loading.fail && this.$loading.fail(this.nuxt.err), this.$loading.finish && this.$loading.finish());
                            var n = (R.options || R).layout;
                            "function" == typeof n && (n = n(this.context)), this.setLayout(n)
                        }
                    },
                    setLayout: function(n) {
                        return n && X["_" + n] || (n = "default"), this.layoutName = n, this.layout = X["_" + n], this.layout
                    },
                    loadLayout: function(n) {
                        return n && X["_" + n] || (n = "default"), Promise.resolve(X["_" + n])
                    }
                },
                components: {
                    NuxtLoading: U
                }
            };
        e(90), e(62);
        c.a.use(l.a);
        var tn = ["state", "getters", "actions", "mutations"],
            en = {};
        (en = function(n, t) {
            if ((n = n.default || n).commit) throw new Error("[nuxt] ".concat(t, " should export a method that returns a Vuex instance."));
            return "function" != typeof n && (n = Object.assign({}, n)), an(n, t)
        }(e(347), "store/index.js")).modules = en.modules || {},
            function(n, t) {
                n = n.default || n;
                var e = t.replace(/\.(js|mjs)$/, "").split("/"),
                    o = e[e.length - 1],
                    r = "store/".concat(t);
                if (n = "state" === o ? function(n, t) {
                        if ("function" != typeof n) {
                            console.warn("".concat(t, " should export a method that returns an object"));
                            var e = Object.assign({}, n);
                            return function() {
                                return e
                            }
                        }
                        return an(n, t)
                    }(n, r) : an(n, r), tn.includes(o)) {
                    var c = o;
                    sn(rn(en, e, {
                        isProperty: !0
                    }), n, c)
                } else {
                    "index" === o && (e.pop(), o = e[e.length - 1]);
                    for (var l = rn(en, e), d = 0, f = tn; d < f.length; d++) {
                        var h = f[d];
                        sn(l, n[h], h)
                    }!1 === n.namespaced && delete l.namespaced
                }
            }(e(348), "common.js");
        var on = en instanceof Function ? en : function() {
            return new l.a.Store(Object.assign({
                strict: !1
            }, en))
        };

        function an(n, t) {
            if (n.state && "function" != typeof n.state) {
                console.warn("'state' should be a method that returns an object in ".concat(t));
                var e = Object.assign({}, n.state);
                n = Object.assign({}, n, {
                    state: function() {
                        return e
                    }
                })
            }
            return n
        }

        function rn(n, t) {
            var e = (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}).isProperty,
                o = void 0 !== e && e;
            if (!t.length || o && 1 === t.length) return n;
            var r = t.shift();
            return n.modules[r] = n.modules[r] || {}, n.modules[r].namespaced = !0, n.modules[r].modules = n.modules[r].modules || {}, rn(n.modules[r], t, {
                isProperty: o
            })
        }

        function sn(n, t, e) {
            t && ("state" === e ? n.state = t || n.state : n[e] = Object.assign({}, n[e], t))
        }
        var cn = e(231);

        function ln(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }

        function dn(n) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? ln(Object(source), !0).forEach((function(t) {
                    Object(r.a)(n, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : ln(Object(source)).forEach((function(t) {
                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return n
        }

        function un(n, t) {
            var e = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
            if (!e) {
                if (Array.isArray(n) || (e = function(n, t) {
                        if (!n) return;
                        if ("string" == typeof n) return pn(n, t);
                        var e = Object.prototype.toString.call(n).slice(8, -1);
                        "Object" === e && n.constructor && (e = n.constructor.name);
                        if ("Map" === e || "Set" === e) return Array.from(n);
                        if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return pn(n, t)
                    }(n)) || t && n && "number" == typeof n.length) {
                    e && (n = e);
                    var i = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return i >= n.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: n[i++]
                            }
                        },
                        e: function(n) {
                            throw n
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0,
                l = !1;
            return {
                s: function() {
                    e = e.call(n)
                },
                n: function() {
                    var n = e.next();
                    return c = n.done, n
                },
                e: function(n) {
                    l = !0, r = n
                },
                f: function() {
                    try {
                        c || null == e.return || e.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function pn(n, t) {
            (null == t || t > n.length) && (t = n.length);
            for (var i = 0, e = new Array(t); i < t; i++) e[i] = n[i];
            return e
        }
        for (var fn = {
                setBaseURL: function(n) {
                    this.defaults.baseURL = n
                },
                setHeader: function(n, t) {
                    var e, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "common",
                        r = un(Array.isArray(o) ? o : [o]);
                    try {
                        for (r.s(); !(e = r.n()).done;) {
                            var c = e.value;
                            t ? this.defaults.headers[c][n] = t : delete this.defaults.headers[c][n]
                        }
                    } catch (n) {
                        r.e(n)
                    } finally {
                        r.f()
                    }
                },
                setToken: function(n, t) {
                    var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "common",
                        o = n ? (t ? t + " " : "") + n : null;
                    this.setHeader("Authorization", o, e)
                },
                onRequest: function(n) {
                    this.interceptors.request.use((function(t) {
                        return n(t) || t
                    }))
                },
                onResponse: function(n) {
                    this.interceptors.response.use((function(t) {
                        return n(t) || t
                    }))
                },
                onRequestError: function(n) {
                    this.interceptors.request.use(void 0, (function(t) {
                        return n(t) || Promise.reject(t)
                    }))
                },
                onResponseError: function(n) {
                    this.interceptors.response.use(void 0, (function(t) {
                        return n(t) || Promise.reject(t)
                    }))
                },
                onError: function(n) {
                    this.onRequestError(n), this.onResponseError(n)
                },
                create: function(n) {
                    return bn(Object(cn.a)(n, this.defaults))
                }
            }, hn = function() {
                var n = mn[gn];
                fn["$" + n] = function() {
                    return this[n].apply(this, arguments).then((function(n) {
                        return n && n.data
                    }))
                }
            }, gn = 0, mn = ["request", "delete", "get", "head", "options", "post", "put", "patch"]; gn < mn.length; gn++) hn();
        var bn = function(n) {
                var t = Z.a.create(n);
                return t.CancelToken = Z.a.CancelToken, t.isCancel = Z.a.isCancel,
                    function(n) {
                        for (var t in fn) n[t] = fn[t].bind(n)
                    }(t), t.onRequest((function(n) {
                        n.headers = dn(dn({}, t.defaults.headers.common), n.headers)
                    })), xn(t), t
            },
            xn = function(n) {
                var t = {
                        finish: function() {},
                        start: function() {},
                        fail: function() {},
                        set: function() {}
                    },
                    e = function() {
                        var n = "undefined" != typeof window && window.$nuxt;
                        return n && n.$loading && n.$loading.set ? n.$loading : t
                    },
                    o = 0;
                n.onRequest((function(n) {
                    n && !1 === n.progress || o++
                })), n.onResponse((function(n) {
                    n && n.config && !1 === n.config.progress || --o <= 0 && (o = 0, e().finish())
                })), n.onError((function(n) {
                    n && n.config && !1 === n.config.progress || (o--, Z.a.isCancel(n) ? o <= 0 && (o = 0, e().finish()) : (e().fail(), e().finish()))
                }));
                var r = function(n) {
                    if (o && n.total) {
                        var progress = 100 * n.loaded / (n.total * o);
                        e().set(Math.min(100, progress))
                    }
                };
                n.defaults.onUploadProgress = r, n.defaults.onDownloadProgress = r
            },
            wn = function(n, t) {
                var e = n.$config && n.$config.axios || {},
                    o = e.browserBaseURL || e.browserBaseUrl || e.baseURL || e.baseUrl || "/";
                var r = bn({
                    baseURL: o,
                    headers: {
                        common: {
                            Accept: "application/json, text/plain, */*"
                        },
                        delete: {},
                        get: {},
                        head: {},
                        post: {},
                        put: {},
                        patch: {}
                    }
                });
                n.$axios = r, t("axios", r)
            },
            vn = (e(67), e(144));
        c.a.use(vn.a);
        var yn = function(n) {
            var t = n.app,
                o = n.store;
            t.i18n = new vn.a({
                locale: o.state.locale,
                fallbackLocale: "en",
                messages: {
                    en: e(349)
                }
            }), t.i18n.path = function(link) {
                return link && !link.match(/\/$/) && (link += "/"), "/".concat(t.i18n.locale, "/").concat(link)
            }
        };

        function kn(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }

        function An(n) {
            var t = n.$axios,
                e = (n.redirect, n.$cookies, n.params);
            n.store, n.req;
            t.onRequest((function(n) {
                return n.params = function(n) {
                    for (var i = 1; i < arguments.length; i++) {
                        var source = null != arguments[i] ? arguments[i] : {};
                        i % 2 ? kn(Object(source), !0).forEach((function(t) {
                            Object(r.a)(n, t, source[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : kn(Object(source)).forEach((function(t) {
                            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                        }))
                    }
                    return n
                }({
                    lang: "en-us" === (e.lang || "en-us").toLowerCase() ? "en" : "cn"
                }, n.params), n
            })), t.onResponse((function(n) {}));
            var o = {
                getQrCodeImg: function(n) {
                    return t.get("/dgg/index/property", {
                        params: n
                    })
                }
            };
            n.$req = o, c.a.prototype.$req = o
        }
        var Cn = e(245);
        c.a.use(Cn);
        var jn = e(232),
            Dn = e.n(jn);
        c.a.use(Dn.a);
        var Sn = e(233),
            On = e.n(Sn);
        c.a.use(On.a);
        var Mn = e(234),
            Tn = function(n) {
                n.app, n.store;
                c.a.use(Mn.a)
            },
            In = (e(70), e(140)),
            Pn = {
                install: function(n) {
                    n.prototype.$isM = function() {
                        return "pc" === Object(In.a)(navigator.userAgent)
                    }, n.prototype.$browser = navigator.appName, n.prototype.$browserVer = navigator.appVersion, n.prototype.$getCurrPageName = function() {
                        return window.location.pathname.includes("announcement") ? "公告" : window.location.pathname.includes("about") ? "关于我们" : window.location.pathname.includes("join") ? "加入我们" : "首页"
                    }
                }
            };
        c.a.use(Pn);
        var _n = e(111),
            En = ["isServer", "req", "redirect", "route", "app", "store", "params", "query", "error", "res"],
            Ln = (e(177), function(n) {
                n.isServer;
                var t = n.req,
                    e = (n.redirect, n.route, n.app, n.store, n.params),
                    o = (n.query, n.error, n.res, Object(_n.a)(n, En), t ? t.headers["user-agent"] : navigator.userAgent || ""),
                    r = e.lang || ("Netscape" == navigator.appName ? navigator.language : navigator.userLanguage).substr(0, 2) || "en",
                    c = "mobile" === function(u) {
                        u.indexOf("Trident"), u.indexOf("Presto"), u.indexOf("AppleWebKit"), u.indexOf("Gecko") > -1 && u.indexOf("KHTML");
                        var n = !!u.match(/AppleWebKit.*Mobile.*/),
                            t = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
                            e = u.indexOf("Android") > -1 || u.indexOf("Linux") > -1,
                            o = u.indexOf("iPhone") > -1,
                            r = u.indexOf("iPad") > -1;
                        return u.indexOf("Safari"), n || t || e || o || r ? "mobile" : "pc"
                    }(o) ? "h5" : "";
                "/".concat(r, "/").concat("" !== c ? c + "/" : c)
            });

        function Nn(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }

        function Bn(n) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? Nn(Object(source), !0).forEach((function(t) {
                    Object(r.a)(n, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : Nn(Object(source)).forEach((function(t) {
                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return n
        }
        c.a.component(h.a.name, h.a), c.a.component(x.a.name, Bn(Bn({}, x.a), {}, {
            render: function(n, t) {
                return x.a._warned || (x.a._warned = !0, console.warn("<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead")), x.a.render(n, t)
            }
        })), c.a.component(S.name, S), c.a.component("NChild", S), c.a.component(H.name, H), Object.defineProperty(c.a.prototype, "$nuxt", {
            get: function() {
                var n = this.$root ? this.$root.$options.$nuxt : null;
                return n || "undefined" == typeof window ? n : window.$nuxt
            },
            configurable: !0
        }), c.a.use(d.a, {
            keyName: "head",
            attribute: "data-n-head",
            ssrAttribute: "data-n-head-ssr",
            tagIDKeyName: "hid"
        });
        var Rn = {
                name: "page",
                mode: "out-in",
                appear: !1,
                appearClass: "appear",
                appearActiveClass: "appear-active",
                appearToClass: "appear-to"
            },
            zn = l.a.Store.prototype.registerModule;

        function Hn(path, n) {
            var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                e = Array.isArray(path) ? !!path.reduce((function(n, path) {
                    return n && n[path]
                }), this.state) : path in this.state;
            return zn.call(this, path, n, Bn({
                preserveState: e
            }, t))
        }

        function Fn(n) {
            return Un.apply(this, arguments)
        }

        function Un() {
            return Un = Object(o.a)(regeneratorRuntime.mark((function n(t) {
                var e, r, l, d, f, h, path, m, x = arguments;
                return regeneratorRuntime.wrap((function(n) {
                    for (;;) switch (n.prev = n.next) {
                        case 0:
                            return m = function(n, t) {
                                if (!n) throw new Error("inject(key, value) has no key provided");
                                if (void 0 === t) throw new Error("inject('".concat(n, "', value) has no value provided"));
                                d[n = "$" + n] = t, d.context[n] || (d.context[n] = t), r[n] = d[n];
                                var e = "__nuxt_" + n + "_installed__";
                                c.a[e] || (c.a[e] = !0, c.a.use((function() {
                                    Object.prototype.hasOwnProperty.call(c.a.prototype, n) || Object.defineProperty(c.a.prototype, n, {
                                        get: function() {
                                            return this.$root.$options[n]
                                        }
                                    })
                                })))
                            }, e = x.length > 1 && void 0 !== x[1] ? x[1] : {}, r = on(t), n.next = 5, D(0, e);
                        case 5:
                            return l = n.sent, r.$router = l, r.registerModule = Hn, d = Bn({
                                head: {
                                    title: "iToken",
                                    meta: [{
                                        charset: "utf-8"
                                    }, {
                                        name: "viewport",
                                        content: "width=device-width, initial-scale=1, viewport-fit=cover"
                                    }, {
                                        name: "renderer",
                                        content: "webkit"
                                    }, {
                                        name: "format-detection",
                                        content: "telephone=no"
                                    }, {
                                        name: "X-UA-Compatible",
                                        content: "IE=Edge,chrome=1"
                                    }],
                                    link: [{
                                        rel: "icon",
                                        type: "image/x-icon",
                                        href: "/favicon.ico?t=1.0"
                                    }, {
                                        rel: "shortcut icon",
                                        href: "/apple-touch-icon.png"
                                    }, {
                                        rel: "apple-touch-icon",
                                        sizes: "80x80",
                                        href: "/apple-touch-icon-80x80.png"
                                    }, {
                                        rel: "apple-touch-icon",
                                        sizes: "152x152",
                                        href: "/apple-touch-icon-152x152.png"
                                    }, {
                                        rel: "apple-touch-icon",
                                        sizes: "180x180",
                                        href: "/apple-touch-icon-180x180.png"
                                    }, {
                                        rel: "apple-touch-icon",
                                        sizes: "167x167",
                                        href: "/apple-touch-icon-167x167.png"
                                    }, {
                                        rel: "apple-touch-icon",
                                        sizes: "304x304",
                                        href: "/apple-touch-icon.png"
                                    }, {
                                        rel: "apple-touch-icon-precomposed",
                                        href: "/apple-touch-icon.png"
                                    }],
                                    script: [],
                                    __dangerouslyDisableSanitizers: ["script"],
                                    style: []
                                },
                                store: r,
                                router: l,
                                nuxt: {
                                    defaultTransition: Rn,
                                    transitions: [Rn],
                                    setTransitions: function(n) {
                                        return Array.isArray(n) || (n = [n]), n = n.map((function(n) {
                                            return n = n ? "string" == typeof n ? Object.assign({}, Rn, {
                                                name: n
                                            }) : Object.assign({}, Rn, n) : Rn
                                        })), this.$options.nuxt.transitions = n, n
                                    },
                                    err: null,
                                    dateErr: null,
                                    error: function(n) {
                                        n = n || null, d.context._errored = Boolean(n), n = n ? Object(y.p)(n) : null;
                                        var e = d.nuxt;
                                        return this && (e = this.nuxt || this.$options.nuxt), e.dateErr = Date.now(), e.err = n, t && (t.nuxt.error = n), n
                                    }
                                }
                            }, nn), r.app = d, f = t ? t.next : function(n) {
                                return d.router.push(n)
                            }, t ? h = l.resolve(t.url).route : (path = Object(y.f)(l.options.base, l.options.mode), h = l.resolve(path).route), n.next = 14, Object(y.t)(d, {
                                store: r,
                                route: h,
                                next: f,
                                error: d.nuxt.error.bind(d),
                                payload: t ? t.payload : void 0,
                                req: t ? t.req : void 0,
                                res: t ? t.res : void 0,
                                beforeRenderFns: t ? t.beforeRenderFns : void 0,
                                beforeSerializeFns: t ? t.beforeSerializeFns : void 0,
                                ssrContext: t
                            });
                        case 14:
                            if (m("config", e), window.__NUXT__ && window.__NUXT__.state && r.replaceState(window.__NUXT__.state), "function" != typeof wn) {
                                n.next = 20;
                                break
                            }
                            return n.next = 20, wn(d.context, m);
                        case 20:
                            if ("function" != typeof yn) {
                                n.next = 23;
                                break
                            }
                            return n.next = 23, yn(d.context, m);
                        case 23:
                            return n.next = 26, An(d.context);
                        case 26:
                            n.next = 29;
                            break;
                        case 29:
                            n.next = 32;
                            break;
                        case 32:
                            n.next = 35;
                            break;
                        case 35:
                            if ("function" != typeof Tn) {
                                n.next = 38;
                                break
                            }
                            return n.next = 38, Tn(d.context, m);
                        case 38:
                            n.next = 41;
                            break;
                        case 41:
                            if ("function" != typeof Ln) {
                                n.next = 44;
                                break
                            }
                            return n.next = 44, Ln(d.context, m);
                        case 44:
                            return n.next = 47, new Promise((function(n, t) {
                                if (!l.resolve(d.context.route.fullPath).route.matched.length) return n();
                                l.replace(d.context.route.fullPath, n, (function(e) {
                                    if (!e._isRouter) return t(e);
                                    if (2 !== e.type) return n();
                                    var r = l.afterEach(function() {
                                        var t = Object(o.a)(regeneratorRuntime.mark((function t(e, o) {
                                            return regeneratorRuntime.wrap((function(t) {
                                                for (;;) switch (t.prev = t.next) {
                                                    case 0:
                                                        return t.next = 3, Object(y.j)(e);
                                                    case 3:
                                                        d.context.route = t.sent, d.context.params = e.params || {}, d.context.query = e.query || {}, r(), n();
                                                    case 8:
                                                    case "end":
                                                        return t.stop()
                                                }
                                            }), t)
                                        })));
                                        return function(n, e) {
                                            return t.apply(this, arguments)
                                        }
                                    }())
                                }))
                            }));
                        case 47:
                            return n.abrupt("return", {
                                store: r,
                                app: d,
                                router: l
                            });
                        case 48:
                        case "end":
                            return n.stop()
                    }
                }), n)
            }))), Un.apply(this, arguments)
        }
    }, function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e(2),
            r = (e(31), e(67), e(90), e(20), e(30)),
            c = e.n(r),
            l = {
                en: "en-US",
                zh: "zh-CN",
                ja: "ja-JP",
                ko: "ko-KR",
                ru: "ru-RU",
                tw: "zh-TW",
                es: "es-ES",
                vi: "vi-VI",
                id: "id-ID"
            };
        t.default = {
            isMobile: function(n) {
                return !!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|(?:ios \d+)/i.test(n || navigator.userAgent)
            },
            isAndroid: function(n) {
                return n.indexOf("Android") > -1 || n.indexOf("Linux") > -1
            },
            isWeixin: function() {
                return !!navigator.userAgent.toLowerCase().match(/MicroMessenger/i)
            },
            isPortrait: function() {
                if (navigator.userAgent.toLowerCase().indexOf("android") > -1) {
                    if (0 == window.orientation || 180 == window.orientation) return !1;
                    if (90 == window.orientation || -90 == window.orientation) return !0
                } else {
                    if (90 == window.orientation || -90 == window.orientation) return !1;
                    if (0 == window.orientation || 180 == window.orientation) return !0
                }
                return !0
            },
            language: function(n) {
                return l[n]
            },
            languageLower: function(n) {
                return l[n].toLowerCase()
            },
            hrefLang: function(n, path) {
                var t = [];
                for (var e in l) "zh" === e && path && path.indexOf("/zh") >= 0 ? t.push({
                    rel: "alternate",
                    hreflang: l[e],
                    href: "https://www.itoken.com/zh/".concat(n)
                }) : t.push({
                    rel: "alternate",
                    hreflang: l[e],
                    href: "https://www.itoken.com/".concat("zh" === e ? "" : e + "/").concat(n)
                });
                return t.push({
                    rel: "alternate",
                    hreflang: "x-default",
                    href: "https://www.itoken.com/en/".concat(n)
                }), t
            },
            initWeixinShare: function(title, desc) {
                var n = this;
                return Object(o.a)(regeneratorRuntime.mark((function t() {
                    var e, data;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (n.isWeixin()) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return");
                            case 2:
                                return t.next = 4, c.a.post("/api/getSignature", {
                                    url: location.href.split("#")[0]
                                });
                            case 4:
                                if (e = t.sent, data = e.data, "undefined" != typeof wx) {
                                    t.next = 8;
                                    break
                                }
                                return t.abrupt("return");
                            case 8:
                                data && data.appId && wx.config({
                                    debug: !1,
                                    appId: data.appId,
                                    timestamp: data.timestamp,
                                    nonceStr: data.nonceStr,
                                    signature: data.signature,
                                    jsApiList: ["checkJsApi", "onMenuShareTimeline", "onMenuShareAppMessage", "onMenuShareQQ", "onMenuShareWeibo", "hideMenuItems", "chooseImage"]
                                }), wx.ready((function() {
                                    var n = {
                                        title: title,
                                        desc: desc,
                                        link: "https://www.itoken.com",
                                        imgUrl: "https://www.itoken.com/thumbnail.png",
                                        success: function() {},
                                        cancel: function() {}
                                    };
                                    wx.onMenuShareTimeline(n), wx.onMenuShareAppMessage(n)
                                }));
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                })))()
            },
            getConfig: function() {
                var path = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "config.json";
                return c.a.get("/" + path).then((function(n) {
                    return n.data
                })).catch((function(n) {
                    return {}
                }))
            },
            loadScript: function(n, t) {
                document.getElementById("") && document.getElementById("").remove();
                var script = document.createElement("script");
                script.type = "text/javascript", script.async = "async", script.src = n, script.id = "", (document.head || document.getElementsByTagName("head")[0]).appendChild(script), script.readyState ? script.onreadystatechange = function() {
                    "complete" != script.readyState && "loaded" != script.readyState || (script.onreadystatechange = null, t())
                } : script.onload = function() {
                    t()
                }
            }
        }
    }, , , , , , , function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Light.4526165.eot"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Light.d398740.woff"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Light.72c693a.ttf"
    }, function(n, t, e) {
        n.exports = e.p + "img/PingFang-SC-Light.e432dd7.svg"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Semibold.0758b9b.eot"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Semibold.55144c0.woff"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Semibold.766ffb9.ttf"
    }, function(n, t, e) {
        n.exports = e.p + "img/PingFang-SC-Semibold.146b83a.svg"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Regular.504b157.eot"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Regular.c2d3dce.woff"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/PingFang-SC-Regular.13c3519.ttf"
    }, function(n, t, e) {
        n.exports = e.p + "img/PingFang-SC-Regular.325759a.svg"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/Roboto-Light.03e629f.ttf"
    }, function(n, t, e) {
        n.exports = e.p + "fonts/Roboto-Condensed.0eb141b.ttf"
    }, , , , , , , , , , , , , , , , , , , , function(n, t, e) {
        n.exports = e.p + "img/logo.05577e5.png"
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(n, t, e) {
        "use strict";
        e(70), e(62), e(71), e(24), e(20), e(68), e(58), e(19), e(69), e(72), e(73);
        var o = e(1);

        function r(n, t) {
            var e = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
            if (!e) {
                if (Array.isArray(n) || (e = function(n, t) {
                        if (!n) return;
                        if ("string" == typeof n) return c(n, t);
                        var e = Object.prototype.toString.call(n).slice(8, -1);
                        "Object" === e && n.constructor && (e = n.constructor.name);
                        if ("Map" === e || "Set" === e) return Array.from(n);
                        if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return c(n, t)
                    }(n)) || t && n && "number" == typeof n.length) {
                    e && (n = e);
                    var i = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return i >= n.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: n[i++]
                            }
                        },
                        e: function(n) {
                            throw n
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, l = !0,
                d = !1;
            return {
                s: function() {
                    e = e.call(n)
                },
                n: function() {
                    var n = e.next();
                    return l = n.done, n
                },
                e: function(n) {
                    d = !0, r = n
                },
                f: function() {
                    try {
                        l || null == e.return || e.return()
                    } finally {
                        if (d) throw r
                    }
                }
            }
        }

        function c(n, t) {
            (null == t || t > n.length) && (t = n.length);
            for (var i = 0, e = new Array(t); i < t; i++) e[i] = n[i];
            return e
        }
        var l = window.requestIdleCallback || function(n) {
                var t = Date.now();
                return setTimeout((function() {
                    n({
                        didTimeout: !1,
                        timeRemaining: function() {
                            return Math.max(0, 50 - (Date.now() - t))
                        }
                    })
                }), 1)
            },
            d = window.cancelIdleCallback || function(n) {
                clearTimeout(n)
            },
            f = window.IntersectionObserver && new window.IntersectionObserver((function(n) {
                n.forEach((function(n) {
                    var t = n.intersectionRatio,
                        link = n.target;
                    t <= 0 || !link.__prefetch || link.__prefetch()
                }))
            }));
        t.a = {
            name: "NuxtLink",
            extends: o.a.component("RouterLink"),
            props: {
                prefetch: {
                    type: Boolean,
                    default: !0
                },
                noPrefetch: {
                    type: Boolean,
                    default: !1
                }
            },
            mounted: function() {
                this.prefetch && !this.noPrefetch && (this.handleId = l(this.observe, {
                    timeout: 2e3
                }))
            },
            beforeDestroy: function() {
                d(this.handleId), this.__observed && (f.unobserve(this.$el), delete this.$el.__prefetch)
            },
            methods: {
                observe: function() {
                    f && this.shouldPrefetch() && (this.$el.__prefetch = this.prefetchLink.bind(this), f.observe(this.$el), this.__observed = !0)
                },
                shouldPrefetch: function() {
                    return this.getPrefetchComponents().length > 0
                },
                canPrefetch: function() {
                    var n = navigator.connection;
                    return !(this.$nuxt.isOffline || n && ((n.effectiveType || "").includes("2g") || n.saveData))
                },
                getPrefetchComponents: function() {
                    return this.$router.resolve(this.to, this.$route, this.append).resolved.matched.map((function(n) {
                        return n.components.default
                    })).filter((function(n) {
                        return "function" == typeof n && !n.options && !n.__prefetched
                    }))
                },
                prefetchLink: function() {
                    if (this.canPrefetch()) {
                        f.unobserve(this.$el);
                        var n, t = r(this.getPrefetchComponents());
                        try {
                            for (t.s(); !(n = t.n()).done;) {
                                var e = n.value,
                                    o = e();
                                o instanceof Promise && o.catch((function() {})), e.__prefetched = !0
                            }
                        } catch (n) {
                            t.e(n)
                        } finally {
                            t.f()
                        }
                    }
                }
            }
        }
    }, function(n, t, e) {
        "use strict";
        t.a = {
            link: [{
                href: "/alerts/badbrowser.css",
                type: "text/css",
                rel: "stylesheet"
            }],
            script: [{
                type: "text/javascript",
                src: "/js/optimized/flexible.js"
            }, {
                type: "text/javascript",
                body: !0,
                innerHTML: "\n             var ieVersion = new IeVersion();\n        if (ieVersion.IsIE) {\n          if (ieVersion.TrueVersion < 9) {\n            var el  = document.createElement('div');\n            el.className = 'badbrowser';\n            el.innerHTML = getTemplate();\n            document.body.appendChild(el);\n          }\n        } else {\n          // alert('not ie');\n        }"
            }, {
                type: "text/javascript",
                innerHTML: "\n          (function(para) {\n        window['sensorsDataAnalytic201505'] = para.name;\n        window[para.name] = {\n          para: para\n        };\n      })({\n        name: 'sa',\n        server_url: 'https://www.huobiwallet.com/shence_api/sa?project=production',\n        heatmap: {\n           //是否开启点击图，默认 default 表示开启，自动采集 $WebClick 事件，可以设置 'not_collect' 表示关闭\n           //需要 JSSDK 版本号大于 1.7\n           clickmap:'default',\n           //是否开启触达注意力图，默认 default 表示开启，自动采集 $WebStay 事件，可以设置 'not_collect' 表示关闭\n           //需要 JSSDK 版本号大于 1.9.1\n           scroll_notice_map:'not_collect'\n        }\n      });"
            }, {
                type: "text/javascript",
                body: !0,
                src: "/js/optimized/weixinsensor.js"
            }, {
                type: "text/javascript",
                body: !0,
                innerHTML: "sa.quick('autoTrack');"
            }, {
                type: "text/javascript",
                body: !0,
                src: "/js/www.googletagmanager.com/gtag/js?id=G-YGDCLRCT8Z"
            }, {
                type: "text/javascript",
                innerHTML: "window.dataLayer = window.dataLayer || [];\n        function gtag(){dataLayer.push(arguments);}\n        gtag('js', new Date());\n        gtag('config', 'G-YGDCLRCT8Z');\n        "
            }, {
                type: "text/javascript",
                body: !0,
                src: "/js/www.googletagmanager.com/gtag/js?id=AW-10826892364"
            }, {
                type: "text/javascript",
                innerHTML: "window.dataLayer = window.dataLayer || [];\n        function gtag(){dataLayer.push(arguments);}\n        gtag('js', new Date());\n        gtag('config', 'AW-10826892364');\n        gtag('event', 'conversion', {'send_to': 'AW-10826892364/b6BrCLfx3rwDEMyI1aoo'});\n        "
            }, {
                type: "text/javascript",
                body: !0,
                src: "/js/www.googletagmanager.com/gtag/js?id=G-H9766Z0BME"
            }, {
                type: "text/javascript",
                innerHTML: "window.dataLayer = window.dataLayer || [];\n          function gtag(){dataLayer.push(arguments);}\n          gtag('js', new Date());\n          gtag('config', 'G-H9766Z0BME');\n          "
            }],
            __dangerouslyDisableSanitizers: ["script"]
        }
    }, , , , , , , , , , , , , , , , , function(n, t, e) {
        n.exports = e.p + "img/wallet-logo.97beb35.png"
    }, , , , , , , , , function(n, t, e) {
        "use strict";

        function o(n) {
            return !!/MicroMessenger/i.test(n)
        }

        function r(n) {
            return !!/Weibo/i.test(n)
        }

        function c(n) {
            return !!/QQ/i.test(n)
        }

        function l(n) {
            return function(n) {
                return !!/(Android|webOS|iPhone|iPod|tablet|BlackBerry|Mobile)/i.test(n)
            }(n) ? function(n) {
                return !!/iPhone|iPad|iPod/i.test(n)
            }(n) ? o(n) ? {
                type: "ios",
                env: "wechat",
                masklayer: !0
            } : r(n) ? {
                type: "ios",
                env: "weibo",
                masklayer: !0
            } : c(n) ? {
                type: "ios",
                env: "qq",
                masklayer: !0
            } : {
                type: "ios"
            } : function(n) {
                return !!/Android/i.test(n)
            }(n) ? o(n) ? {
                type: "android",
                env: "wechat",
                masklayer: !0
            } : r(n) ? {
                type: "android",
                env: "weibo",
                masklayer: !0
            } : c(n) ? {
                type: "android",
                env: "qq",
                masklayer: !0
            } : {
                type: "android"
            } : {
                type: "mobile"
            } : {
                type: "pc"
            }
        }
        e.d(t, "a", (function() {
            return l
        }))
    }, function(n, t, e) {
        "use strict";
        var o = {};
        o.device = e(274), o.device = o.device.default || o.device, o.i18n = e(275), o.i18n = o.i18n.default || o.i18n, t.a = o
    }, , , , , , function(n, t, e) {
        "use strict";
        e(16), e(19), e(33), e(34);
        var o = e(7),
            r = e(23),
            c = (e(194), e(24), e(90), e(70), e(62), e(25), e(67), e(130), e(241)),
            l = e(9),
            d = e(226),
            f = e.n(d),
            h = e(77),
            m = e.n(h),
            x = e(227),
            w = e.n(x),
            v = e(17),
            y = e(228),
            k = e(229);
        e(37);

        function A(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }
        var C = {
                name: "Top",
                components: {
                    lottie: c.a
                },
                mixins: [v.a],
                props: {
                    theme: {
                        type: String
                    },
                    disableTranslate: {
                        type: Boolean,
                        default: !1
                    },
                    logo: {
                        type: String,
                        default: "logo"
                    },
                    mobileLogo: {
                        type: String,
                        default: ""
                    },
                    langShow: {
                        type: Boolean,
                        default: !0
                    },
                    isLight: {
                        type: Boolean,
                        default: !1
                    },
                    arrow: {
                        type: String,
                        default: "down_arrow_dark"
                    },
                    logoSrc: {
                        type: String,
                        default: ""
                    },
                    special: {
                        type: Boolean,
                        default: !1
                    },
                    styleCSS: {
                        type: Object,
                        default: function() {}
                    }
                },
                data: function() {
                    var n = {
                        en: {
                            language: "English",
                            key: "en"
                        }
                    };
                    return {
                        zhOptions: {
                            loop: !0,
                            autoplay: !0,
                            animationData: y
                        },
                        enOptions: {
                            loop: !0,
                            autoplay: !0,
                            animationData: k
                        },
                        animationSpeed: 1,
                        anim: {},
                        defaultLogo: m.a,
                        defaultArrow: w.a,
                        lightArrow: f.a,
                        cls: "mobile",
                        words: l,
                        showNav: !1,
                        lan: this.$i18n.locale,
                        showLanguageList: !1,
                        localeMap: n,
                        locales: Object.values(n),
                        expandMobileLanguage: !1,
                        getScroll: "",
                        contactUrl: "https://support.huobiwallet.io/hc/".concat("zh" === this.$i18n.locale ? "zh-cn" : "en-us", "/articles/360000143241")
                    }
                },
                computed: {
                    isZH: function() {
                        return "zh" === this.$i18n.locale
                    },
                    localesList: function() {
                        var n = this;
                        return this.locales.filter((function(t) {
                            return "noChinese" !== n.langShow || "zh" !== t.key
                        }))
                    },
                    uiLanguageList: function() {
                        return [this.currentLanguage].concat(Object(r.a)(this.otherLanguage))
                    },
                    currentLanguage: function() {
                        var n = this.localeMap,
                            t = n[this.lan];
                        return t || (t = n.en), t
                    },
                    otherLanguage: function() {
                        var n = function(n) {
                            for (var i = 1; i < arguments.length; i++) {
                                var source = null != arguments[i] ? arguments[i] : {};
                                i % 2 ? A(Object(source), !0).forEach((function(t) {
                                    Object(o.a)(n, t, source[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : A(Object(source)).forEach((function(t) {
                                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                                }))
                            }
                            return n
                        }({}, this.localeMap);
                        "noChinese" === this.langShow && delete n.zh;
                        var t = this.lan;
                        return n[t] && delete n[t], Object.values(n)
                    },
                    helpUrl: function() {
                        return "https://forum.itoken.com/latest/"
                    },
                    pathFind: function() {
                        var path = this.$route.path.split("/");
                        return !path[2] || "install" === path[2]
                    }
                },
                mounted: function() {
                    window.addEventListener("scroll", this.onScroll), this.onScroll()
                },
                beforeDestroy: function() {
                    window.removeEventListener("scroll", this.onScroll)
                },
                methods: {
                    onScroll: function() {
                        this.pathFind ? window.scrollY > 0 ? this.getScroll = "outside-background" : this.getScroll = "outside-background-transparent" : this.getScroll = "outside-background"
                    },
                    handleDecorationAnimation: function(n) {
                        this.anim = n, console.log(n)
                    },
                    gotoLink: function(path) {
                        var n = "";
                        n = path.includes("announcement") ? "PC_Notice" : "PC_home", this.special || this.reqBuriedData(n), this.$router.push(path)
                    },
                    gotoHome: function(path) {
                        window.open(path, "_self")
                    },
                    gotoFeature: function(path) {
                        this.$router.push(path), document.getElementById("feature").scrollIntoView({
                            behavior: "smooth"
                        })
                    },
                    gotoHelp: function() {
                        this.special || this.reqBuriedData("PC_help"), window.location.href = this.helpUrl
                    },
                    goto8th: function() {
                        this.$route.push({
                            path: "activeLandPage"
                        })
                    },
                    onMobileLanguageToggle: function(n) {
                        this.expandMobileLanguage = !this.expandMobileLanguage;
                        var t = this.$refs.lanSelector;
                        "noChinese" === this.langShow ? t.className = t.className.replace(/\s?lan-selector-expand1/, "") + (this.expandMobileLanguage ? " lan-selector-expand1" : "") : t.className = t.className.replace(/\s?lan-selector-expand/, "") + (this.expandMobileLanguage ? " lan-selector-expand" : "")
                    },
                    onNavClick: function() {
                        this.showNav = !0
                    },
                    closeNavScreen: function() {
                        this.showNav = !1
                    },
                    toggleLanguageList: function() {
                        var n = this;
                        if (this.showLanguageList = !this.showLanguageList, this.showLanguageList) {
                            document.body.addEventListener("click", (function t() {
                                n.showLanguageList = !1, document.body.removeEventListener("click", t)
                            }))
                        }
                    },
                    selectPCLanguage: function(n) {
                        this.special || ("zh" === n ? sa.track("C_CN", {}) : "en" === n ? sa.track("C_EN", {}) : "tw" === n ? sa.track("C_TW", {}) : "es" === n ? sa.track("C_ES", {}) : "vi" === n ? sa.track("C_VI", {}) : "ru" === n ? sa.track("C_RU", {}) : "id" === n && sa.track("C_ID", {})), this.special || this.reqBuriedData("PC_LanguageChoice", {
                            SelectContent: n
                        }), this.$i18n.locale = n, this.lan = n, this.showLanguageList = !1;
                        var t = "\\/(" + this.$store.state.locales.join("|") + ")/?",
                            e = location.href.match(new RegExp(t));
                        if (e) {
                            if (e[1] === n) return;
                            var o = location.href.replace(new RegExp(t), "/".concat(n, "/"));
                            location.href = o
                        } else {
                            var r = location.href.replace(/([^/:])\//, "$1/".concat(n, "/"));
                            location.href = r
                        }
                    }
                }
            },
            j = C,
            D = (e(321), e(3)),
            component = Object(D.a)(j, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    class: ["header-bar-con header-bar-pc"]
                }, [t("div", {
                    staticClass: "outside-container",
                    class: n.getScroll,
                    style: n.styleCSS
                }, [t("div", {
                    staticClass: "header-bar-content"
                }, [t("div", {
                    staticClass: "header-bar-menu"
                }, [t("a", {
                    staticClass: "header_logo",
                    on: {
                        click: function(t) {
                            n.gotoHome(n.$i18n.path(""))
                        }
                    }
                }, [t("img", {
                    attrs: {
                        alt: n.$t("hbWallet"),
                        src: n.logoSrc || n.defaultLogo
                    }
                })]), n._v(" "), t("div", {
                    staticClass: "nav-item"
                }, [t("a", {
                    staticClass: "pc-nav-item",
                    class: n.$route.path === "/".concat(n.$i18n.locale) || n.$route.path === "/".concat(n.$i18n.locale, "/") || "" === n.$route.path ? "active-nav" : "",
                    on: {
                        click: function(t) {
                            n.gotoFeature(n.$i18n.path(""))
                        }
                    }
                }, [n._v("\n                        " + n._s(n.$t("homeMenu")) + "\n                    ")])])])])])])
            }), [], !1, null, "cf602d34", null);
        t.a = component.exports
    }, function(n, t, e) {
        "use strict";
        var o = e(2),
            r = (e(31), e(25), e(16), e(9)),
            c = (e(37), e(17)),
            l = {
                name: "Section4",
                props: ["appstore", "googlePlayAndroidDownload"],
                computed: {
                    isZH: function() {
                        return "zh" === this.$i18n.locale
                    }
                },
                mixins: [c.a],
                data: function() {
                    return {
                        qrImgUrl: "",
                        androidDownload: "",
                        androidDownloadModalVisible: !1,
                        tipShow: !1,
                        showWarmPrompt: !1,
                        registerUrl: "https://www.yuque.com/docs/share/4fa4747b-0293-4841-b473-213573296f38?#"
                    }
                },
                created: function() {
                    this.getQrCode()
                },
                methods: {
                    getQrCode: function() {
                        var n = this;
                        return Object(o.a)(regeneratorRuntime.mark((function t() {
                            var param;
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return param = {
                                            key: "wallet_qrcode"
                                        }, t.next = 3, n.$axios.get("/dgg/index/property", {
                                            params: param
                                        }).then((function(data) {
                                            data = JSON.parse(data.data.data), Object.keys(data).length && (n.qrImgUrl = n.isZH ? data.zhCode : data.enCode, n.androidDownload = data.apkUrl)
                                        })).catch((function(n) {
                                            console.log("请求失败")
                                        }));
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))()
                    },
                    downloadGoogleStore: function(n) {
                        this.reqBuriedData("PC_DownloadResults", {
                            Entrance: "底部导航下载按键",
                            BackupResult: !0,
                            DownloadMethod: "Google Play"
                        })
                    },
                    downloadAndroidAPK: function(n) {
                        this.reqBuriedData("PC_DownloadResults", {
                            Entrance: "底部导航下载按键",
                            BackupResult: !0,
                            DownloadMethod: "AndroidApk"
                        }), location.href = this.androidDownload
                    },
                    _onOrientationChange: function() {
                        var n, t = this,
                            e = -90 === window.orientation || 90 === window.orientation;
                        if (e) this.$refs.videoCon.style.width = "100vw", this.$refs.videoCon.style.height = "100vh";
                        else {
                            setTimeout((function() {
                                t.$refs.videoCon.style.width = "100vw";
                                var n = t.$refs.videoCon.getBoundingClientRect().width;
                                t.$refs.videoCon.style.height = 609 * n / 1082 + "px"
                            }), 200)
                        }
                        e && this.showVideo ? (n = this.$refs.videoCon).requestFullscreen ? n.requestFullscreen() : n.mozRequestFullScreen ? n.mozRequestFullScreen() : n.webkitRequestFullscreen ? n.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT) : n.msRequestFullscreen ? n.msRequestFullscreen() : n.webkitEnterFullscreen ? n.webkitEnterFullscreen() : console.log("no requestFullscreen functionality detected") : (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement) && function(n) {
                            document.cancelFullscreen ? document.cancelFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen ? document.msExitFullscreen() : n && n.webkitExitFullscreen ? n.webkitExitFullscreen() : console.log("no cancelFullscreen functionality detected")
                        }(this.$refs.videoCon)
                    },
                    setSize: function() {
                        var n = window.innerWidth,
                            t = window.innerHeight,
                            e = 1082,
                            o = 609,
                            r = n / t,
                            c = e / o;
                        if (n <= 960)
                            if (r > c) {
                                var l = e * t / o;
                                this.videoStyle = {
                                    height: "100vh",
                                    width: l + "px"
                                }
                            } else {
                                var d = o * n / e;
                                this.videoStyle = {
                                    height: d + "px",
                                    width: "100vw"
                                }
                            }
                        else if (r > c) {
                            var f = .8 * t,
                                h = e * t * .8 / o;
                            this.videoStyle = {
                                height: f + "px",
                                width: h + "px"
                            }
                        } else {
                            var m = .8 * n,
                                x = o * n * .8 / e;
                            this.videoStyle = {
                                width: m + "px",
                                height: x + "px"
                            }
                        }
                        this.$refs.videoCon && (this.$refs.videoCon.style.width = this.videoStyle.width, this.$refs.videoCon.style.height = this.videoStyle.height)
                    },
                    onIOSClick: function(n) {
                        this.reqBuriedData("PC_DownloadResults", {
                            Entrance: "底部导航下载按键",
                            BackupResult: !1,
                            DownloadMethod: "App Store"
                        }), window.open(this.appstore)
                    },
                    onAndroidClick: function(n) {},
                    hideHover: function() {
                        clearTimeout(this.delayHover)
                    },
                    onAndroidHover: function(n) {
                        var t = this;
                        this.delayHover = setTimeout((function() {
                            t.$refs.androidDownloadList.style.display = "block", t.androidDownloadModalVisible = !0
                        }), 200)
                    },
                    onAndroidOut: function(n) {
                        var t = this;
                        this.androidDownloadModalVisible = !1, setTimeout((function() {
                            t.$refs.androidDownloadList.style.display = "none"
                        }), 300)
                    },
                    closeAndroidDownloadModal: function() {
                        this.onAndroidOut()
                    }
                }
            },
            d = (e(310), e(3)),
            component = Object(d.a)(l, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", [t("div", {
                    staticClass: "section4-con-pc"
                }, [t("div", {
                    staticClass: "section4-content"
                }, [t("div", {
                    staticClass: "left"
                }, [t("div", {
                    staticClass: "title",
                    class: n.isZH ? "" : "is-en-title",
                    domProps: {
                        innerHTML: n._s(n.$t("home.footer.downLoadTips"))
                    }
                }), n._v(" "), t("div", {
                    staticClass: "desc",
                    class: n.isZH ? "" : "is-en-desc",
                    domProps: {
                        innerHTML: n._s(n.$t("home.footer.downLoadDesc"))
                    }
                })]), n._v(" "), t("div", {
                    staticClass: "right"
                }, [t("div", {
                    staticClass: "btn_con",
                    staticStyle: {
                        "margin-top": "30px"
                    }
                }, [t("router-link", {
                    staticClass: "download_btn android_btn",
                    attrs: {
                        to: n.$i18n.path("install"),
                        href: n.androidDownload
                    },
                    on: {
                        click: function(t) {
                            return t.stopPropagation(), t.preventDefault(), n.onAndroidClick.apply(null, arguments)
                        },
                        mouseleave: function(t) {
                            return t.stopPropagation(), t.preventDefault(), n.hideHover.apply(null, arguments)
                        },
                        mouseenter: function(t) {
                            return t.stopPropagation(), t.preventDefault(), n.onAndroidHover.apply(null, arguments)
                        }
                    }
                }, [t("img", {
                    staticClass: "android_icon",
                    attrs: {
                        src: e(246)
                    }
                }), n._v(" "), t("div", [n._v(n._s(n.$t("downloadAndroidButton")))])]), n._v(" "), t("div", {
                    ref: "androidDownloadList",
                    staticClass: "android_download_list",
                    class: [n.androidDownloadModalVisible ? "visible" : ""],
                    on: {
                        mouseleave: n.onAndroidOut
                    }
                }, [t("div", {
                    staticClass: "close-btn",
                    on: {
                        click: n.closeAndroidDownloadModal
                    }
                }, [t("img", {
                    attrs: {
                        src: e(242)
                    }
                })]), n._v(" "), t("div", {
                    staticClass: "android_download_con"
                }, [t("div", {
                    staticClass: "android_download_title"
                }, [n._v(n._s(n.$t("androidDownloadText")))]), n._v(" "), t("a", {
                    staticClass: "download_btn site_download",
                    attrs: {
                        href: "javascript:void(0)"
                    },
                    on: {
                        click: n.downloadAndroidAPK
                    }
                }, [t("img", {
                    attrs: {
                        src: e(152),
                        alt: "android下载"
                    }
                }), n._v(" "), t("div", [n._v(n._s(n.$t("androidLocalDownloadText")))])]), n._v(" "), t("a", {
                    staticClass: "download_btn google_play_download",
                    attrs: {
                        href: n.googlePlayAndroidDownload,
                        target: "_blank"
                    },
                    on: {
                        click: n.downloadGoogleStore
                    }
                }, [t("img", {
                    attrs: {
                        src: e(151),
                        alt: "Google Play"
                    }
                }), n._v("\n                                Google Play\n                            ")])])])], 1), n._v(" "), t("div", {
                    staticClass: "qr_con"
                }, [t("div", {
                    staticClass: "temp_pos"
                }, [n.isZH ? t("img", {
                    attrs: {
                        src: e(247)
                    }
                }) : t("img", {
                    attrs: {
                        src: e(248)
                    }
                })])])])])]), n._v(" "), t("div", {
                    staticClass: "section4-con-pc-line"
                })])
            }), [], !1, null, "32c22c38", null),
            f = component.exports,
            h = (e(243), {
                name: "Footer",
                mixins: [c.a],
                props: {
                    appstore: {
                        type: String
                    },
                    googlePlayAndroidDownload: {
                        type: String
                    },
                    testflight: {
                        type: String
                    },
                    showDownload: {
                        type: Boolean,
                        default: !0
                    },
                    special: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        qrImgUrl: "",
                        androidDownload: "",
                        copyRightDes: r.copyRightDes,
                        jingICP: r.jingICP,
                        copyRight: r.copyRight.replace("{}", (new Date).getFullYear()),
                        huobiChina: r.hbChina2,
                        huobiChinaZH: r.hbChina1,
                        wechatHover: !1
                    }
                },
                computed: {
                    helpUrl: function() {
                        return "https://forum.itoken.com/latest/"
                    },
                    isVI: function() {
                        return "vi" === this.$i18n.locale
                    },
                    isRU: function() {
                        return "ru" === this.$i18n.locale
                    }
                },
                components: {
                    Section4: f
                },
                created: function() {
                    this.getQrCode()
                },
                mounted: function() {
                    gtag("event", "conversion", {
                        send_to: "AW-10826892364/b6BrCLfx3rwDEMyI1aoo"
                    })
                },
                methods: {
                    getQrCode: function() {
                        var n = this;
                        return Object(o.a)(regeneratorRuntime.mark((function t() {
                            var param;
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return param = {
                                            key: "wallet_qrcode"
                                        }, t.next = 3, n.$axios.get("/dgg/index/property", {
                                            params: param
                                        }).then((function(data) {
                                            data = JSON.parse(data.data.data), Object.keys(data).length && (n.qrImgUrl = n.isZH ? data.zhCode : data.enCode, n.androidDownload = data.apkUrl)
                                        })).catch((function(n) {
                                            console.log("请求失败1")
                                        }));
                                    case 3:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))()
                    },
                    contactUsLinkClick: function(text, n) {
                        this.special || this.reqBuriedData("PC_contactUs", {
                            SelectContent: text
                        }), window.open(n)
                    },
                    bottomLinkClick: function(text, n) {
                        this.special || this.reqBuriedData("PC_BottomArea", {
                            SelectContent: text
                        }), window.open(n)
                    },
                    onWechatHover: function(n) {
                        var t = this;
                        n ? (this.$refs.wechatQRCon.style.display = "flex", setTimeout((function() {
                            t.wechatHover = !0
                        }), 30)) : (this.wechatHover = !1, setTimeout((function() {
                            t.$refs.wechatQRCon.style.display = "none"
                        }), 300))
                    }
                }
            }),
            m = (e(312), Object(d.a)(h, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    staticClass: "footer-pc",
                    style: {
                        height: n.showDownload ? "671px" : "300px"
                    }
                }, [n.showDownload ? t("Section4", {
                    attrs: {
                        androidDownload: n.androidDownload,
                        appstore: n.appstore,
                        googlePlayAndroidDownload: n.googlePlayAndroidDownload,
                        testflight: n.testflight
                    }
                }) : n._e(), n._v(" "), t("div", {
                    staticClass: "content"
                }, [t("div", {
                    staticClass: "bottom-nav"
                }, [t("div", {
                    staticClass: "left"
                }, [t("div", {
                    staticClass: "logo-info"
                }, [t("a", {
                    staticStyle: {
                        display: "inherit"
                    },
                    attrs: {
                        href: "javascript: void(0)"
                    },
                    on: {
                        click: function(t) {
                            n.bottomLinkClick("huobi_bottom_logo", n.$i18n.path(""))
                        }
                    }
                }, [t("img", {
                    staticClass: "logo-small",
                    attrs: {
                        src: e(131)
                    }
                })]), n._v(" "), t("div", {
                    staticClass: "logo-text-title"
                }, [n._v(n._s(n.copyRight))])]), n._v(" "), t("div", {
                    staticClass: "links-con"
                }, [t("div", {
                    class: ["links-group", n.$i18n.locale + "-links-group"]
                }, [t("div", {
                    staticClass: "links-title"
                }, [n._v("\n                            " + n._s(n.$t("walletTeam")) + "\n                        ")]), n._v(" "), t("router-link", {
                    staticClass: "links-item",
                    attrs: {
                        to: n.$i18n.path("about")
                    }
                }, [n._v(n._s(n.$t("aboutUS")))]), n._v(" "), t("a", {
                    staticClass: "links-item",
                    attrs: {
                        href: "https://itokenwallet.onelink.me/KBT5/Site2AS2"
                    }
                }, [n._v(n._s(n.$t("iosWallet")))]), n._v(" "), t("a", {
                    staticClass: "links-item",
                    attrs: {
                        href: "https://play.google.com/store/apps/details?id=com.huobionchainwallet.itokenhd"
                    }
                }, [n._v(n._s(n.$t("androidWallet")))])], 1), n._v(" "), t("div", {
                    class: ["links-group", n.$i18n.locale + "-links-group"]
                }, [t("div", {
                    staticClass: "links-title"
                }, [n._v("\n                            " + n._s(n.$t("userSupport")) + "\n                        ")]), n._v(" "), t("a", {
                    staticClass: "links-item",
                    attrs: {
                        href: "javascript: void(0)"
                    },
                    on: {
                        click: function(t) {
                            n.bottomLinkClick(n.$t("userProtocol"), "/protocols/".concat("zh" === n.$i18n.locale ? "zh" : "en", ".html"))
                        }
                    }
                }, [n._v("\n                            " + n._s(n.$t("userProtocol")) + "\n                        ")])])])]), n._v(" "), t("div", {
                    staticClass: "contact-con"
                }, [t("div", {
                    staticClass: "contact-con-title",
                    class: n.isVI || n.isRU ? "contact-con-title-small" : ""
                }, [n._v("\n                    " + n._s(n.$t("follow")) + "\n                ")]), n._v(" "), t("div", {
                    staticClass: "list"
                }, [t("a", {
                    attrs: {
                        href: "javascript: void(0)",
                        "data-event": "C_Twitter"
                    },
                    on: {
                        click: function(t) {
                            return n.bottomLinkClick("twitter", "https://twitter.com/iTokenWallet")
                        }
                    }
                }, [t("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(155)
                    }
                })]), n._v(" "), t("a", {
                    attrs: {
                        href: "javascript: void(0)",
                        "data-event": "C_Facebook"
                    },
                    on: {
                        click: function(t) {
                            return n.bottomLinkClick("medium", "https://medium.com/@iTokenWalletOfficial")
                        }
                    }
                }, [t("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(156)
                    }
                })])])])])])], 1)
            }), [], !1, null, "1307f04f", null));
        t.a = m.exports
    }, function(n, t, e) {
        "use strict";
        var o = [function() {
                var n = this._self._c;
                return n("div", {
                    staticClass: "link-title"
                }, [n("a", {
                    attrs: {
                        "data-event": "C_Twitter",
                        href: "https://twitter.com/iTokenWallet",
                        target: "_blank"
                    }
                }, [n("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(329)
                    }
                })]), this._v(" "), n("a", {
                    attrs: {
                        "data-event": "C_Facebook",
                        href: "https://defibox.medium.com/",
                        target: "_blank"
                    }
                }, [n("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(330)
                    }
                })])])
            }],
            r = (e(16), e(19), e(33), e(34), e(7)),
            c = e(23),
            l = (e(194), e(24), e(25), e(67), e(130), e(331), e(9)),
            d = e(17),
            f = e(230),
            h = e.n(f);
        e(37);

        function m(object, n) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(object);
                n && (e = e.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(object, n).enumerable
                }))), t.push.apply(t, e)
            }
            return t
        }
        var x = {
                name: "HeaderBar",
                components: {},
                props: ["theme", "disableTranslate", "logo", "mobileLogo", "langShow", "logoSrc"],
                mixins: [d.a],
                data: function() {
                    var n = {
                        en: {
                            language: "English",
                            key: "en"
                        }
                    };
                    return {
                        navIcon8th: h.a,
                        cls: "mobile",
                        words: l,
                        showNav: !1,
                        lan: this.$i18n.locale,
                        showLanguageList: !1,
                        localeMap: n,
                        locales: Object.values(n),
                        expandMobileLanguage: !1,
                        contactUrl: "https://support.huobiwallet.io/hc/".concat("zh" === this.$i18n.locale ? "zh-cn" : "en-us", "/articles/360000143241")
                    }
                },
                computed: {
                    txt: function() {
                        return this.$t("activeLandPage.h5")
                    },
                    localesList: function() {
                        var n = this;
                        return this.locales.filter((function(t) {
                            return "noChinese" !== n.langShow || "zh" !== t.key
                        }))
                    },
                    uiLanguageList: function() {
                        return console.log([this.currentLanguage].concat(Object(c.a)(this.otherLanguage))), [this.currentLanguage].concat(Object(c.a)(this.otherLanguage))
                    },
                    currentLanguage: function() {
                        var n = this.localeMap,
                            t = n[this.lan];
                        return t || (t = n.en), t
                    },
                    otherLanguage: function() {
                        var n = function(n) {
                            for (var i = 1; i < arguments.length; i++) {
                                var source = null != arguments[i] ? arguments[i] : {};
                                i % 2 ? m(Object(source), !0).forEach((function(t) {
                                    Object(r.a)(n, t, source[t])
                                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(source)) : m(Object(source)).forEach((function(t) {
                                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(source, t))
                                }))
                            }
                            return n
                        }({}, this.localeMap);
                        "noChinese" === this.langShow && delete n.zh;
                        var t = this.lan;
                        return n[t] && delete n[t], Object.values(n)
                    },
                    helpUrl: function() {
                        return "https://forum.itoken.com/latest"
                    }
                },
                mounted: function() {
                    window.addEventListener("click", this.otherClose), window.addEventListener("click", this.otherCloseNemu)
                },
                methods: {
                    otherCloseNemu: function(n) {
                        if (this.$refs.menuPopList && this.showNav) {
                            if ("link-title" === n.target.className || "nav-btn-icon" === n.target.className || "nav-item" === n.target.className) return;
                            this.showNav = !1
                        }
                    },
                    otherClose: function(n) {
                        if (this.$refs.lanSelector) {
                            if ("lan-selector" === n.target.className || "locale-flag" === n.target.className) return;
                            this.expandMobileLanguage = !1
                        }
                    },
                    onMobileLanguageToggle: function(n) {
                        this.expandMobileLanguage = !this.expandMobileLanguage;
                        var t = this.$refs.lanSelector;
                        "noChinese" === this.langShow ? t.className = t.className.replace(/\s?lan-selector-expand1/, "") + (this.expandMobileLanguage ? " lan-selector-expand1" : "") : t.className = t.className.replace(/\s?lan-selector-expand/, "") + (this.expandMobileLanguage ? " lan-selector-expand" : "")
                    },
                    onNavClick: function() {
                        this.showNav = !0
                    },
                    closeNavScreen: function() {
                        this.showNav = !1
                    },
                    selectLanguage: function(n, t) {
                        if (0 !== t) {
                            "zh" === n ? sa.track("C_CN", {}) : "en" === n ? sa.track("C_EN", {}) : "tw" === n ? sa.track("C_TW", {}) : "ko" === n ? sa.track("C_KO", {}) : "ja" === n ? sa.track("C_JA", {}) : "ru" === n && sa.track("C_RU", {}), this.reqBuriedData("H5_LanguageChoice", {
                                SelectContent: n
                            }), this.$i18n.locale = n, this.lan = n;
                            var e = location.href.match(new RegExp("\\/(" + this.$store.state.locales.join("|") + ")"));
                            if (e) {
                                if (e[1] === n) return;
                                location.href = location.href.replace(new RegExp("\\/(" + this.$store.state.locales.join("|") + ")/?"), "/".concat(n, "/"))
                            } else location.href = location.href.replace(/([^/:])\//, "$1/".concat(n, "/"))
                        }
                    },
                    toggleLanguageList: function() {
                        var n = this;
                        if (this.showLanguageList = !this.showLanguageList, this.showLanguageList) {
                            document.body.addEventListener("click", (function t() {
                                n.showLanguageList = !1, document.body.removeEventListener("click", t)
                            }))
                        }
                    },
                    selectPCLanguage: function(n) {
                        "zh" === n ? sa.track("C_CN", {}) : "en" === n ? sa.track("C_EN", {}) : "tw" === n ? sa.track("C_TW", {}) : "ko" === n ? sa.track("C_KO", {}) : "ja" === n ? sa.track("C_JA", {}) : "ru" === n && sa.track("C_RU", {}), this.$i18n.locale = n, this.lan = n, this.showLanguageList = !1;
                        var t = "\\/(" + this.$store.state.locales.join("|") + ")/?",
                            e = location.href.match(new RegExp(t));
                        if (e) {
                            if (e[1] === n) return;
                            var o = location.href.replace(new RegExp(t), "/".concat(n, "/"));
                            location.href = o
                        } else {
                            var r = location.href.replace(/([^/:])\//, "$1/".concat(n, "/"));
                            location.href = r
                        }
                    },
                    gotoFeature: function(path) {
                        this.$router.push(path), document.getElementById("feature").scrollIntoView({
                            behavior: "smooth"
                        })
                    }
                }
            },
            w = x,
            v = (e(332), e(3)),
            component = Object(v.a)(w, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", [t("div", {
                    staticClass: "header-bar-con header-bar-mobile"
                }, [t("div", {
                    staticClass: "header-bar-content"
                }, [t("div", {
                    class: ["nav-screen", n.showNav ? "nav-screen-show" : ""]
                }, [t("router-link", {
                    staticClass: "header_logo",
                    attrs: {
                        to: n.$i18n.path("h5")
                    }
                }, [t("img", {
                    attrs: {
                        alt: n.$t("hbWallet"),
                        src: e(77)
                    }
                })]), n._v(" "), t("div", {
                    staticClass: "right"
                }, [t("div", {
                    staticClass: "nav-btn",
                    on: {
                        click: n.onNavClick
                    }
                }, [t("img", {
                    staticClass: "nav-btn-icon",
                    attrs: {
                        alt: "",
                        src: e(323)
                    }
                })])]), n._v(" "), t("div", {
                    ref: "menuPopList",
                    class: ["inner_screen", n.showNav ? "inner_screen-show" : ""]
                }, [t("div", {
                    staticClass: "inner_screen-page"
                }, [t("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: n.showNav,
                        expression: "showNav"
                    }],
                    staticClass: "download-header"
                }, [t("img", {
                    staticClass: "logo",
                    attrs: {
                        src: e(77)
                    }
                }), n._v(" "), t("div", {
                    staticClass: "close-btn",
                    on: {
                        click: n.closeNavScreen
                    }
                }, [t("img", {
                    attrs: {
                        src: e(153)
                    }
                })])]), n._v(" "), t("div", {
                    staticClass: "nav-items"
                }, [t("router-link", {
                    staticClass: "nav-item",
                    attrs: {
                        to: n.$i18n.path("h5")
                    },
                    nativeOn: {
                        click: function(t) {
                            n.gotoFeature(n.$i18n.path("h5"))
                        }
                    }
                }, [n._v("\n                                " + n._s(n.$t("homeMenu")))])], 1), n._v(" "), n._m(0)])])], 1)])]), n._v(" "), t("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: n.expandMobileLanguage,
                        expression: "expandMobileLanguage"
                    }],
                    staticClass: "languages-mobile"
                }, [t("div", {
                    staticClass: "languages-mobile-container"
                }, [t("div", {
                    ref: "lanSelector",
                    staticClass: "lan-selector"
                }, n._l(n.uiLanguageList, (function(o, r) {
                    return t("div", {
                        key: o.key,
                        staticClass: "lan-item",
                        on: {
                            click: function(t) {
                                return n.selectLanguage(o.key, r)
                            }
                        }
                    }, ["zh" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(196)
                        }
                    }) : n._e(), n._v(" "), "tw" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(196)
                        }
                    }) : n._e(), n._v(" "), "en" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(324)
                        }
                    }) : n._e(), n._v(" "), "es" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(325)
                        }
                    }) : n._e(), n._v(" "), "ru" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(326)
                        }
                    }) : n._e(), n._v(" "), "vi" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(327)
                        }
                    }) : n._e(), n._v(" "), "id" === o.key ? t("img", {
                        staticClass: "locale-flag",
                        attrs: {
                            alt: "",
                            src: e(328)
                        }
                    }) : n._e(), n._v("\n                    " + n._s(o.language) + "\n                ")])
                })), 0), n._v(" "), t("div", {
                    staticClass: "close-button"
                }, [n._v(n._s(n.$t("close")))])])])])
            }), o, !1, null, "40dd17ea", null);
        t.a = component.exports
    }, function(n, t, e) {
        "use strict";
        e(146), e(25);
        var o = e(131),
            r = e.n(o),
            c = e(9),
            l = e(154),
            d = e(17),
            f = e(37),
            h = {
                name: "Footer",
                props: {
                    androidDownload: {
                        type: String
                    },
                    appstore: {
                        type: String
                    },
                    googlePlayAndroidDownload: {
                        type: String
                    },
                    testflight: {
                        type: String
                    },
                    showDownload: {
                        type: Boolean,
                        default: !0
                    },
                    special: {
                        type: Boolean,
                        default: !1
                    }
                },
                mixins: [d.a],
                data: function() {
                    return {
                        walletLogo: r.a,
                        copyRightDes: c.copyRightDes,
                        jingICP: c.jingICP,
                        copyRight: c.copyRight.replace("{}", (new Date).getFullYear()),
                        huobiChina: c.hbChina2,
                        huobiChinaZH: c.hbChina1,
                        wechatHover: !1
                    }
                },
                components: {
                    Section4: l.a
                },
                computed: {
                    helpUrl: function() {
                        return "https://support.huobiwallet.io/hc/".concat(f.default.languageLower(this.$i18n.locale))
                    }
                },
                created: function() {},
                methods: {
                    onWechatHover: function(n) {
                        var t = this;
                        n ? (this.$refs.wechatQRCon.style.display = "flex", setTimeout((function() {
                            t.wechatHover = !0
                        }), 30)) : (this.wechatHover = !1, setTimeout((function() {
                            t.$refs.wechatQRCon.style.display = "none"
                        }), 300))
                    },
                    joinUs: function(n) {
                        this.reqBuriedData("H5_BottomArea", {
                            SelectContent: "该区域所有内容"
                        })
                    },
                    handleBuriedPoint: function(n) {
                        1 === n && this.reqBuriedData("H5_contactUs"), 2 === n && this.reqBuriedData("H5_help"), this.reqBuriedData("H5_BottomArea", {
                            SelectContent: "该区域所有内容"
                        })
                    }
                }
            },
            m = (e(318), e(3)),
            component = Object(m.a)(h, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    staticClass: "footer-mobile",
                    class: n.special ? "special" : ""
                }, [n.showDownload ? t("Section4", {
                    attrs: {
                        androidDownload: n.androidDownload,
                        appstore: n.appstore,
                        googlePlayAndroidDownload: n.googlePlayAndroidDownload,
                        testflight: n.testflight,
                        Entrance: "底部导航按键"
                    }
                }) : n._e(), n._v(" "), t("div", {
                    staticClass: "content"
                }, [t("img", {
                    attrs: {
                        src: n.walletLogo,
                        alt: ""
                    }
                }), n._v(" "), t("div", {
                    staticClass: "links-group"
                }, [n._l(n.$t("home.footer.linkGroup"), (function(e, o) {
                    return t("div", {
                        key: e.title,
                        staticClass: "item"
                    }, [t("span", {
                        staticClass: "title"
                    }, [n._v(n._s(e.title))]), n._v(" "), t("div", {
                        staticClass: "link-title"
                    }, [n._l(e.link, (function(o, r) {
                        return t("a", {
                            key: "c_contact" + r,
                            staticClass: "links-item",
                            attrs: {
                                href: e.url[r],
                                target: "_blank"
                            },
                            on: {
                                click: function(t) {
                                    return n.handleBuriedPoint(r)
                                }
                            }
                        }, [n._v("\n                            " + n._s(o) + "\n                        ")])
                    }))], 2)])
                })), n._v(" "), t("div", {
                    staticClass: "item"
                }, [t("span", {
                    staticClass: "title"
                }, [n._v(n._s(n.$t("home.footer.follow.title")))]), n._v(" "), t("div", {
                    staticClass: "link-title"
                }, [t("a", {
                    attrs: {
                        "data-event": "C_Twitter",
                        href: "https://twitter.com/iTokenWallet",
                        target: "_blank"
                    },
                    on: {
                        click: function(t) {
                            return n.reqBuriedData("H5_BottomArea", {
                                SelectContent: "该区域所有内容"
                            })
                        }
                    }
                }, [t("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(155)
                    }
                })]), n._v(" "), t("a", {
                    attrs: {
                        "data-event": "C_Facebook",
                        href: "https://medium.com/@iTokenWalletOfficial",
                        target: "_blank"
                    },
                    on: {
                        click: function(t) {
                            return n.reqBuriedData("H5_BottomArea", {
                                SelectContent: "该区域所有内容"
                            })
                        }
                    }
                }, [t("img", {
                    staticClass: "contact-items",
                    attrs: {
                        src: e(156)
                    }
                })])])])], 2)]), n._v(" "), t("div", {
                    staticClass: "copyright"
                }, [n._v("\n        " + n._s(n.copyRight) + "\n    ")])], 1)
            }), [], !1, null, "2de522ce", null);
        t.a = component.exports
    }, function(n, t, e) {
        n.exports = e.p + "img/googlePlay.f2cae57.svg"
    }, function(n, t, e) {
        n.exports = e.p + "img/android.1f7d35f.svg"
    }, function(n, t) {
        n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgb3BhY2l0eT0iMC4wMSIgd2lkdGg9IjE2IiBoZWlnaHQ9IjE2IiByeD0iMSIgZmlsbD0iIzIxMkQ0MyIvPgo8cmVjdCB4PSIxIiB5PSIxMy43MjgiIHdpZHRoPSIxOCIgaGVpZ2h0PSIyIiByeD0iMSIgdHJhbnNmb3JtPSJyb3RhdGUoLTQ1IDEgMTMuNzI4KSIgZmlsbD0iIzIxMkQ0MyIvPgo8cmVjdCB3aWR0aD0iMTgiIGhlaWdodD0iMiIgcng9IjEiIHRyYW5zZm9ybT0ibWF0cml4KC0wLjcwNzEwNyAtMC43MDcxMDcgLTAuNzA3MTA3IDAuNzA3MTA3IDE1LjE0MjEgMTMuNzI4KSIgZmlsbD0iIzIxMkQ0MyIvPgo8L3N2Zz4K"
    }, function(n, t, e) {
        "use strict";
        var o = {
                name: "Section4",
                components: {
                    downLoadApk: e(221).a
                },
                data: function() {
                    return {
                        isAndroid: !1,
                        androidDownloadModalVisible: !1
                    }
                },
                computed: {
                    isZH: function() {
                        return "zh" === this.$i18n.locale
                    },
                    isEN: function() {
                        return "zh" != this.$i18n.locale && "tw" != this.$i18n.locale
                    }
                },
                mounted: function() {
                    window.addEventListener("click", this.otherCloseNemu)
                },
                props: ["androidDownload", "appstore", "googlePlayAndroidDownload", "testflight", "Entrance"],
                methods: {
                    otherCloseNemu: function(n) {
                        if (this.$refs.androidDownloadList && this.androidDownloadModalVisible) {
                            if ("download_btn site_download" === n.target.className || "download_btn google_play_download" === n.target.className) return;
                            this.androidDownloadModalVisible = !1
                        }
                    },
                    onIOSClick: function(n) {
                        void 0 !== n && window.innerWidth >= 960 || (this.isAndroid = !1, this.onIosHover())
                    },
                    onIosHover: function(n) {
                        var t = this;
                        void 0 !== n && window.innerWidth < 960 || setTimeout((function() {
                            t.androidDownloadModalVisible = !0
                        }), 30)
                    },
                    onAndroidClick: function(n) {
                        void 0 !== n && window.innerWidth >= 960 || (this.isAndroid = !0, this.onAndroidHover())
                    },
                    onAndroidHover: function(n) {
                        var t = this;
                        void 0 !== n && window.innerWidth < 960 || setTimeout((function() {
                            t.androidDownloadModalVisible = !0
                        }), 30)
                    },
                    onAndroidOut: function(n) {
                        void 0 !== n && window.innerWidth < 960 || (this.androidDownloadModalVisible = !1, setTimeout((function() {}), 300))
                    },
                    closeAndroidDownloadModal: function() {
                        this.onAndroidOut()
                    }
                }
            },
            r = (e(316), e(3)),
            component = Object(r.a)(o, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", [t("div", {
                    staticClass: "section4-con-mobile",
                    class: n.isEN ? "is-en-section4-con-mobile" : ""
                }, [t("div", {
                    staticClass: "title",
                    domProps: {
                        innerHTML: n._s(n.$t("home.footer.title"))
                    }
                }), n._v(" "), t("div", {
                    staticClass: "desc",
                    class: n.isEN ? "is-en-desc-mb4" : "",
                    domProps: {
                        innerHTML: n._s(n.$t("home.footer.desc"))
                    }
                })]), n._v(" "), t("downLoadApk", {
                    ref: "androidDownloadList",
                    attrs: {
                        androidDownload: n.androidDownload,
                        appstore: n.appstore,
                        googlePlayAndroidDownload: n.googlePlayAndroidDownload,
                        testflight: n.testflight,
                        androidDownloadModalVisible: n.androidDownloadModalVisible,
                        Entrance: n.Entrance,
                        isAndroid: ""
                    },
                    on: {
                        closeAndroidDownloadModal: n.closeAndroidDownloadModal,
                        onAndroidOut: n.onAndroidOut
                    }
                })], 1)
            }), [], !1, null, "97ea575c", null);
        t.a = component.exports
    }, function(n, t, e) {
        n.exports = e.p + "img/f-web.072c8f6.svg"
    }, function(n, t) {
        n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgb3BhY2l0eT0iMC4yIiB4PSIwLjUiIHk9IjAuNSIgd2lkdGg9IjIzIiBoZWlnaHQ9IjIzIiByeD0iMTEuNSIgc3Ryb2tlPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTcuNSA3LjY4NjM4TDE2LjYyMjkgOC41MjY5MUMxNi41NDYyIDguNTg1MzggMTYuNTA5NiA4LjY4MDQgMTYuNTI0MyA4Ljc3MTc2VjE0Ljk1ODhDMTYuNTA5NiAxNS4wNTM4IDE2LjU0NjIgMTUuMTQ4OCAxNi42MjI5IDE1LjIwMzdMMTcuNDgxNyAxNi4wNDQyVjE2LjIzMDZIMTMuMTY5NFYxNi4wNTE1TDE0LjA1NzUgMTUuMTg5QzE0LjE0NTIgMTUuMTAxMyAxNC4xNDUyIDE1LjA3NTcgMTQuMTQ1MiAxNC45NDQyVjkuOTQxMkwxMS42NzQ4IDE2LjIxMjNIMTEuMzQyMkw4LjQ2NjExIDkuOTQxMlYxNC4xNDM5QzguNDQwNTMgMTQuMzE5MyA4LjUwMjY2IDE0LjQ5ODMgOC42MjY5MSAxNC42MjYyTDkuNzgxNzMgMTYuMDI1OVYxNi4yMTIzSDYuNVYxNi4wMjU5TDcuNjU0ODIgMTQuNjI2MkM3Ljc3OTA3IDE0LjQ5ODMgNy44MzM4OSAxNC4zMTkzIDcuODA0NjUgMTQuMTQzOVY5LjI4MzM5QzcuODE5MjcgOS4xNDgxNyA3Ljc2ODExIDkuMDE2NjEgNy42NjU3OCA4LjkyNTI1TDYuNjM4ODcgNy42ODYzOFY3LjVIOS44MjkyNEwxMi4yOTI0IDEyLjkwODZMMTQuNDU5NSA3LjUwMzY1SDE3LjVWNy42ODYzOFoiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPgo="
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(n, t, e) {
        var content = e(311);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("a34f4a44", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(313);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("56acd69f", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(315);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("8ef50de0", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(317);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("262d52c7", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(319);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("19cc4185", content, !0, {
            sourceMap: !1
        })
    }, , function(n, t, e) {
        var content = e(322);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("3da9011e", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        n.exports = e.p + "img/china.6d6aa96.svg"
    }, function(n, t, e) {
        var content = e(333);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("f4392a80", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(335);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("791bb370", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(337);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("7a2d06d0", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(344);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("7462a93c", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var content = e(346);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("21c03797", content, !0, {
            sourceMap: !1
        })
    }, , , , , , , , , , , , , , , , , , , , function(n, t, e) {
        "use strict";
        var o = {
                name: "downLoadApk",
                mixins: [e(17).a],
                props: {
                    androidDownload: {
                        type: String,
                        default: ""
                    },
                    appstore: {
                        type: String,
                        default: ""
                    },
                    googlePlayAndroidDownload: {
                        type: String,
                        default: ""
                    },
                    testflight: {
                        type: String,
                        default: ""
                    },
                    isAndroid: {
                        type: Boolean,
                        default: !1
                    },
                    androidDownloadModalVisible: {
                        type: Boolean,
                        default: !1
                    },
                    Entrance: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {}
                },
                methods: {
                    downloadGoogleStore: function(n) {
                        sa.trackLink(n.target, "C_To_GooglePlay"), this.reqBuriedData("H5_DownloadResults", {
                            DownloadMethod: "Google Play",
                            Entrance: this.Entrance || "顶部导航按键"
                        })
                    },
                    downloadAndroidAPK: function(n) {
                        sa.trackLink(n.target, "C_localDownAndroid", {}), location.href = this.androidDownload, this.reqBuriedData("H5_DownloadResults", {
                            DownloadMethod: "AndroidApk",
                            Entrance: this.Entrance || "顶部导航按键"
                        })
                    },
                    downloadAppstore: function() {
                        this.reqBuriedData("H5_DownloadResults", {
                            DownloadMethod: "App Store",
                            Entrance: this.Entrance || "顶部导航按键"
                        })
                    },
                    downloadTestflight: function() {
                        this.reqBuriedData("H5_DownloadResults", {
                            DownloadMethod: "TestFlight",
                            Entrance: this.Entrance || "顶部导航按键"
                        })
                    }
                }
            },
            r = (e(314), e(3)),
            component = Object(r.a)(o, (function() {
                var n = this,
                    t = n._self._c;
                return t("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: n.androidDownloadModalVisible,
                        expression: "androidDownloadModalVisible"
                    }],
                    staticClass: "dlist_section4-mobile"
                }, [t("div", {
                    ref: "androidDownloadList",
                    staticClass: "android_download_list-p4",
                    on: {
                        mouseleave: function() {
                            n.$emit("onAndroidOut")
                        }
                    }
                }, [t("div", {
                    staticClass: "download-header"
                }, [t("img", {
                    staticClass: "logo",
                    attrs: {
                        src: e(77)
                    }
                }), n._v(" "), t("div", {
                    staticClass: "close-btn",
                    on: {
                        click: function() {
                            n.$emit("closeAndroidDownloadModal")
                        }
                    }
                }, [t("img", {
                    attrs: {
                        src: e(153)
                    }
                })])]), n._v(" "), n.isAndroid ? t("div", {
                    staticClass: "android_download_con"
                }, [t("div", {
                    staticClass: "android_download_title"
                }, [n._v(n._s(n.$t("androidDownloadText")))]), n._v(" "), t("a", {
                    staticClass: "download_btn site_download",
                    attrs: {
                        href: "javascript:void(0)"
                    },
                    on: {
                        click: n.downloadAndroidAPK
                    }
                }, [t("img", {
                    attrs: {
                        src: e(152),
                        alt: "android下载"
                    }
                }), n._v(" "), t("div", [n._v(" " + n._s(n.$t("androidLocalDownloadText")))])]), n._v(" "), t("a", {
                    staticClass: "download_btn google_play_download",
                    attrs: {
                        href: n.googlePlayAndroidDownload,
                        target: "_blank"
                    },
                    on: {
                        click: n.downloadGoogleStore
                    }
                }, [t("img", {
                    attrs: {
                        src: e(151),
                        alt: "Google Play"
                    }
                }), n._v("\n        Google Play\n      ")])]) : t("div", {
                    staticClass: "android_download_con"
                }, [t("div", {
                    staticClass: "android_download_title"
                }, [n._v(n._s(n.$t("iosDownloadText")))]), n._v(" "), t("a", {
                    staticClass: "download_btn site_download",
                    attrs: {
                        href: n.appstore
                    },
                    on: {
                        click: n.downloadAppstore
                    }
                }, [t("img", {
                    attrs: {
                        src: e(244),
                        alt: "App Store"
                    }
                }), n._v(" "), t("div", [n._v(" " + n._s(n.$t("appStoreDownloadText")))])]), n._v(" "), t("a", {
                    staticClass: "download_btn google_play_download",
                    attrs: {
                        href: n.testflight,
                        target: "_blank"
                    },
                    on: {
                        click: n.downloadTestflight
                    }
                }, [t("img", {
                    staticStyle: {
                        width: "20px",
                        height: "20px"
                    },
                    attrs: {
                        src: e(249),
                        alt: "TestFlight"
                    }
                }), n._v("\n        TestFlight\n      ")])])])])
            }), [], !1, null, "4813229b", null);
        t.a = component.exports
    }, , , , , function(n, t) {
        n.exports = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTFweCIgaGVpZ2h0PSI2cHgiIHZpZXdCb3g9IjAgMCAxMSA2IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA1MSAoNTc0NjIpIC0gaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPgogICAgPHRpdGxlPmNoYW5nZTwvdGl0bGU+CiAgICA8ZGVzYz5DcmVhdGVkIHdpdGggU2tldGNoLjwvZGVzYz4KICAgIDxkZWZzPjwvZGVmcz4KICAgIDxnIGlkPSJTeW1ib2xzIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBzdHJva2UtbGluZWNhcD0icm91bmQiPgogICAgICAgIDxnIGlkPSJuYXYiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMjA0LjAwMDAwMCwgLTExLjAwMDAwMCkiIHN0cm9rZT0iI0ZGRkZGRiIgc3Ryb2tlLXdpZHRoPSIxLjUiPgogICAgICAgICAgICA8cG9seWxpbmUgaWQ9ImNoYW5nZSIgcG9pbnRzPSIxMjA1IDEyIDEyMDkuNSAxNS44NDczNDA3IDEyMTQgMTIiPjwvcG9seWxpbmU+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4="
    }, function(n, t) {
        n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOCIgaGVpZ2h0PSI1IiB2aWV3Qm94PSIwIDAgOCA1IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNNC4yODgyMyA0LjcwMDQ2QzQuMTMwODcgNC44NjM5OSAzLjg2OTEzIDQuODYzOTkgMy43MTE3NyA0LjcwMDQ2TDAuMzIxNjU0IDEuMTc3MzVDMC4wNzcxMjUgMC45MjMyMjggMC4yNTcyMiAwLjQ5OTk5OSAwLjYwOTg4NCAwLjQ5OTk5OUw3LjM5MDEyIDAuNUM3Ljc0Mjc4IDAuNSA3LjkyMjg4IDAuOTIzMjI5IDcuNjc4MzUgMS4xNzczNUw0LjI4ODIzIDQuNzAwNDZaIiBmaWxsPSIjMjUyQjI3Ii8+Cjwvc3ZnPgo="
    }, function(n) {
        n.exports = JSON.parse('{"v":"5.5.3","fr":25,"ip":0,"op":51,"w":160,"h":48,"nm":"20210924-钱包8周年标签设计-中文","ddd":0,"assets":[{"id":"image_0","w":160,"h":48,"u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAwCAYAAACWqXFuAAASQUlEQVR4Xu1deZAc1X3+Xs/szB7a2ZU2EhgdjEAyCKjCHIkAGYOwpSQQYxEbAnFhJJyKTA4LbJDKcWFE+CNliXKkVMUuSIzwCTYQhKuARFYM2CGWOYXBSjmy0SCtkLTSamd3tbuzc/RL/d7r1/P6mu45ekHOvqqtmel+/a7+3vc7u5ehBYVnN/YCnavKMD+UgHE6Bz4EsF6A97ag+ekm3h8rkGNArgLzjSSSrwOlF1juS7lmh8YabUCCrmsdB7+SA1c22s70dSfvCjBgN4OxpRkw1g1ABTwTuH2a4U5e8MQw8ocNVO6tlxXrAiDPbr5nGngx3LrfoSYNsI0sd9e9UacUCYA8+w9ZjsSTUrebLtMrELoCOQOV5VHYMBSAPHv/LSb4likTt6d2g114GtDRBlQ4+IE88OrB0BlPV3jfrUCeg69J5jZsrzWymgCUIpdvjH1qmTTYmovAPr4EyM70dnd0DPzRN8C/8TJQLMU+nOkOWrcCYSI5EIBTBT72uaVgty0FulOA6TNxk1cPvjsC80+/CxyfaN0KTbcU+wrUAqEvAMvZr65iYE/GOrJZHTC2fhxYtqDaTRgAqeYvDsC8+YexDm268davgAGsYbn1D7tb9gCQDA5TOBpjdCIT+L77Z8CS2XI83GI5NwB19tPqmZ95TABxupxUK5A3ULnAbZh4AFjJbtoHIBvn1Izv3AB8+HRnFwRCAmDFBAploItEsgVMBVDrCv7EW+B/tyPOIU63HcMKkOPayK2/QG/aAcCp0PuEsfHl5XIMhjaUgyMwv7ITeO5teXBeBsYD1wGL+rxL8dpBmDf9IIYlmm4y7hUwwe9ty22wDVsbgFL0Joj94iskep+6GTilW4pd+qtw4NAozBu+7zUuzuyD8cwt3vG81P++0gONu68CzpkD7BmAed9PGl8/ten6R2A+9Ep8agb1s+ZimNteAfpH7A3Plkp9nP94LzAy2fg8al+ZNzC+kOU25qmaDcBKdtM2AKvj6lV09snzwO5bAZQqQNkEihXwsgl+/feBw6O+XRs/vw2Y1SHPEWAZA9/5G/C//lGcQ622vXQ+2CXza/bFPnUeMK9HAJDv2FuzLn/iV0D/sG8dtu4ysNuXiXPmjY/GA8BMGsbTt8jx9g/DvOZbAmxsxSKwB6+TfZ//T04AKsA2s7m0GessKAA4JexHAPzna8EunAuMFYHJspgk//Ux8I07/W8aTXznZz3n+Jd/DNIDp6IIdrv1opZ1ZV7+oD8Aaa4/Wyv76R8G3/LfDfVZk70IfJuvBlYu8oDcBv/IpASgVQQw778ayKSBh15tjuGrM7JZ0ALgptUmQAwYazH+7dOy/XwBfHAcjABIi73tVX9G2HAF2C0XSl2RDBRLZzSv/NdAxmz1BIi1SR8NKizTbgOUP/5WILup6/lWf2AZj9wIhDBtlLl52EtdROCjPkhVINLZ8iL0sdgbjdQIYkXaEARWNSYC5l3PAiEMH2WMVEexoACgmd30+lTEeY2HPglOovbICeB4ARidBIpl8J1veyIcwkH9+cu87PfDN4MZM+rs66zHNv9xbQBajIJd+8GVTuVzBacb6FN00Vvn0JzVXexlnzxnDowHVkmx6wM+OmZvACKEXQcg1ApVdu2Hede/h26uesbOgOeN3PrlbKrELw2ObbgCGDgBfnAEGC4AEyWgLSHpnUDZnQb74Gyw5QuBpZbexTRDnSIhqx+rKs71zLjRuvN6YPzsLxu9unpdADgc4COd7KZHffuyxTOJQTIegoprAwivA+mVtMZUAsYh9EKLHe2maTx3PhuPLioE2vhMxrNTI34FAFcsAidAHR4FO/cU8RtL5sgwnCo64MRFVQCKCMhUJybQjaMxNluI7fcMVFshkbhuWVW/FOD7QYB+WN0E/O9/EqiyuIfoCypiM+XCUjH4SxY4xT+pRiSiA1SjZpdCXS+iI6Xspi0GsK5VjdZsZ14P2J+cDXbtEuB0LVtfdzS7AUgNFsrg9z0Hvv1XUzJMTyd0o55u3EHA73zGyyJL58N49EbZVS3w0Xmtbj3WsWBuEru79stP+tvxG5hbX4TQ+Xx0TtJjOVm7LjcMgZmTlU+g1DdSE3fEhLmVmdlNz01JSv2sDrB7PiZZTwecK8qhM54SGXz7HvDvvT61oldfWBdYIq+5pXMFgUaAYOUiwUiMVA7LBePXPlOGELGTj4+O7djrsVCpfWXk2WC0LFlb56O2dh3wtYztcWgWej0bIGydOPAUm4rQG+kWxtc/AcyZURt8usgl1vuvd4BXDgJdbUA68Z6lYzl8ZJc/ELau4jxbMqfqVwtyvWh6WbPuHrdV6xHH++4Sh2wRTvpedxr4nwGhYig25nc+C/6L/Y7Ljbs/KgEaZOREWhHfSjkCoJbv1HhLgVdSNIPMfwKRXtzMR+fGy0B/HsjlwV/ul7V72uXfaRngp/umzP+nD1Uo8l+5quHFMRduDr1WhB3pJpMVSu4crbCVi6WBQOxHERKfQpZrYIKGZkiZa7d7XCn6Bqs1UCGeAyz50An6V8jHC0CibgJfX5eX+UaLMsmUFm7vMRkZmdkJdu4cYEEvkDRkQkJPGoyut9jCthKVnypo5sJv9YyMJ5Orae2T0uNPYFq5WEQsIivZKxfDWHGm1KFIYadCepVfRGPlB6sW5+NvAiPFSM5bWyTqRoI1NxucykdX790O0yH16EhQ2zG4YqirWAEoohgf6PZMiT//tjAqgsJvWH4GDMqOJgBm6K9dfu9Mwbz229KKprDe/cH+OVK2+eNvSjGo3ThlGfoxgWOgfs7nTLvcULQZSJm/7z+dc6Pz5M6g4ucuIX0rIMaqdDQ/lqkFzkhYJABaa6VCb+I6CjNSlINEMxlKJI6VWqA3XGPckfqvUYlVspuH4sj9E47kv73UC74HX3J44IPGRs5fctWgk/S/JJBKCFY0b31CumJooazFEgxxzhyp31AgnQqx3d1XSYeqCiHpyrQ73ukaiK8Lo9nV9mE31aShdDRXhILOG298Xsy11SLQodvGFXsOWbN4jBC60Y992rObBPNFTCJgf3Mp2GcuBBJMimP6ZEw6an95uDotEh90g0jMupR9m1UsxZqtWCx1uRpAsAFBTKazAbEw/RZsUGgMioI1rWwZnWHn9lSNAH0TWb1EdkJrTCUc3EpdCBotjcGy1IUlHFLMLS+22imdY+Xspu0M+ERY5/WcF3rWnZc7L+Ec5h9ti+xKsZ8VsYCnGjM/+k2H6LZ3MfnSCICqkOWtxKFr8PU4c21AWj41X2szirPalcGtWK2edQ2rKyxYK0mjVbFlvc9WumCoXQrHxeKIFkkHZ1np9moG9CwHic+IRYjgq89y1qa8wY9903FM1PvUeR7xpGd3YM8ReY3FCEIPCnGmRrV8CZBiMWv48HQdVFTWWDvickSqpgNEuHVIf65VlMFEzLnjf0P7MElvb2GeoHBEtzwUl2qD8dpfOUJo5Hjm//JyJN1PrAK1sWM1MLvLsSj8qT2eVHwlZt27UzGAzQrKEnQzZcCyR00QIGPGICcypWzRzVFgp3ZV9MEt8imysmJx6A2Xm2a+nRhAzF0LAJxYNiDX0K+zpo2baDMIrCVCcTz7j70mSkNNtlW9nETfY39e/W35++oBoK8IJx3v2u8Avx109kVi1u0g1Y0NSy8MYsrAeVtGDlu3zAaAtCALwDmnyOwSGtM136qGtVz5csp90ozx4EhSjeBPrOc+xmXcRB2DgcpClY7VunDcRXNhfPt6LwBf2BfNAHEDWLX0H3thfuFpx9yEK+b2y4Qv0eEgJb/d3cuBPUel/0+lG83LRM/uIJZSVrQrhcl2AVlsalvM5PrR8uUYsSJZ5z6WbdSbpDZODFEI1LK8o46v0XrqASUBwFL2qxsNsHsabcxxHUU+fnSzB4CCLW54pKbuxVadC7bhI15fFDHc9d+LbMA0PQ+f/DnS49itF8uxkWjV3CJhBoVuHNQ7ttjEpGakNWKU1TsPd331nLCVEU1iuLyvJf5A0t9+vlbEbj3l2Dj4pp+KBFSzrQNmZw8qXTJJkl16BviHZaq4p+wbQuXZX9uHE2PyQRpWLMAoTYKXJpEoFWBYx5tdHGEkCDdMu/QtPvGW45kJ0b6KDIwUbDeQOyO6Fc936Oyq2Lzp+VEDYdGRlnQS3IgQv7kv0UsvZWklCxpfuwa4YiHKQ0lUjgDlnARj+QjAByswi8m6psfoQSRX7LiiP9JJjxNbz1elJuVrO9jxQ+LTPDGE9GQBBNrE2LAAa1tey8sLGokVe3Uo9SpJ9uBwlY01g8LxPEbQ8bpmDmDlYrDutMhqaenD+JQaZ82nXuOl3in41H84kVu/RtwndVIaI42xoNmVQWn2ApgzT0Wxuwds/nzwUpsEDeX3+SUeNDmLIACqZt3ny8yZc5EuVQrFkYH27okC2gYPoVSZRHJoAKnJiABtcvz/Xy8/fuo8/N7hdwT7OQBYDwsKwM1dDLNrJiZPPxtoa4cfS8W9yDrIFAPqfbpBKFjYBUR5zPuKnLZj74qmuo4eAh8fRnpoAKw0ic7jEdgz7omfpO2/dsky/PL3L7v3s19k3gfT1Zx8H1BKtaHccypK886yASflnJfdmgZiFMYsA7wI8AnAHJMjLxT970rRB1wlLT8i2V1lRqOnCsRywHvDSowjM2CJ96FDmDEyDc6w/XB4wUK89JGrMNA3K7f2DrZQrx/8cqJUspdAN7bkD8BnfUCwXGCJApqwUVrnbQCXAXPYAhjZHBMALwB8FKiUqsOuMMC0WI2e3DQpXmz9pnNUTEvTMEVd+YQnfVLhjPRH+akKm1X9nrDeDNLVCRSkvYS2Hv8UypIBJI8fQcfYKNLHDqFzdASp8ROCPZPF2N40EHFlp74aAe/Ni5fi3Xnz6Q7kCwwX3HYHc7xZ33efT1z+5Orxi/5wW03Q1TOfEIDycaByjDJYJNDMowDXQObXlXqRlhuAVLesGSgKhErMKgAKYBKBWwDUwSjPcQlmq3MFWNUeHU72cbA2+Q8pqKRmyuXsmOUP0PShfUiVK7/T4Cyn0vjtuedj/8IzBPBUMYGb/uILzPPIX+ALKgfXVzaCt8g36EKQDbgj0cBWLwCDWFBnQB2A9F1nQfpus6oFQjcABfA1cLqBmsxwGCmgy3rhK4GzmOLo1ES+Pq+OwQEkJsfRfVhmgncMHER7sXhS6JxjmQz6zzzbAzo1P87h0Pv0edd8RW9NENYjdpU4PQSY+8PZLSq5ire5KTFLjGUDwl8MKxDpLKgMFQKdzoJuACrA6gzoB0I/pqR6+nWpXsmQyT6GZAcwwwJl0hLx7vmnTA4F0M78EBKFMSTyA0gVSwKkqRPDUybiCWyjvX0Y7puN/Nws9p92CibTVfVMn6dYzxrgo/OhLyk/9sXyqpLBH0khQaZudJeKBbrKHqm3hYnUqKDT69USw/WyYBAAqT9dfAu2tFYtjAX1eu7rgtpJZ4BkB0dnhwRnYgZHhyXa9bnraoY6nhodRtsJ8dIppMfky5468jJ2PqPCwCcti826oHNY1h3vcf5Dq7HOTnF8olcqwEdn9mCiswuTPbNs3VkHmvu9onSOdL4KcJuf2NXnEQpAqjz0OZ7lGTzHOQ99caU5CJgtZrogcOoAlAzlZEF1TDdGFEMpK7eWHmi3WUMMizqWPhmkL0YFom4cVZm9OvuU9Xx8aibQbb2uposen7GqlH0WquITkPKz8P2O6ZJCroWzg+q6Oo9zht0TDNe5DQ6/+xgJgOrCWiKZgEdsZx6vq8kgbEU6HgZAP2vYLYaDrOGoeqAOQPf3MOBR/SA2Vec8uqcCmysSlOgFuhNkCMkKOkAbBaEbgG4QugFoMuRNjq26ny/sRtaNFmJDM2OSgSKevnkvgKdPqh5rmNwxfnpgEAsG6YG1gOPHYu76Qb+DGDQKCIuuO0kuIb1kuoGE5f/sTQOG5moiQynJSdVwXmOvlXZYZ8Gqh0ECb+QAttyxhUm5HrHUDUDVLgGxtBtXlgf5OjD2nv0HpXoAKBnKC0IFQAEMzTcod7w0GGrpgTrzxSmGbbYMYEEdhG4Aen5rd17pk6l2jo5uJyQ6ZsjOkj5u4L4+PG+m8EIjwFM4ahiAOsAVGIuD4t+1ns8Z6YosVF+MuElqVmtGDOt6IHWiO6WVURLmjlFspjOfHwu6rWf3b70dCXw5bennrH5Xm0RsChfLhbGgDkLdzaq3427D6ifPGYjZdpcZ3uHA7vOz2F4v2/ndyP8DpgsP9mQzMBIAAAAASUVORK5CYII=","e":1}],"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"中文.png","cl":"png","td":1,"refId":"image_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[80,24,0],"ix":2},"a":{"a":0,"k":[80,24,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":1500,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":4,"nm":"形状图层 1","tt":1,"sr":1,"ks":{"o":{"a":0,"k":23,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.388,"y":1},"o":{"x":0.333,"y":0},"t":0,"s":[-28.037,24.126,0],"e":[171.963,24.126,0],"to":[33.333,0,0],"ti":[-33.333,0,0]},{"t":24}],"ix":2},"a":{"a":0,"k":[-49.912,1.501,0],"ix":1},"s":{"a":0,"k":[102.28,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[34.336,-28.126],[10.963,28.126],[-10.963,28.126],[12.411,-28.126]],"c":true},"ix":2},"nm":"路径 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"fl","c":{"a":0,"k":[1,1,1,1],"ix":4},"o":{"a":0,"k":100,"ix":5},"r":1,"bm":0,"nm":"填充 1","mn":"ADBE Vector Graphic - Fill","hd":false},{"ty":"tr","p":{"a":0,"k":[-49.912,1.501],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"变换"}],"nm":"矩形 1","np":3,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":1500,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":2,"nm":"中文.png","cl":"png","refId":"image_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[80,24,0],"ix":2},"a":{"a":0,"k":[80,24,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":1500,"st":0,"bm":0}],"markers":[]}')
    }, function(n) {
        n.exports = JSON.parse('{"v":"5.5.3","fr":25,"ip":0,"op":51,"w":186,"h":48,"nm":"20210924-钱包8周年标签设计-英文","ddd":0,"assets":[{"id":"image_0","w":186,"h":48,"u":"","p":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALoAAAAwCAYAAACmJWBPAAATS0lEQVR4Xu1dC5AcxXn+enb3nrqHhHTGCMmLkQokgbElOzJQJhIBEgUSZGNcxsSWEGVwigoCV8SFKmMfoVKJJFdFSpXjB45BRYxlCEb4ARUpQYFEDjIhglQsipIsr3WckXSK7m7vubc706m/e3q257U7u7ezh8ROlXR3Oz09/fj6+7///3tmGWpw8HRfN9B6cwH8IwmwD3CwDwOsG+DdNai+UcV7awQyDCxjwnwjCXYIsF5imQczMx0CVm0FEtztmzmwhoOvqbaexnWNESg3Agx4nYHvmAnoKwa6ArgF3Ndg7HJT1Dgfwwg8bsB8uFKWrwjoPL39aw2AxzB1jSorGwEGGJz1scyWh6NeGAnoPP3XaY7Esxz4cNSKG+UaI1CHEcgYMNdGYfeyQOfprRssGDtilynvmwP8ziKw5gRQ4OD9w8BrA3UYq8YtzvIRGOLgm5KZ3j2l+lES6FKq8L7YBqKrGWzjKrD1K4DFXe7bcA4MToDvfgP8mweBaTO2ZjQqPstHIIKUCQV63CBnf7oa7EurgTlN/lEmkFvaxwNZWLf8I3Bm8iyfkUbzYxuBMmAPBHohvXU9A3s2lkbNa4XxtzcB16Rl9RYvD3Qq8Z/HYW14OpYmNSo9R0ZAgJ1vZJneXd4e+YBOjqeF5KFYNDmB/InPAMt7iu3wAt3L5lqLrc8/BRzsP0dmpdGNmEZgyIC50uug+oBuprf9GoBNt7VtirHr1iKT61UT2PMWkCsA7Sm3bFHlLA7+T/8L/pW9tW1Uo7ZzbgQowWRkHviI3jEX0OPU5eyOVWBfWeseVIMBb2dhPfA88Eo/QCrmwk4Y3/4ksHS+X9ocGoB12w/PuYlpdKj2I2CBP5zK9DqBFAfoUrIkiM1rf5Bkee4LAIUQ6TAtgCTKb0dh3f5D4OSY+54XnwfjZxv87TjY39DptZ+dc7XGIQMTH2SZvmHqoAN0M73tMQAb4+g1+/RlYI9cL0OE9K9gAXkT1q1P+kFuN8D497uBBe3yL1oUjIH/61Hwe34cRxMbdZ6DI6CzugB6rGxOq+kbfwy2ciEwVQAmpoFsDvxXZ8L1NsmXfXf6hp4/uBd8zy9nd0o6m8FWLxYSC53Noi8kv/jB4/L3s+WgftxyGTCaE75P3Q+6/x2r5G0PD4LvOxJHExxWt4FO2U/2eBx3ojqNH90uiZni4EOTNjhGwB97LfCWrPd3wTau9J2z1jwaagHiartT74WdYJuvBrthqQR4wMG/9xr4zgPvfsBTGO6lu4BFMknHdxwA3/nz2IfQdYMrF8F48rOx31+xugC6ld52KLZ9LAxgj34KODEGnB4X2U6MT4sIC0kRb8ZTJJLuvcrP5s/8ctYiLuz6pWBfXxcKcFdjD5+CddvudzfYu5phvH6v02yxQB95sa5AF2P6nfUS6FteiM2qMPD9Rqb3Wha3bKGOEEPj1JgAOz8zAUzmgVQCbF4b+MAI0NEMtmQ+2A1LgI8tlAPOtIAQZUY3Pi0kQt2P1Ytg7JbMIyaFQLH3SDGeTyb4hqVycc4mQ1YyMMToxKYfXwT0j8D63O66jy3bfBXYfVeLVluf3R1ffkQkkSbmMrlpKz7ZIjB7/VIJkpOjwLIF4m+24n0C4L7DsD/RgG79yVOzs8GLfAUChAJwKeahsuRA05HNwbri7yqB3uyUJT9jNsiDMPHQWrBNH5VAv3EXcPhUPGOgsqX59LYdBrA5nrvYtZK+/aNlYDddClw0NzghpDdAgX08D/5X/zZrDigxDjGPWKQRdKzxA5slafI+8W0/iFYvkuyvZYb54VPgj/2Xv+zyHrDrl8h7PyOdReEjXNglF9Ldz4oMs1Nm31EgOwX26cvBVi9yFpxIsgU4eqpfGMhK2aA7hxQsCPKfaB7JgaVDXafmjc7RvZf1FCUe1bPviF+W6BaFxuqi7bHCz4K1k1np7ftjfRSOYuhf/T3g95fKMKG+WSusewT0kRz4nsPg3z80a6xjvGw7bGTer/lO+ckgJ1U5qjpTEttv/0MpFUIO/pcvusDlMu2PvAhj89UuAJHF0MsQWMMcZW/d0DX63qNy0RD4SLfb7RcWSY8ika+1bR0oVCwWn2bddEII7J7Xb6F7/XSD3ApSB+vHwPewOFP+1BHjGzcD58+JDnLS7wd+A/7qANCWBNqbwP/+lfpv09W0uWDFLS+UB3pICWfB0PlXjsMi9iWGXtbjAEdMOFkBG1y6aRef6ZEeAs5Nu1zAExX2j4ArZifmtSWXD0w0L3ZCznFEPUD26WZdmmkL3wVydf83TwELbfZXsk9fyPqiovGIP9udIaAHbB+sek6LF1J2k5w42rtCRykmJ3DTgxbHRyTA6SCQz2sDe38H+H9kYvPKw3oqtix89VrJXnftqTrOK5Jl29fJegLkD51TLOmAy2PaxbUEFJIwBHrS1gPZokNJBYiZtzxfZGFi7ZfvLjK0LqX00J4GQFdbPcAMZHPdMhD4b9rltgL6fXSyCLIoNYBciSqG4gE6rf4f3AbMb/MzOSUo6GGKX/QDb52WWVLSh5e/X05gWwpoSclIDGVGlSmlkB0dSgaE9YqYccvzcr8MrS8yy9mcSE6QaaeISVj8Xq8yEIDVToZILrUEOlyB0QfdtCuQezWzp4zPJyjB0KGLWGdtJWnUmCun3CvjaH6E3zDll5jUxmNb5KjpzB1kUaod2yjX0VjEwejGv9wJXNDhY3L+0jHBTL69LXZjRTTmxkuA1hTQ2STB0dYEtCRhrX9CXKezTmAf9x4V7C9itGTiyaOnpBWZ6uU9kdlZLBQKd4Y5llEGWC9jhyGhOWuM+rdsgSMxnOiDbtrD/INy5t8LdI3RQ0N7eiJJ084upg+LPJGjTZpbc7T1v12x+hCLUumQRi4vgb59qJZ7z0XC58+uLLbBliz80V9Eyr4JJqXBsgGOpAE0JWBtekaGGDWHT4CRwEtmVkUWiL0fulYsCGdwNabyOVkho1UzoBPAKVqyyU53l5gdp21RTHu5MmGRDfr8W9oi1p3OoMVBEkllUQMWnSCnh9YW/YGQ/umyzbVwZiALKwR6DfefE6Cevh3k1euaXDB5xM1YYqF8YSXQlASSDEjIWKNIavzPiWLfOpthvCGze16zrZw/ERl45biM25PersDx0aVLJI2um2NNjypL4pjvfUfBKOzWPyItDbXLG32IYtrLldGljQ7QMqE9L3tTGx0fw8PmLutKfaIw5ZunnL6xKxcXw7MaoOuWLCqiJcOs9NZnOZjMxc7wENpvyyd8jqf1B9+LHCJ0niW1AQ47pm6t/a5L8jgpZC/LaADwdscXZivRX5eOjRB10QGtFp4LNCF1iMVKVkqTWYhi2suVCdPHujzR76nGQrMUZBEZhURpIXrHWa8nKLsa5iOUkFQzhF/o5bQNgNUyYSQ2b126wA301wYq2kMumHTdJcVGE9Bp3/p1/+DqiGJcb+jPYQuKThw+Ka/5+GLJ/JVk4MhiUKbTdoZL7ccQUsmWJroWdWX/AtLcrtCcZm2imPayUaEwaRO2ANToenR6aP+1hSYiPuT06wdZ959t9Ed96pwsEvNOCaOabQFoSsB49R5Haqg+R9XmojzV8c+bivvQ7UpE4sjzCJ2SJ954r8pOOsBU8fCoSR99sjatgvGQDDHSIUzzwX5hmoUjuaIH7FMrivrUw5Au+aNvnArQ7fqCjWLay5YJ2x2o+Sth+QFXDJ86HjR2uuWkfhPQKUkWsPdHgE1lP72WIEoibiZUr7YA0LsULbQNzaQucS11/KnP+arh331VxI+jHOyLHxOOm/ewbn4C+NX/FT9Wg+zNqulOpx1lCGP+KO2hMr5JD7lQgIZ2AOrZRM+GMHFOxcGpnr1HnciO46x5Tbs3QykaVcKhtNvn2h2ox8QjbI/1RrYCrRlZjJ9scDuhNtCFFSAfZDTnlz3lLErUiYlaTgDdvMjepluDbQCrFkI8/Ow5IjuiYQvlhbd8WUkxEfdeBU7sqmUsnQjAm4OOKRUMv7ATFpWr8g0C4n63rHAkkNNFWx5ZO34eWrdgXj1LaTMkxfIpUuTsyX5kv4wcKaDb+1UCtx5EKKPGSLCp3ncC+lY7gaXu6Z00BWL6fDTnhGh9k6ue79Xf6mA7pbR/R0SbqB/afIjtB7RAyEJ65i8qdisppx6UFkDPp7f2GWBfq6QCX1nKhD73+cAqrM88WXJ3Gr2pi/Ve49/NSIN86/cjO7Izan/Uiyn5s7ALoO3Flez8U2B4e+TdvVc96jjo5YjBKT9Q6ZhUc69KrtHe82I/YUTypf3XM4qnk74+8CWZ7PEeg+Pg214Gf+Et95kPnQ+DtmpeJxMzPmuw8wD4o6+6PuapZlhNzeBt8ukYq93zKrsyA2GMy7CeuHZ6AolCHsZ0Dix/Fj0GV8lkv5fLKtmSeTDjPN1QC1b3RUy8g3xiVOzREMfibp/TiZyJwnAS1jBgHR7F1J4MWMc8sFQr8m3tYM32w9IzmDxLvFOjeFjavvfE1Lg4kRw5LX7y0TPg0xPi99bRLGiR0OJITYw1FsYM5qCOlz6eyDxwB91Pe91FDVi9hHxxdS5nIv9OAuZJBmvYgDkImGcgfq/HoYNdBzrdu8CC97iZAS/v45Oj4OMjwiJ0jI2KRZEalJvSmkeHkBifhSei6jGAZ8M9NDZ3AZ3+qAmrU2bzHm0LgAbq/BGjroAOm49SrB4G9iCg5/XH/Tw3K9hrtmUs6yyGOWdOopAbR2t2GMhNoG1o8GyAzNnXRkav9OR9qUyv80UBPp6a6YPSQkPftw758y8WTJ0/Vh+WjjobfNpmbJtsc54X9ObLNNe038Hk3E+pqRb3UCqg6+0qeGSTOtd+8m1hFYzhE2ianGgshKiTGVBuurkZRy9ZcezyH193sX66Ji8ZJXBPpy/D9MKLUeiaXxMtXU1fBYhtAPMsgzUO8CwHl9IblpTb8nebjRVTq7evW7Z00c/rW+mpvLeMAjAzGHgrh9Em72G0MbBWubCsuUCqRX6etDd2BvWxkHBPCRsbQmd2zLUQUtkzSOamGhZBDSADTlywCEeu+CgyS5cMcWDlHfcz1zfZBb42Okq2VAe32fOBanBZ9TUK0F4w60COUjmBWZckBHYFYrUY1HkFdh3oqozO1KZmEUx7MdG1VK9S/+rzRBuHMUdOQbJTtrilW5YSi6LbPT3TAbNFvoA1MYJUPo+uwZPCIrwnFoIN7oEPLsWR5Ssw1SxZxALWf/HL7Dnv/Id+EUCYXi8sWITJFVeiXuDWQW2+I9m5UkDrnWZgUJCrhtUd4HuYvxTY1SIJAruqTzjBtDA4F9aGMy42gNK6YfZbtpvnyZ6kzpPT1mEvDtW/INnFp8bRkZtGYuQ0UmNZYQnmjI87i6FpPIvk9Ls/tEqS5Mz8HgzP78Fvl1yKU/PnYboIbjkEefTd2csCv8Cr5Fe76GAnaZJLL48d4ArY5jtMyA7S+XEdXqDTfXRWjyJfFKuLaw2AW1z8FH9rjC7LSbam/9U53aLoYKc6dMlkkWSiRSp+0j960ly8/4bNOU/+6l0ILZ6vM86HzHZyUmq79qFBYRnUgmiyOFj2NNomp8QCSVoWmka0rRg1nhgCc6GtE9nubgx3dmK8swsTHV0YJYB3uVd1QeuLGKcSIBfDVK6t9O0Xozfe9ZjV3h3bt0ATuPnbDMTY1mCRccu1rRbnayVfqC2K1cPkiwS/BKUCuvxd9kQPbeqsLheJG+jqM3DOTUOuKLJUzuKy79OsyZ/UAi4kUbftOCfmukcwH/Bgr6m2S3sGO2FaaJ2cBMbFy2qdo306DzPneTuy59rRlhbkW6UjM9UuvfvJjk6XjNQv0UHt/ZwxDFkc92/6MvN9y4VetizQqfDQX/A0t7Cf1/ALAnRwx8na5RZDNfJFgTPIKRUOaQir64yugz0q0AW4UfQrCPwK6EqO6QuI7mdqXObcR/Mjki0czPYT5nbKhYAOCYtySecgCxEUhg36LCgqFVROEkDwLJrAf3MDt3gdz6DSkYCuLjz15+bfJAyjtxx4Sp3npzkKb6EqSaLr65m0wXttrVh9pjpdTqodpdF0ugC4PVOB8oWuM7RXgDPmcqoV2F0yyeU0yxFxy6jiKHXZzJ+0d1sk5wKdCXm+yWPnw8Dq/TwI6N42hLG6aWDInMbOMD0+Y6Ardrcsqw8wAt7UHw4/6xiENJlN9g5rXRCrR4m+SAAWgSmAqsXKda2uO6RUTtfp+gSXky/KEjj1kVZnjBGQvKyu2jZToOuM6vrdXixJ+4sFW+2wqfpJn7fabx1M2fmH1tbiLFTK6grg2UnsvL+PuTVTGeariNH1ukjOmCbWMPDNYCz0G6UJ4IWjHHyivtq7UsbXWT1KTN0bfZGgZ4FA94EzINQY5JQSmFX0xcvqxbCnBLpuDbw6XdzfJvwg+eIKsTr+ggZIDSVBQNfHOheAqGmb/VU5qiPJgaaA/XipgO1MTW3Yf+EFeKkagKt7Vg10P+jNNRZnlyaZsRoMaes0T1crUfS645Ir3oVQrXzxsrpicV2nK6CLsiExdR/Q7Qbq0Zcg+SLrrB+re/Wyl5WjAF0uStnBAvGf6isDsfQwZ3i9wPEblsDrH7oCz1XK3kEk9/+JK34B0H6UAgAAAABJRU5ErkJggg==","e":1}],"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"英文.png","cl":"png","td":1,"refId":"image_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[93,24,0],"ix":2},"a":{"a":0,"k":[93,24,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":1500,"st":0,"bm":0},{"ddd":0,"ind":2,"ty":4,"nm":"形状图层 1","tt":1,"sr":1,"ks":{"o":{"a":0,"k":23,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.388,"y":1},"o":{"x":0.333,"y":0},"t":0,"s":[-28.037,24.126,0],"e":[190.963,24.126,0],"to":[36.5,0,0],"ti":[-36.5,0,0]},{"t":25}],"ix":2},"a":{"a":0,"k":[-49.912,1.501,0],"ix":1},"s":{"a":0,"k":[102.28,100,100],"ix":6}},"ao":0,"shapes":[{"ty":"gr","it":[{"ind":0,"ty":"sh","ix":1,"ks":{"a":0,"k":{"i":[[0,0],[0,0],[0,0],[0,0]],"o":[[0,0],[0,0],[0,0],[0,0]],"v":[[34.336,-28.126],[10.963,28.126],[-10.963,28.126],[12.411,-28.126]],"c":true},"ix":2},"nm":"路径 1","mn":"ADBE Vector Shape - Group","hd":false},{"ty":"fl","c":{"a":0,"k":[1,1,1,1],"ix":4},"o":{"a":0,"k":100,"ix":5},"r":1,"bm":0,"nm":"填充 1","mn":"ADBE Vector Graphic - Fill","hd":false},{"ty":"tr","p":{"a":0,"k":[-49.912,1.501],"ix":2},"a":{"a":0,"k":[0,0],"ix":1},"s":{"a":0,"k":[100,100],"ix":3},"r":{"a":0,"k":0,"ix":6},"o":{"a":0,"k":100,"ix":7},"sk":{"a":0,"k":0,"ix":4},"sa":{"a":0,"k":0,"ix":5},"nm":"变换"}],"nm":"矩形 1","np":3,"cix":2,"bm":0,"ix":1,"mn":"ADBE Vector Group","hd":false}],"ip":0,"op":1500,"st":0,"bm":0},{"ddd":0,"ind":3,"ty":2,"nm":"英文.png","cl":"png","refId":"image_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[93,24,0],"ix":2},"a":{"a":0,"k":[93,24,0],"ix":1},"s":{"a":0,"k":[100,100,100],"ix":6}},"ao":0,"ip":0,"op":1500,"st":0,"bm":0}],"markers":[]}')
    }, function(n, t, e) {
        n.exports = e.p + "img/h5-8th-logo.73c4c5c.png"
    }, , , , , , , , , , function(n, t, e) {
        "use strict";
        var o = e(2),
            r = (e(31), e(20), e(1)),
            c = e(0),
            l = window.__NUXT__;

        function d() {
            if (!this._hydrated) return this.$fetch()
        }

        function f() {
            if ((n = this).$vnode && n.$vnode.elm && n.$vnode.elm.dataset && n.$vnode.elm.dataset.fetchKey) {
                var n;
                this._hydrated = !0, this._fetchKey = this.$vnode.elm.dataset.fetchKey;
                var data = l.fetch[this._fetchKey];
                if (data && data._error) this.$fetchState.error = data._error;
                else
                    for (var t in data) r.a.set(this.$data, t, data[t])
            }
        }

        function h() {
            var n = this;
            return this._fetchPromise || (this._fetchPromise = m.call(this).then((function() {
                delete n._fetchPromise
            }))), this._fetchPromise
        }

        function m() {
            return x.apply(this, arguments)
        }

        function x() {
            return (x = Object(o.a)(regeneratorRuntime.mark((function n() {
                var t, e, o, r = this;
                return regeneratorRuntime.wrap((function(n) {
                    for (;;) switch (n.prev = n.next) {
                        case 0:
                            return this.$nuxt.nbFetching++, this.$fetchState.pending = !0, this.$fetchState.error = null, this._hydrated = !1, t = null, e = Date.now(), n.prev = 6, n.next = 9, this.$options.fetch.call(this);
                        case 9:
                            n.next = 15;
                            break;
                        case 11:
                            n.prev = 11, n.t0 = n.catch(6), t = Object(c.p)(n.t0);
                        case 15:
                            if (!((o = this._fetchDelay - (Date.now() - e)) > 0)) {
                                n.next = 19;
                                break
                            }
                            return n.next = 19, new Promise((function(n) {
                                return setTimeout(n, o)
                            }));
                        case 19:
                            this.$fetchState.error = t, this.$fetchState.pending = !1, this.$fetchState.timestamp = Date.now(), this.$nextTick((function() {
                                return r.$nuxt.nbFetching--
                            }));
                        case 23:
                        case "end":
                            return n.stop()
                    }
                }), n, this, [
                    [6, 11]
                ])
            })))).apply(this, arguments)
        }
        t.a = {
            beforeCreate: function() {
                Object(c.l)(this) && (this._fetchDelay = "number" == typeof this.$options.fetchDelay ? this.$options.fetchDelay : 200, r.a.util.defineReactive(this, "$fetchState", {
                    pending: !1,
                    error: null,
                    timestamp: Date.now()
                }), this.$fetch = h.bind(this), Object(c.a)(this, "created", f), Object(c.a)(this, "beforeMount", d))
            }
        }
    }, , function(n, t, e) {
        n.exports = e.p + "img/close.2850a88.svg"
    }, function(n, t, e) {
        n.exports = e.p + "img/qr.81bc0a5.png"
    }, function(n, t, e) {
        n.exports = e.p + "img/appstore.bf68d0e.svg"
    }, , function(n, t) {
        n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAGDSURBVHgB7ZmLbYMwEECPqgNkhIyQEbJJM0I3CBu0G4RN6AaMwAjtBtezMGqDDOcPdnzRPclSRGzfPQWbCwZQlCpoIDOIeHZdb5rmCzJSQgxd10ksa+wXeFJUTBoqJg0Vk4aKSUPFpKFi0lAxaaiYNKLE6E/xidoHZIZiXE0sKAEFOlL7xokbtQPT3wkz5mDnRhvrCDmxUuMix2FLLlTMSg2L7mM2uRUpNnCIWGyMVLEet3EG9hVjpGZusDfovkVccqfFOFYMp81oZObukVnPqYIdk4BZ7Od//TfFTF/824zW6KAEFKhFnjdOzPRBnhZK4il3jfzuMVKBcrG8wyOhBC64L2a9XaAGcNrVuA3AV6pMCeUL+j2Hthgxd+kUS4LcWK3UTITcUL3UDPpVKYYec1YTucDtKqWDUqxlAAmg+1nXQgLBeQYP8E+k3UvKzsfm+QoFoHP01sb9oc+fUIC7k/u1Xyf3CX8oPnnqWyppeK2xPTaQ0uitKA0Vk8bTiilKJfwCTjWYCAlhWKMAAAAASUVORK5CYII="
    }, function(n, t, e) {
        n.exports = e.p + "img/qr_cn.ebe55fb.png"
    }, function(n, t, e) {
        n.exports = e.p + "img/qr_en.ebe55fb.png"
    }, function(n, t) {
        n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALXSURBVHgBxVmBldowDBU3QUbIBs0GzW1wG1w2ODYgneDoBGEDrhOYTsB1AtMJjg1Uiyi9IGTHCtD+93QcjiR/S7ZlhwXMBCLW4aMK8pU/CxbCMciB5VeQ3WKx2MG9EUgVQVZBPtAOH6QLUsKtwcRe8XbobkY0OHrGeRGbgg/SwDXAdNQ+OBINd6Y9p2cbTA/wFazAPqUO4yNfks5I32t6wmdsIITt2F8OwS3qEVlG9PeKvovothGSLpfcayRqZcLGWTokX6hHM51u7NNgIsd2WwvBCZLPFoNJcmy7UTrqMuy0Pmkq/Z2PDyP9VZBS+HgMFeAAdwL7foS+8gwomMsneCQSLWQi6K4V+7XBXls4pygOEVwJm0MYXQv5OGa2qeC+DqL5tGMMBGvx8Bv8e3wX319Of0MoazlJwQjUV39j9FHgZcWpKYK10P0J/wEhzTQlfojmigh+EY1vcBtkz8ERduJ7rZWpGgzg1Hi2JV+O//doqa+9r0pw8aDk3ep0yXZPo7YnbmvBAB7s+XoQDWh0OFQCpzzbY2YlEnZneIAZ4JFSYacjVQmfd5ExjvyMSHY49wRtSTGm7yRaiiU6TJ+K1BR70VgZiY3hUD8bSqw0oni5SPaU4nehV0li0KeyBT2VA95Gz6e2qjaIU4jK4Pwer8IBHdqulw71qMfOexKegwDc9xitWuowj1j0CiCItpgHj0qpG5xYr5UODasS+2g6tMHPGWVW1BJE6VDhM/vqxoZFhoHtahgnSdHcZPRXSsN1RNGjsT5nEk1Fs9MMtPMYoYI7AS8X6BCQMmawNBlcRy62DTVThut7k0yQy7toYXxLWMGVCD5eUJ9Ke4uTqZdHDRjA/pYYXxQO5+wQGF/ZiOev3yo8f9tVcFvDOqlCkH1/jpG0bK4WXLXpS5K5m2suKDNXb/opoh7toIi1VmILmAnsqwsJXVtLOD/6H1norEn37Pe5P0P8AViOELtBth7/AAAAAElFTkSuQmCC"
    }, function(n, t, e) {
        n.exports = e(251)
    }, function(n, t, e) {
        "use strict";
        e.r(t),
            function(n) {
                e(68), e(19), e(69);
                var t = e(11),
                    o = e(2),
                    r = (e(168), e(261), e(269), e(271), e(31), e(58), e(24), e(16), e(70), e(62), e(71), e(72), e(20), e(73), e(1)),
                    c = e(222),
                    l = e(141),
                    d = e(0),
                    f = e(36),
                    h = e(240),
                    m = e(113);

                function x(n, t) {
                    var e = "undefined" != typeof Symbol && n[Symbol.iterator] || n["@@iterator"];
                    if (!e) {
                        if (Array.isArray(n) || (e = function(n, t) {
                                if (!n) return;
                                if ("string" == typeof n) return w(n, t);
                                var e = Object.prototype.toString.call(n).slice(8, -1);
                                "Object" === e && n.constructor && (e = n.constructor.name);
                                if ("Map" === e || "Set" === e) return Array.from(n);
                                if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)) return w(n, t)
                            }(n)) || t && n && "number" == typeof n.length) {
                            e && (n = e);
                            var i = 0,
                                o = function() {};
                            return {
                                s: o,
                                n: function() {
                                    return i >= n.length ? {
                                        done: !0
                                    } : {
                                        done: !1,
                                        value: n[i++]
                                    }
                                },
                                e: function(n) {
                                    throw n
                                },
                                f: o
                            }
                        }
                        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                    }
                    var r, c = !0,
                        l = !1;
                    return {
                        s: function() {
                            e = e.call(n)
                        },
                        n: function() {
                            var n = e.next();
                            return c = n.done, n
                        },
                        e: function(n) {
                            l = !0, r = n
                        },
                        f: function() {
                            try {
                                c || null == e.return || e.return()
                            } finally {
                                if (l) throw r
                            }
                        }
                    }
                }

                function w(n, t) {
                    (null == t || t > n.length) && (t = n.length);
                    for (var i = 0, e = new Array(t); i < t; i++) e[i] = n[i];
                    return e
                }
                r.a.__nuxt__fetch__mixin__ || (r.a.mixin(h.a), r.a.__nuxt__fetch__mixin__ = !0), r.a.component(m.a.name, m.a), r.a.component("NLink", m.a), n.fetch || (n.fetch = c.a);
                var v, y, k = [],
                    A = window.__NUXT__ || {},
                    C = A.config || {};
                C._app && (e.p = Object(d.v)(C._app.cdnURL, C._app.assetsPath)), Object.assign(r.a.config, {
                    silent: !0,
                    performance: !1
                });
                var j = r.a.config.errorHandler || console.error;

                function D(n, t, e) {
                    for (var o = function(component) {
                            var n = function(component, n) {
                                if (!component || !component.options || !component.options[n]) return {};
                                var option = component.options[n];
                                if ("function" == typeof option) {
                                    for (var t = arguments.length, e = new Array(t > 2 ? t - 2 : 0), o = 2; o < t; o++) e[o - 2] = arguments[o];
                                    return option.apply(void 0, e)
                                }
                                return option
                            }(component, "transition", t, e) || {};
                            return "string" == typeof n ? {
                                name: n
                            } : n
                        }, r = e ? Object(d.g)(e) : [], c = Math.max(n.length, r.length), l = [], f = function() {
                            var t = Object.assign({}, o(n[i])),
                                e = Object.assign({}, o(r[i]));
                            Object.keys(t).filter((function(n) {
                                return void 0 !== t[n] && !n.toLowerCase().includes("leave")
                            })).forEach((function(n) {
                                e[n] = t[n]
                            })), l.push(e)
                        }, i = 0; i < c; i++) f();
                    return l
                }

                function S(n, t, e) {
                    return O.apply(this, arguments)
                }

                function O() {
                    return (O = Object(o.a)(regeneratorRuntime.mark((function n(t, e, o) {
                        var r, c, l, f, h = this;
                        return regeneratorRuntime.wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    if (this._routeChanged = Boolean(v.nuxt.err) || e.name !== t.name, this._paramChanged = !this._routeChanged && e.path !== t.path, this._queryChanged = !this._paramChanged && e.fullPath !== t.fullPath, this._diffQuery = this._queryChanged ? Object(d.i)(t.query, e.query) : [], (this._routeChanged || this._paramChanged) && this.$loading.start && !this.$loading.manual && this.$loading.start(), n.prev = 5, !this._queryChanged) {
                                        n.next = 12;
                                        break
                                    }
                                    return n.next = 9, Object(d.r)(t, (function(n, t) {
                                        return {
                                            Component: n,
                                            instance: t
                                        }
                                    }));
                                case 9:
                                    r = n.sent, r.some((function(n) {
                                        var o = n.Component,
                                            r = n.instance,
                                            c = o.options.watchQuery;
                                        return !0 === c || (Array.isArray(c) ? c.some((function(n) {
                                            return h._diffQuery[n]
                                        })) : "function" == typeof c && c.apply(r, [t.query, e.query]))
                                    })) && this.$loading.start && !this.$loading.manual && this.$loading.start();
                                case 12:
                                    o(), n.next = 26;
                                    break;
                                case 15:
                                    if (n.prev = 15, n.t0 = n.catch(5), c = n.t0 || {}, l = c.statusCode || c.status || c.response && c.response.status || 500, f = c.message || "", !/^Loading( CSS)? chunk (\d)+ failed\./.test(f)) {
                                        n.next = 23;
                                        break
                                    }
                                    return window.location.reload(!0), n.abrupt("return");
                                case 23:
                                    this.error({
                                        statusCode: l,
                                        message: f
                                    }), this.$nuxt.$emit("routeChanged", t, e, c), o();
                                case 26:
                                case "end":
                                    return n.stop()
                            }
                        }), n, this, [
                            [5, 15]
                        ])
                    })))).apply(this, arguments)
                }

                function M(n, t) {
                    return A.serverRendered && t && Object(d.b)(n, t), n._Ctor = n, n
                }

                function T(n, t, e, o) {
                    var r = this,
                        c = ["i18n"],
                        f = !1;
                    if (void 0 !== e && (c = [], (e = Object(d.s)(e)).options.middleware && (c = c.concat(e.options.middleware)), n.forEach((function(n) {
                            n.options.middleware && (c = c.concat(n.options.middleware))
                        }))), c = c.map((function(n) {
                            return "function" == typeof n ? n : ("function" != typeof l.a[n] && (f = !0, r.error({
                                statusCode: 500,
                                message: "Unknown middleware " + n
                            })), l.a[n])
                        })), !f) return Object(d.o)(c, t, o)
                }

                function I(n, t, e, o) {
                    return P.apply(this, arguments)
                }

                function P() {
                    return P = Object(o.a)(regeneratorRuntime.mark((function n(t, e, r, c) {
                        var l, h, m, w, y, A, C, j, S, O, M, I, P, _, E, L = this;
                        return regeneratorRuntime.wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    if (!1 !== this._routeChanged || !1 !== this._paramChanged || !1 !== this._queryChanged) {
                                        n.next = 2;
                                        break
                                    }
                                    return n.abrupt("return", r());
                                case 2:
                                    return !1, t === e ? (k = [], !0) : (l = [], k = Object(d.g)(e, l).map((function(n, i) {
                                        return Object(d.c)(e.matched[l[i]].path)(e.params)
                                    }))), h = !1, m = function(path) {
                                        e.path === path.path && L.$loading.finish && L.$loading.finish(), e.path !== path.path && L.$loading.pause && L.$loading.pause(), h || (h = !0, r(path))
                                    }, n.next = 8, Object(d.t)(v, {
                                        route: t,
                                        from: e,
                                        error: function(n) {
                                            c.aborted || v.nuxt.error.call(L, n)
                                        },
                                        next: m.bind(this)
                                    });
                                case 8:
                                    if (this._dateLastError = v.nuxt.dateErr, this._hadError = Boolean(v.nuxt.err), w = [], (y = Object(d.g)(t, w)).length) {
                                        n.next = 33;
                                        break
                                    }
                                    return n.next = 15, T.call(this, y, v.context, void 0, c);
                                case 15:
                                    if (!h) {
                                        n.next = 17;
                                        break
                                    }
                                    return n.abrupt("return");
                                case 17:
                                    if (!c.aborted) {
                                        n.next = 20;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 20:
                                    return A = (f.a.options || f.a).layout, n.next = 23, this.loadLayout("function" == typeof A ? A.call(f.a, v.context) : A);
                                case 23:
                                    return C = n.sent, n.next = 26, T.call(this, y, v.context, C, c);
                                case 26:
                                    if (!h) {
                                        n.next = 28;
                                        break
                                    }
                                    return n.abrupt("return");
                                case 28:
                                    if (!c.aborted) {
                                        n.next = 31;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 31:
                                    return v.context.error({
                                        statusCode: 404,
                                        message: "This page could not be found"
                                    }), n.abrupt("return", r());
                                case 33:
                                    return y.forEach((function(n) {
                                        n._Ctor && n._Ctor.options && (n.options.asyncData = n._Ctor.options.asyncData, n.options.fetch = n._Ctor.options.fetch)
                                    })), this.setTransitions(D(y, t, e)), n.prev = 35, n.next = 38, T.call(this, y, v.context, void 0, c);
                                case 38:
                                    if (!h) {
                                        n.next = 40;
                                        break
                                    }
                                    return n.abrupt("return");
                                case 40:
                                    if (!c.aborted) {
                                        n.next = 43;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 43:
                                    if (!v.context._errored) {
                                        n.next = 45;
                                        break
                                    }
                                    return n.abrupt("return", r());
                                case 45:
                                    return "function" == typeof(j = y[0].options.layout) && (j = j(v.context)), n.next = 49, this.loadLayout(j);
                                case 49:
                                    return j = n.sent, n.next = 52, T.call(this, y, v.context, j, c);
                                case 52:
                                    if (!h) {
                                        n.next = 54;
                                        break
                                    }
                                    return n.abrupt("return");
                                case 54:
                                    if (!c.aborted) {
                                        n.next = 57;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 57:
                                    if (!v.context._errored) {
                                        n.next = 59;
                                        break
                                    }
                                    return n.abrupt("return", r());
                                case 59:
                                    S = !0, n.prev = 60, O = x(y), n.prev = 62, O.s();
                                case 64:
                                    if ((M = O.n()).done) {
                                        n.next = 75;
                                        break
                                    }
                                    if ("function" == typeof(I = M.value).options.validate) {
                                        n.next = 68;
                                        break
                                    }
                                    return n.abrupt("continue", 73);
                                case 68:
                                    return n.next = 70, I.options.validate(v.context);
                                case 70:
                                    if (S = n.sent) {
                                        n.next = 73;
                                        break
                                    }
                                    return n.abrupt("break", 75);
                                case 73:
                                    n.next = 64;
                                    break;
                                case 75:
                                    n.next = 80;
                                    break;
                                case 77:
                                    n.prev = 77, n.t0 = n.catch(62), O.e(n.t0);
                                case 80:
                                    return n.prev = 80, O.f(), n.finish(80);
                                case 83:
                                    n.next = 89;
                                    break;
                                case 85:
                                    return n.prev = 85, n.t1 = n.catch(60), this.error({
                                        statusCode: n.t1.statusCode || "500",
                                        message: n.t1.message
                                    }), n.abrupt("return", r());
                                case 89:
                                    if (S) {
                                        n.next = 92;
                                        break
                                    }
                                    return this.error({
                                        statusCode: 404,
                                        message: "This page could not be found"
                                    }), n.abrupt("return", r());
                                case 92:
                                    return n.next = 94, Promise.all(y.map(function() {
                                        var n = Object(o.a)(regeneratorRuntime.mark((function n(o, i) {
                                            var r, c, l, f, h, m, x, y, p;
                                            return regeneratorRuntime.wrap((function(n) {
                                                for (;;) switch (n.prev = n.next) {
                                                    case 0:
                                                        if (o._path = Object(d.c)(t.matched[w[i]].path)(t.params), o._dataRefresh = !1, r = o._path !== k[i], L._routeChanged && r ? o._dataRefresh = !0 : L._paramChanged && r ? (c = o.options.watchParam, o._dataRefresh = !1 !== c) : L._queryChanged && (!0 === (l = o.options.watchQuery) ? o._dataRefresh = !0 : Array.isArray(l) ? o._dataRefresh = l.some((function(n) {
                                                                return L._diffQuery[n]
                                                            })) : "function" == typeof l && (P || (P = Object(d.h)(t)), o._dataRefresh = l.apply(P[i], [t.query, e.query]))), L._hadError || !L._isMounted || o._dataRefresh) {
                                                            n.next = 6;
                                                            break
                                                        }
                                                        return n.abrupt("return");
                                                    case 6:
                                                        return f = [], h = o.options.asyncData && "function" == typeof o.options.asyncData, m = Boolean(o.options.fetch) && o.options.fetch.length, x = h && m ? 30 : 45, h && ((y = Object(d.q)(o.options.asyncData, v.context)).then((function(n) {
                                                            Object(d.b)(o, n), L.$loading.increase && L.$loading.increase(x)
                                                        })), f.push(y)), L.$loading.manual = !1 === o.options.loading, m && ((p = o.options.fetch(v.context)) && (p instanceof Promise || "function" == typeof p.then) || (p = Promise.resolve(p)), p.then((function(n) {
                                                            L.$loading.increase && L.$loading.increase(x)
                                                        })), f.push(p)), n.abrupt("return", Promise.all(f));
                                                    case 14:
                                                    case "end":
                                                        return n.stop()
                                                }
                                            }), n)
                                        })));
                                        return function(t, e) {
                                            return n.apply(this, arguments)
                                        }
                                    }()));
                                case 94:
                                    if (h) {
                                        n.next = 100;
                                        break
                                    }
                                    if (this.$loading.finish && !this.$loading.manual && this.$loading.finish(), !c.aborted) {
                                        n.next = 99;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 99:
                                    r();
                                case 100:
                                    n.next = 119;
                                    break;
                                case 102:
                                    if (n.prev = 102, n.t2 = n.catch(35), !c.aborted) {
                                        n.next = 107;
                                        break
                                    }
                                    return r(!1), n.abrupt("return");
                                case 107:
                                    if ("ERR_REDIRECT" !== (_ = n.t2 || {}).message) {
                                        n.next = 110;
                                        break
                                    }
                                    return n.abrupt("return", this.$nuxt.$emit("routeChanged", t, e, _));
                                case 110:
                                    return k = [], Object(d.k)(_), "function" == typeof(E = (f.a.options || f.a).layout) && (E = E(v.context)), n.next = 116, this.loadLayout(E);
                                case 116:
                                    this.error(_), this.$nuxt.$emit("routeChanged", t, e, _), r();
                                case 119:
                                case "end":
                                    return n.stop()
                            }
                        }), n, this, [
                            [35, 102],
                            [60, 85],
                            [62, 77, 80, 83]
                        ])
                    }))), P.apply(this, arguments)
                }

                function _(n, e) {
                    Object(d.d)(n, (function(n, e, o, c) {
                        return "object" !== Object(t.a)(n) || n.options || ((n = r.a.extend(n))._Ctor = n, o.components[c] = n), n
                    }))
                }

                function E(n) {
                    var t = Boolean(this.$options.nuxt.err);
                    this._hadError && this._dateLastError === this.$options.nuxt.dateErr && (t = !1);
                    var e = t ? (f.a.options || f.a).layout : n.matched[0].components.default.options.layout;
                    "function" == typeof e && (e = e(v.context)), this.setLayout(e)
                }

                function L(n) {
                    n._hadError && n._dateLastError === n.$options.nuxt.dateErr && n.error()
                }

                function N(n, t) {
                    var e = this;
                    if (!1 !== this._routeChanged || !1 !== this._paramChanged || !1 !== this._queryChanged) {
                        var o = Object(d.h)(n),
                            c = Object(d.g)(n),
                            l = !1;
                        r.a.nextTick((function() {
                            o.forEach((function(n, i) {
                                if (n && !n._isDestroyed && n.constructor._dataRefresh && c[i] === n.constructor && !0 !== n.$vnode.data.keepAlive && "function" == typeof n.constructor.options.data) {
                                    var t = n.constructor.options.data.call(n);
                                    for (var e in t) r.a.set(n.$data, e, t[e]);
                                    l = !0
                                }
                            })), l && window.$nuxt.$nextTick((function() {
                                window.$nuxt.$emit("triggerScroll")
                            })), L(e)
                        }))
                    }
                }

                function B(n) {
                    window.onNuxtReadyCbs.forEach((function(t) {
                        "function" == typeof t && t(n)
                    })), "function" == typeof window._onNuxtLoaded && window._onNuxtLoaded(n), y.afterEach((function(t, e) {
                        r.a.nextTick((function() {
                            return n.$nuxt.$emit("routeChanged", t, e)
                        }))
                    }))
                }

                function R() {
                    return R = Object(o.a)(regeneratorRuntime.mark((function n(t) {
                        var e, c, l, f, h, m, x;
                        return regeneratorRuntime.wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    return v = t.app, y = t.router, t.store, e = new r.a(v), c = A.layout || "default", n.next = 7, e.loadLayout(c);
                                case 7:
                                    return e.setLayout(c), l = function() {
                                        e.$mount("#__nuxt"), y.afterEach(_), y.afterEach(E.bind(e)), y.afterEach(N.bind(e)), r.a.nextTick((function() {
                                            B(e)
                                        }))
                                    }, n.next = 11, Promise.all((w = v.context.route, Object(d.d)(w, function() {
                                        var n = Object(o.a)(regeneratorRuntime.mark((function n(t, e, o, r, c) {
                                            var l;
                                            return regeneratorRuntime.wrap((function(n) {
                                                for (;;) switch (n.prev = n.next) {
                                                    case 0:
                                                        if ("function" != typeof t || t.options) {
                                                            n.next = 4;
                                                            break
                                                        }
                                                        return n.next = 3, t();
                                                    case 3:
                                                        t = n.sent;
                                                    case 4:
                                                        return l = M(Object(d.s)(t), A.data ? A.data[c] : null), o.components[r] = l, n.abrupt("return", l);
                                                    case 7:
                                                    case "end":
                                                        return n.stop()
                                                }
                                            }), n)
                                        })));
                                        return function(t, e, o, r, c) {
                                            return n.apply(this, arguments)
                                        }
                                    }())));
                                case 11:
                                    if (f = n.sent, e.setTransitions = e.$options.nuxt.setTransitions.bind(e), f.length && (e.setTransitions(D(f, y.currentRoute)), k = y.currentRoute.matched.map((function(n) {
                                            return Object(d.c)(n.path)(y.currentRoute.params)
                                        }))), e.$loading = {}, A.error && e.error(A.error), y.beforeEach(S.bind(e)), h = null, m = I.bind(e), y.beforeEach((function(n, t, e) {
                                            h && (h.aborted = !0), m(n, t, e, h = {
                                                aborted: !1
                                            })
                                        })), !A.serverRendered || !Object(d.n)(A.routePath, e.context.route.path)) {
                                        n.next = 22;
                                        break
                                    }
                                    return n.abrupt("return", l());
                                case 22:
                                    return x = function() {
                                        _(y.currentRoute, y.currentRoute), E.call(e, y.currentRoute), L(e), l()
                                    }, n.next = 25, new Promise((function(n) {
                                        return setTimeout(n, 0)
                                    }));
                                case 25:
                                    I.call(e, y.currentRoute, y.currentRoute, (function(path) {
                                        if (path) {
                                            var n = y.afterEach((function(t, e) {
                                                n(), x()
                                            }));
                                            y.push(path, void 0, (function(n) {
                                                n && j(n)
                                            }))
                                        } else x()
                                    }), {
                                        aborted: !1
                                    });
                                case 26:
                                case "end":
                                    return n.stop()
                            }
                            var w
                        }), n)
                    }))), R.apply(this, arguments)
                }
                Object(f.b)(null, A.config).then((function(n) {
                    return R.apply(this, arguments)
                })).catch(j)
            }.call(this, e(12))
    }, , , , , , , , , , , , , , , , , , , , , , , function(n, t) {}, function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e(111),
            r = (e(276), e(25), e(70), e(62), e(140), ["isHMR", "app", "store", "route", "params", "query", "error", "redirect", "res"]);
        e(177), e(278).default, e(37).default;
        t.default = function(n) {
            var t = n.isHMR,
                e = n.app,
                c = (n.store, n.route, n.params);
            n.query, n.error, n.redirect, n.res, Object(o.a)(n, r), e.i18n.fallbackLocale;
            if (!(t || c && "__webpack_hmr" === c.lang));
        }
    }, , , function(n, t, e) {
        "use strict";
        e.r(t);
        t.default = {
            enableAppStore: !0,
            downloadPath: ["download1", "download2"]
        }
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(n, t, e) {
        n.exports = e.p + "img/404.1660c00.png"
    }, , function(n, t, e) {
        "use strict";
        e(189)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ") format(\"truetype\");\n  font-style: normal;\n  font-weight: normal;\n}\n.section4-con-pc[data-v-32c22c38] {\n  height: 320px;\n  background: linear-gradient(81.61deg, #00b25d 8.41%, #00cb6a 100%);\n}\n.section4-con-pc .section4-content[data-v-32c22c38] {\n  width: 1200px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin: 0 auto;\n}\n.section4-con-pc .section4-content .title[data-v-32c22c38] {\n  font-weight: 600;\n  font-size: 40px;\n  line-height: 56px;\n  color: #e8f0e8;\n  margin-top: 80px;\n  text-align: left;\n}\n.section4-con-pc .section4-content .is-en-title[data-v-32c22c38] {\n  white-space: break-spaces;\n  max-width: 750px;\n}\n.section4-con-pc .section4-content .desc[data-v-32c22c38] {\n  font-weight: 400;\n  color: #e8f0e8;\n  font-size: 16px;\n  line-height: 24px;\n  margin-top: 16px;\n  font-style: normal;\n  text-align: left;\n}\n.section4-con-pc .section4-content .is-en-desc[data-v-32c22c38] {\n  word-break: keep-all;\n  width: 560px;\n}\n.section4-con-pc .section4-content .right[data-v-32c22c38] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  margin-top: 80px;\n}\n.section4-con-pc .section4-content .right .title[data-v-32c22c38] {\n  position: relative;\n  top: 90px;\n  left: 120px;\n  font-size: 56px;\n  font-weight: 600;\n  line-height: 72px;\n  width: 100%;\n  text-align: left;\n}\n.section4-con-pc .section4-content .right .title span[data-v-32c22c38] {\n  font-family: 'PingFang SC', sans-serif;\n  font-size: 56px;\n  color: #116ffc;\n}\n.section4-con-pc .section4-content .right .title .wallet-desc[data-v-32c22c38] {\n  font-size: 24px;\n  line-height: 24px;\n  color: #6b788e;\n  font-weight: normal;\n  margin-top: 46px;\n  font-family: 'Roboto', sans-serif;\n}\n.section4-con-pc .section4-content .right .btn_con[data-v-32c22c38] {\n  margin-right: 31px;\n  position: relative;\n}\n.section4-con-pc .section4-content .right .download_btn[data-v-32c22c38] {\n  width: 180px;\n  height: 48px;\n  border: 1px solid rgba(255, 255, 255, .6);\n  border-radius: 4px;\n  font-size: 14px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #fff;\n  text-decoration: none;\n  margin-bottom: 16px;\n  cursor: pointer;\n}\n.section4-con-pc .section4-content .right .download_btn > img[data-v-32c22c38] {\n  margin-right: 12px;\n}\n.section4-con-pc .section4-content .right .download_btn[data-v-32c22c38]:last-child {\n  margin-bottom: 0;\n}\n.section4-con-pc .section4-content .right .ios_btn img[data-v-32c22c38] {\n  width: 17px;\n  height: 20px;\n}\n.section4-con-pc .section4-content .right .android_btn[data-v-32c22c38] {\n  left: 0;\n  top: 94px;\n}\n.section4-con-pc .section4-content .right .android_btn img[data-v-32c22c38] {\n  width: 18px;\n  height: 20px;\n}\n.section4-con-pc .section4-content .right .qr_con[data-v-32c22c38] {\n  display: block;\n  width: 112px;\n  height: 112px;\n  border-radius: 4px;\n  background: #fff;\n  overflow: hidden;\n}\n.section4-con-pc .section4-content .right .qr_con .temp_pos[data-v-32c22c38] {\n  width: 112px;\n  height: 112px;\n  border-radius: 8px;\n  background: #fff;\n  padding: 8px;\n  position: relative;\n}\n.section4-con-pc .section4-content .right .qr_con .temp_pos img[data-v-32c22c38] {\n  font-size: 0;\n  left: 8px;\n  top: 8px;\n  position: absolute;\n  height: 96px;\n  width: 96px;\n}\n.section4-con-pc .section4-content .right .qr_con > .scan_text[data-v-32c22c38] {\n  text-align: center;\n  font-size: 12px;\n  line-height: 12px;\n  white-space: nowrap;\n  color: #99a5b8;\n  margin-top: 8px;\n}\n.section4-con-pc .section4-content .right .android_download_list[data-v-32c22c38] {\n  display: none;\n  position: absolute;\n  left: -8px;\n  top: -8px;\n  z-index: 2;\n  -webkit-transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  -webkit-transform-origin: center;\n          transform-origin: center;\n  opacity: 0;\n}\n.section4-con-pc .section4-content .right .android_download_list.visible[data-v-32c22c38] {\n  opacity: 1;\n}\n.section4-con-pc .section4-content .right .android_download_list .close-btn[data-v-32c22c38] {\n  display: none;\n}\n.section4-con-pc .section4-content .right .android_download_list .android_download_title[data-v-32c22c38] {\n  display: none;\n}\n.section4-con-pc .section4-content .right .android_download_list .download_btn[data-v-32c22c38] {\n  width: 180px;\n  height: 48px;\n  margin-bottom: 8px;\n}\n.section4-con-pc .section4-content .right .android_download_list .download_btn[data-v-32c22c38]:last-child {\n  margin-bottom: 0;\n}\n.section4-con-pc .section4-content .right .android_download_list .android_download_con[data-v-32c22c38] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  background: linear-gradient(81.61deg, #00b25d 8.41%, #00cb6a 100%);\n  width: 196px;\n  padding: 8px;\n  border-radius: 8px;\n  -webkit-box-shadow: 0 0 4px 0 rgba(99, 97, 119, .2);\n          box-shadow: 0 0 4px 0 rgba(99, 97, 119, .2);\n  /*stay px*/\n}\n.section4-con-pc .section4-content .right .android_download_list .site_download img[data-v-32c22c38] {\n  margin-right: 8px;\n  width: 17px;\n  height: 20px;\n}\n.section4-con-pc .section4-content .right .android_download_list .google_play_download img[data-v-32c22c38] {\n  margin-right: 8px;\n  width: 14px;\n  height: 16px;\n}\n.section4-con-pc-line[data-v-32c22c38] {\n  border-bottom: 1px solid #292c4f;\n  height: 1px;\n}\n.warm-prompt-pc[data-v-32c22c38] {\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, .5);\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 999;\n}\n.warm-prompt-pc .content[data-v-32c22c38] {\n  width: 400px;\n  height: auto;\n  position: fixed;\n  left: 50%;\n  top: 50%;\n  background: #fff;\n  border-radius: 16px;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  padding-bottom: 40px;\n}\n.warm-prompt-pc .content .title[data-v-32c22c38] {\n  /* 文字/黑 */\n  color: #212d43;\n  font-size: 18px;\n  line-height: 18px;\n  text-align: center;\n  display: block;\n  line-height: 80px;\n}\n.warm-prompt-pc .content .desc[data-v-32c22c38] {\n  color: #212d43;\n  font-size: 14px;\n  line-height: 20px;\n  margin-bottom: 40px;\n  width: 300px;\n  margin: 0 auto;\n  text-align: left;\n}\n.warm-prompt-pc .content .close[data-v-32c22c38] {\n  position: absolute;\n  right: 33px;\n  top: 24px;\n  cursor: pointer;\n  width: 16px;\n  height: 16px;\n}\n.warm-prompt-pc .content .close img[data-v-32c22c38] {\n  width: 16px;\n  height: 16px;\n}\n.warm-prompt-pc .content .button[data-v-32c22c38] {\n  text-decoration: none;\n  display: block;\n  cursor: pointer;\n  background: #1fb75c;\n  border-radius: 8px;\n  width: 300px;\n  height: 44px;\n  margin: 0 auto;\n  color: #fff;\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 44px;\n  margin-top: 24px;\n}\n.warm-prompt-pc .content .tips[data-v-32c22c38] {\n  display: block;\n  color: #1fb75c;\n  font-size: 14px;\n  line-height: 14px;\n  margin-top: 16px;\n  text-decoration: none;\n}\n", ""]), D.locals = {}, n.exports = D
    }, function(n, t, e) {
        "use strict";
        e(190)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ") format(\"truetype\");\n  font-style: normal;\n  font-weight: normal;\n}\n.footer-pc[data-v-1307f04f] {\n  overflow: hidden;\n  width: 100%;\n  background: #061f0f;\n  background-size: cover;\n  background-position: top;\n}\n.footer-pc .content[data-v-1307f04f] {\n  width: 1200px;\n  margin: 0 auto;\n}\n.footer-pc .content .bottom-nav[data-v-1307f04f] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n.footer-pc .content .left[data-v-1307f04f] {\n  margin-top: 74px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n.footer-pc .content .left .logo-info[data-v-1307f04f] {\n  margin-right: 160px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.footer-pc .content .left .logo-info .logo-small[data-v-1307f04f] {\n  width: 104px;\n  height: 24px;\n}\n.footer-pc .content .left .logo-info .logo-text-title[data-v-1307f04f] {\n  font-size: 12px;\n  line-height: 12px;\n  font-family: 'Roboto';\n  margin-top: 22px;\n  font-weight: 400;\n  color: rgba(255, 255, 255, .4);\n}\n.footer-pc .content .left .links-con[data-v-1307f04f] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  text-align: left;\n}\n.footer-pc .content .left .links-con .links-group[data-v-1307f04f] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin-right: 80px;\n}\n.footer-pc .content .left .links-con .links-group .links-title[data-v-1307f04f] {\n  margin-bottom: 22px;\n  font-size: 18px;\n  line-height: 12px;\n  font-weight: 400;\n  color: rgba(255, 255, 255, .4);\n}\n.footer-pc .content .left .links-con .links-group .links-item[data-v-1307f04f] {\n  text-decoration: none;\n  font-weight: 500;\n  font-size: 12px;\n  line-height: 12px;\n  color: #fff;\n  margin-bottom: 12px;\n}\n.footer-pc .content .contact-con[data-v-1307f04f] {\n  margin: 72px 72px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 104px;\n}\n.footer-pc .content .contact-con .contact-con-title[data-v-1307f04f] {\n  color: #fff;\n  font-size: 18px;\n  line-height: 12px;\n  margin-bottom: 12px;\n}\n.footer-pc .content .contact-con .contact-con-title-small[data-v-1307f04f] {\n  font-size: 12px;\n}\n.footer-pc .content .contact-con .contact-items[data-v-1307f04f] {\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n}\n.footer-pc .content .contact-con .list[data-v-1307f04f] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n.footer-pc .content .contact-con .list a[data-v-1307f04f] {\n  margin-top: 12px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  margin-right: 16px;\n  width: 24px;\n  height: 24px;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  border-radius: 50%;\n  border: 1px solid rgba(153, 165, 184, .2);\n}\n.footer-pc .content .contact-con .list a[data-v-1307f04f]:last-child {\n  margin-right: 0;\n}\n.footer-pc .content .contact-con .list a[data-v-1307f04f]:hover {\n  border-radius: 50%;\n  border: solid 1px #99a5b8;\n}\n", ""]), D.locals = {}, n.exports = D
    }, function(n, t, e) {
        "use strict";
        e(191)
    }, function(n, t, e) {
        var o = e(14)((function(i) {
            return i[1]
        }));
        o.push([n.i, ".dlist_section4-mobile[data-v-4813229b] {\n  position: fixed;\n  z-index: 999999;\n  background: rgba(255, 255, 255, .95);\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  -webkit-transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  -webkit-transform-origin: top;\n          transform-origin: top;\n}\n.dlist_section4-mobile .android_download_list-p4[data-v-4813229b] {\n  width: 100%;\n  height: 100%;\n}\n.dlist_section4-mobile .download-header[data-v-4813229b] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin: 17px 24px;\n}\n.dlist_section4-mobile .download-header .logo[data-v-4813229b] {\n  width: 130px;\n  height: 20px;\n}\n.dlist_section4-mobile .close-btn[data-v-4813229b] {\n  position: absolute;\n  right: 0;\n  top: 0;\n  width: 16vw;\n  height: 16vw;\n  -webkit-tap-highlight-color: transparent;\n}\n.dlist_section4-mobile .close-btn > img[data-v-4813229b] {\n  position: absolute;\n  right: 5.3333vw;\n  top: 5.3333vw;\n  width: 3.4667vw;\n  height: 3.4667vw;\n}\n.dlist_section4-mobile .android_download_title[data-v-4813229b] {\n  font-size: 16px;\n  font-weight: 600;\n  color: #6B788E;\n  line-height: 16px;\n  text-align: center;\n  margin-bottom: 32px;\n  white-space: nowrap;\n  font-family: 'PingFang SC', sans-serif;\n}\n.dlist_section4-mobile .android_download_con[data-v-4813229b] {\n  position: relative;\n  top: 50%;\n  -webkit-transform: translateY(-70%);\n          transform: translateY(-70%);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.dlist_section4-mobile .android_download_con .site_download[data-v-4813229b] {\n  margin-bottom: 3.6vw;\n}\n.dlist_section4-mobile .android_download_con .download_btn[data-v-4813229b] {\n  width: 180px;\n  height: 48px;\n  border-radius: 8px;\n  font-size: 14px;\n  background: #212D43;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #fff;\n  text-decoration: none;\n  margin-bottom: 16px;\n  cursor: pointer;\n}\n.dlist_section4-mobile .android_download_con .download_btn img[data-v-4813229b] {\n  margin-right: 10px;\n}\n.dlist_section4-mobile .android_download_con .download_btn[data-v-4813229b]:last-child {\n  margin-bottom: 0;\n}\n.dlist_section4-mobile .android_download_con .download_btn:last-child img[data-v-4813229b] {\n  width: 14px;\n  height: 16px;\n  margin-right: 10px;\n}\n.dlist_section4-mobile .android_download_con .download_btn[data-v-4813229b]:last-child:hover {\n  background: #116FFC;\n}\n.dlist_section4-mobile .android_download_con .google_play_download img[data-v-4813229b] {\n  margin-right: 8px;\n  width: 14px;\n  height: 16px;\n}\n.dlist_section4-mobile .download_btn[data-v-4813229b] {\n  width: 160px;\n  height: 40px;\n  border-radius: 8px;\n  font-size: 14px;\n  background: #212D43;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  font-weight: 500;\n  color: #fff;\n  font-family: 'Roboto', sans-serif;\n  text-decoration: none;\n  cursor: pointer;\n}\n.dlist_section4-mobile .download_btn[data-v-4813229b]:first-child {\n  margin-right: 12px;\n}\n.dlist_section4-mobile .download_btn img[data-v-4813229b] {\n  width: 14px;\n  height: 17px;\n  margin-right: 7px;\n}\n", ""]), o.locals = {}, n.exports = o
    }, function(n, t, e) {
        "use strict";
        e(192)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ") format(\"truetype\");\n  font-style: normal;\n  font-weight: normal;\n}\n.section4-con-mobile[data-v-97ea575c] {\n  height: 210px;\n  background: linear-gradient(81.61deg, #00b25d 8.41%, #00cb6a 100%);\n}\n.section4-con-mobile .title[data-v-97ea575c] {\n  padding-top: 60px;\n  font-family: 'PingFang SC', sans-serif;\n  font-weight: 600;\n  font-size: 26px;\n  line-height: 36px;\n  color: #fff;\n  margin: 0 16px;\n}\n.section4-con-mobile .desc[data-v-97ea575c] {\n  font-family: 'Roboto', sans-serif;\n  color: #7582a2;\n  font-size: 14px;\n  line-height: 22px;\n  margin-top: 16px;\n  padding: 0 16px;\n  font-weight: 400;\n  color: rgba(255, 255, 255, .8);\n}\n.section4-con-mobile .is-en-desc-mb4[data-v-97ea575c] {\n  font-weight: normal;\n}\n.section4-con-mobile .btn-group[data-v-97ea575c] {\n  height: 40px;\n  margin: 40px 0 60px 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.section4-con-mobile .line[data-v-97ea575c] {\n  height: 1px;\n  margin: 0 16px;\n  border-bottom: 1px solid #292c4f;\n  margin-top: 48px;\n}\n.section4-con-mobile .download_btn[data-v-97ea575c] {\n  width: 160px;\n  height: 40px;\n  border-radius: 8px;\n  font-size: 14px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  font-weight: 500;\n  color: #fff;\n  font-family: 'Roboto', sans-serif;\n  text-decoration: none;\n  cursor: pointer;\n  border: 1px solid rgba(255, 255, 255, .15);\n}\n.section4-con-mobile .download_btn[data-v-97ea575c]:first-child {\n  margin-right: 12px;\n}\n.section4-con-mobile .download_btn img[data-v-97ea575c] {\n  width: 14px;\n  height: 17px;\n  margin-right: 7px;\n}\n.is-en-section4-con-mobile[data-v-97ea575c] {\n  height: 310px;\n}\n", ""]), D.locals = {}, n.exports = D
    }, function(n, t, e) {
        "use strict";
        e(193)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ") format(\"truetype\");\n  font-style: normal;\n  font-weight: normal;\n}\n.special[data-v-2de522ce] {\n  background: #000 !important;\n  -webkit-box-shadow: none !important;\n          box-shadow: none !important;\n}\n.footer-mobile[data-v-2de522ce] {\n  overflow: hidden;\n  background: #061f0f;\n  padding-bottom: 133px;\n}\n.footer-mobile .content[data-v-2de522ce] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  margin: 0 24px;\n}\n.footer-mobile .content img[data-v-2de522ce] {\n  margin-bottom: 32px;\n  margin-top: 36px;\n  width: 104px;\n}\n.footer-mobile .content .links-group[data-v-2de522ce] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  width: 100%;\n}\n.footer-mobile .content .links-group .item[data-v-2de522ce] {\n  width: 100%;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  font-family: 'Roboto', sans-serif;\n  margin-bottom: 21px;\n}\n.footer-mobile .content .links-group .item .title[data-v-2de522ce] {\n  text-align: left;\n  color: rgba(249, 250, 249, .5);\n  font-size: 18px;\n  line-height: 14px;\n  font-weight: 400;\n  margin-bottom: 8px;\n}\n.footer-mobile .content .links-group .item .link-title[data-v-2de522ce] {\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  text-align: left;\n  font-size: 16px;\n  line-height: 20px;\n  font-weight: 400;\n}\n.footer-mobile .content .links-group .item .link-title a[data-v-2de522ce] {\n  color: #fff;\n  margin-right: 10px;\n  text-decoration: none;\n}\n.footer-mobile .content .links-group .item .link-title a[data-v-2de522ce]:last-child {\n  margin-right: 0;\n}\n.footer-mobile .content .links-group .item .link-title .contact-items[data-v-2de522ce] {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  margin: 0;\n  margin-top: 12px;\n  color: #99a5b8;\n}\n.footer-mobile .content .links-group .item .links-item[data-v-2de522ce] {\n  display: block;\n}\n.footer-mobile .copyright[data-v-2de522ce] {\n  font-family: 'Roboto', sans-serif;\n  color: rgba(249, 250, 249, .5);\n  font-size: 12px;\n  line-height: 12px;\n  text-align: left;\n  padding: 0 24px;\n}\n", ""]), D.locals = {}, n.exports = D
    }, , function(n, t, e) {
        "use strict";
        e(195)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ") format(\"truetype\");\n  font-style: normal;\n  font-weight: normal;\n}\n.header-bar-pc .outside-container[data-v-cf602d34] {\n  position: fixed;\n  width: 100%;\n  left: 0;\n  top: 0;\n  z-index: 100;\n  height: 80px;\n  background: #fff;\n  -webkit-transition: background-color 0.6s ease;\n  transition: background-color 0.6s ease;\n}\n.header-bar-pc .outside-background[data-v-cf602d34] {\n  background: #fff;\n}\n.header-bar-pc .outside-background-transparent[data-v-cf602d34] {\n  background: linear-gradient(87.42deg, #dcf5e2 18.1%, rgba(224, 255, 232, .62) 85.39%);\n}\n.header-bar-pc .header-bar-content[data-v-cf602d34] {\n  width: 1200px;\n  margin: 0 auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  height: 80px;\n}\n.header-bar-pc .header-bar-menu[data-v-cf602d34] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n}\n.header-bar-pc .header_logo[data-v-cf602d34] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -ms-flex-line-pack: center;\n      align-content: center;\n  justify-items: center;\n  margin-left: 10px;\n  cursor: pointer;\n}\n.header-bar-pc .header_logo img[data-v-cf602d34] {\n  width: 135px;\n  height: 32px;\n  margin-top: 24px;\n}\n.header-bar-pc .nav-item[data-v-cf602d34] {\n  margin-left: 158px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  justify-items: center;\n}\n.header-bar-pc .nav-item a[data-v-cf602d34] {\n  margin-right: 60px;\n  color: #252b27;\n  text-decoration: none;\n  font-size: 16px;\n  font-family: 'PingFang SC', sans-serif;\n  cursor: pointer;\n  line-height: 24px;\n  font-weight: 400;\n}\n.header-bar-pc .nav-item a.active-nav[data-v-cf602d34] {\n  color: #1fb75c;\n  font-weight: 600;\n}\n.header-bar-pc .nav-item .pc-nav-8th[data-v-cf602d34] {\n  margin-top: 4px;\n}\n.header-bar-pc .nav-screen[data-v-cf602d34] {\n  display: none;\n}\n.header-bar-pc .pc-nav[data-v-cf602d34] {\n  z-index: 3;\n  margin-top: 30px;\n  font-size: 16px;\n  height: 19px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #fff;\n}\n.header-bar-pc .pc-nav.dark[data-v-cf602d34],\n.header-bar-pc .pc-nav.transparent[data-v-cf602d34] {\n  color: #fff;\n}\n.header-bar-pc .pc-nav.dark > .pc-nav-item[data-v-cf602d34],\n.header-bar-pc .pc-nav.transparent > .pc-nav-item[data-v-cf602d34] {\n  color: #fff;\n}\n.header-bar-pc .pc-nav.dark > .pc-nav-item[data-v-cf602d34]:hover,\n.header-bar-pc .pc-nav.transparent > .pc-nav-item[data-v-cf602d34]:hover {\n  color: #fff;\n}\n.header-bar-pc .pc-nav > .pc-nav-item[data-v-cf602d34] {\n  position: relative;\n  cursor: pointer;\n  text-decoration: none;\n  padding-left: 20px;\n  padding-right: 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #030303;\n  white-space: nowrap;\n}\n.header-bar-pc .pc-nav > .pc-nav-item[data-v-cf602d34]:hover {\n  color: #030303;\n}\n.header-bar-pc .pc-nav > .pc-nav-item > .content[data-v-cf602d34] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.header-bar-pc .pc-nav > .pc-nav-item > .content > .locale-flag[data-v-cf602d34] {\n  width: 15px;\n  height: 15px;\n  margin-right: 8px;\n}\n.header-bar-pc .pc-nav > .pc-nav-item > .content > .locale-language[data-v-cf602d34] {\n  font-family: 'Lato';\n  font-style: normal;\n  font-weight: 500;\n  font-size: 16px;\n  line-height: 19px;\n  color: #252b27;\n}\n.header-bar-pc .pc-nav > .pc-nav-item > .content > .down_arrow[data-v-cf602d34] {\n  line-height: 0;\n  width: 10px;\n  margin-left: 6px;\n}\n.header-bar-pc .pc-nav > .pc-nav-item > .content > .transform-arrow-up[data-v-cf602d34] {\n  -webkit-transform: rotate(180deg);\n          transform: rotate(180deg);\n  -webkit-transition: all 0.2s;\n  transition: all 0.2s;\n}\n.header-bar-pc .pc-nav .pc-language-list[data-v-cf602d34] {\n  position: absolute;\n  background-color: #fff;\n  color: #000;\n  -webkit-box-shadow: 0 0.5333vw 1.3333vw 0 rgba(70, 75, 104, .15);\n          box-shadow: 0 0.5333vw 1.3333vw 0 rgba(70, 75, 104, .15);\n  border-radius: 6px;\n  right: 0;\n  top: 30px;\n  width: 203px;\n  padding: 4px;\n  font-size: 14px;\n  -webkit-transform-origin: top;\n          transform-origin: top;\n  -webkit-transition: -webkit-transform 0.3s ease-in;\n  transition: -webkit-transform 0.3s ease-in;\n  transition: transform 0.3s ease-in;\n  transition: transform 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  -webkit-transform: scale3d(1, 0, 1);\n          transform: scale3d(1, 0, 1);\n  overflow: hidden;\n}\n.header-bar-pc .pc-nav .pc-language-list > .pc-language-item[data-v-cf602d34] {\n  border-radius: 6px;\n  padding-left: 16px;\n  text-decoration: none;\n  height: 40px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  color: #000;\n  font-size: 16px;\n}\n.header-bar-pc .pc-nav .pc-language-list > .pc-language-item > .locale-flag[data-v-cf602d34] {\n  width: 18px;\n  height: 13px;\n  margin-right: 4px;\n}\n.header-bar-pc .pc-nav .pc-language-list > .pc-language-item[data-v-cf602d34]:hover {\n  color: rgba(31, 183, 92, .5);\n  background-color: #f3f6f8;\n}\n.header-bar-pc .pc-nav .pc-language-list .active-lang[data-v-cf602d34] {\n  color: #1fb75c;\n}\n.header-bar-pc .pc-nav .pc-language-list.pc-language-list-show[data-v-cf602d34] {\n  -webkit-transform: scale3d(1, 1, 1);\n          transform: scale3d(1, 1, 1);\n}\n.header-bar-special[data-v-cf602d34] {\n  position: absolute;\n  top: 0;\n  left: 0;\n}\n.header-bar-special .outside-container[data-v-cf602d34] {\n  background: transparent;\n}\n.header-bar-special .pc-nav-item[data-v-cf602d34] {\n  color: #fff !important;\n}\n@-webkit-keyframes list-expand-ani-cf602d34 {\n0% {\n    height: 10.6667vw;\n}\n100% {\n    height: auto;\n}\n}\n@keyframes list-expand-ani-cf602d34 {\n0% {\n    height: 10.6667vw;\n}\n100% {\n    height: auto;\n}\n}\n", ""]), D.locals = {}, n.exports = D
    }, function(n, t) {
        n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgb3BhY2l0eT0iMC4wMSIgd2lkdGg9IjE2IiBoZWlnaHQ9IjE2IiByeD0iMSIgZmlsbD0iIzIxMkQ0MyIvPgo8cmVjdCB5PSIxIiB3aWR0aD0iMTYiIGhlaWdodD0iMiIgcng9IjEiIGZpbGw9IiMyMTJENDMiLz4KPHJlY3QgeT0iNyIgd2lkdGg9IjE2IiBoZWlnaHQ9IjIiIHJ4PSIxIiBmaWxsPSIjMjEyRDQzIi8+CjxyZWN0IHk9IjEzIiB3aWR0aD0iMTYiIGhlaWdodD0iMiIgcng9IjEiIGZpbGw9IiMyMTJENDMiLz4KPC9zdmc+Cg=="
    }, function(n, t, e) {
        n.exports = e.p + "img/english.1fd5450.svg"
    }, function(n, t, e) {
        n.exports = e.p + "img/es.ad3137d.png"
    }, function(n, t) {
        n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAM6SURBVHgB1ZrPUtNAHMd/u5spMKNj8S6T3hTrlJ70ZnkDeALkCcAnILwBPIH15BHegHLzRlABTxrgLvEPBGKz6+8XaCemJW0ClN3PTGaTzTL8vtnv/i+DW0ApVT49PZ2zLKuGjzY+z1AeY6ycKObRhXkuvtvF+9bExIQHN4RBQSjA8/PzJbxtXF35//mlmHW4gZjcAjqBY7qc+sI3pYnXal4huQQEQbByB4GncVDE6rCFhxKAgdsY9AZ5G0aDh9fsMLXBBxUIw3ABA98ZYfAEfbAd6hgGFcwUcHFxsRJFUfOOLdMXamuc8w2ybVa5ay1EwUspHdCDa9tFXwFUdaQeNEII8aZUKr1P5/cIoAZLnr8P22SB8fgYVz3dsPu1gS3dgieuRvYeV/wngHyPiQ2aQj0h2ttJ5nUtFAQnNsD4d9AcstLYWFBhbNKnZ6vz4vO3s5VHD9pgAGUJsIypQw9xDZRffbBLFtP+63fBWgjFWcVvLfpxDQicTUoJBqHKVjQe10LciJlgS2Aair2mhJF9LG6QfRK0S8EkFwUXIzogwvE5DpyNcpZ5q3BQM5wpqIGhKMVtzpi+I+8gMPYaVxpPHQahsA8auCLTG2W6AGzIaCEfDIZzgwXgRM7jEpgLhqIUCsDkEAyFMbnLuVTG1gC5h5UbG+XH4c8TMJAfcqwSL2g+1qpblmo3wCAiJtyXu3v1eEHzMPq1zQyblUoZb8tf7kqEFl8Dw7pTIUWL0lhA3fV8HNDWwRBwBt189tXz6L47lTCqFiLe3SftCjClFjDG1c7XJ3r2RverUzuY6LlKw5F3eu+okszqmY2yNp8HPa3ks4jPpjN7BFD1YBf1FnQjUotJ63Toux6o7h83yWugCRTL9MHxZr93mYd8e9UpBwtkHvHcNRT88y9HznXvB55SfnrxZM5S7B3ejvrMwCcrkxuyCg11zHrw1LaVkFswqh0MBS422Pl+nk+T66B7BJaKx6Isy6TJ/VODq9pw8C8X4PaIAw//8LW65+Xqwgv/2IOERDxqcB7vbBcc+FQL93a2iwTeobCAJF0xgPusnNVwtmWjj+1EER//k49b4i5IdSiFcv/+FptFg07yD3RzWY3GbZ+KAAAAAElFTkSuQmCC"
    }, function(n, t, e) {
        n.exports = e.p + "img/vi.1832702.png"
    }, function(n, t) {
        n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMJSURBVHgB1ZpNbtpAFMffG3ACQpGM1HZtNqg74AQlNyAnSHsC0hMEbhBOUHqC5AYhB6hMdlU2cRbZtFJhw0dENdP3jO3yjTFfnp9EBptJ8v5+/zcez4CwA2zTMqVhVJIgChLBolNFkGAC0ssHwQEFjgBo/wX5KEaJVqn704EtQYgIBw0nJ1VQWKbDMkRCtSWoxjZiNhYQBC7xauoKb41qwkjUNxWykQD7Q/5694HPgKpW+vVUD909TCfb/GiBIW+pexEOgwMjPA+TDbGug/0+fwlJZR8weIYumLIp45V1HVcKcC0D2NyrZZZj0gBxO45hOUst5P6iwhrEgRV1sVCAmzpSD7FCfS79fvo+e3ZOgFuw7Pnj2GYVXSrs0mxhz9eAoe5jGDxjjkfCaaYEeAVjQWzB4o93+drUGf/NeKxXzxB/yEpvuVLX6fJBkAE04Br0wJTJkyv/wM2ARlffJ8jCOANG1Nnk0QiyMBagZBU0QyB+4hY1tM9/Rm9ZoaF9AmTCqAgp1SFnmbtFQFEIAQXQFERhcRFboCmooJCkxgJtUWYSz85AY0z88/qqQGOw1+93qBriOH0ORZLuaDyr01WAQ/FjG/TFoRuZfAFNUUo9sgBtM8DuwU6nY6ZSqQ7oSU5ks1ku4hZoBtmnnU6nHf+R8gE0g+zT4NYVMBwOb0hRF/SixT9cAWwjX5EmNNk+/CZYVuFiPj09fUY97so5X0CwrKJLFmjYr/vBM3Nro/1+3yYhcX1Kcyj43OSJubVRCv4ijgXtxXQ+e35OAKeHRHyFmJFIJL5MWsdn4Q4NdWxSE3qjbd+w72mAuVv02cpNvsFgUKPmqGumHHwmk6kt+3ztLmWv16uQpb4denhlz7OVPTcsJdQ2K2XCouYeDrSCwbNMEnCxyPOzrN1mZfgPecPXXuvCG2nqNDsuhQme2firBpwN8mWNVsQuYUd4dmlQ4Dc4fsQNTeQve3i2KtM/r25x42vR6yFK4D6RBUwyIaZIgfBSpQUT9eJd4S7P4enwhZ8CaWS5ixr0JP8ADrohcPIcZUIAAAAASUVORK5CYII="
    }, function(n, t, e) {
        n.exports = e.p + "img/p-t.97a0a69.svg"
    }, function(n, t) {
        n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTIiIHZpZXdCb3g9IjAgMCAxNiAxMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE1LjMzMzMgMC4yNDg1MDVMMTQuMTYzOSAxLjM2OTIxQzE0LjA2MTYgMS40NDcxOCAxNC4wMTI4IDEuNTczODcgMTQuMDMyMyAxLjY5NTY4VjkuOTQ1MDdDMTQuMDEyOCAxMC4wNzE4IDE0LjA2MTYgMTAuMTk4NCAxNC4xNjM5IDEwLjI3MTVMMTUuMzA5IDExLjM5MjJWMTEuNjQwOEg5LjU1OTI0VjExLjQwMkwxMC43NDMzIDEwLjI1MkMxMC44NjAyIDEwLjEzNTEgMTAuODYwMiAxMC4xMDEgMTAuODYwMiA5LjkyNTU4VjMuMjU0OTNMNy41NjYzMiAxMS42MTY0SDcuMTIyOTFMMy4yODgxNCAzLjI1NDkzVjguODU4NDdDMy4yNTQwMyA5LjA5MjM2IDMuMzM2ODcgOS4zMzExMiAzLjUwMjU0IDkuNTAxNjZMNS4wNDIyOSAxMS4zNjc5VjExLjYxNjRIMC42NjY2NTZWMTEuMzY3OUwyLjIwNjQxIDkuNTAxNjZDMi4zNzIwOCA5LjMzMTEyIDIuNDQ1MTcgOS4wOTIzNiAyLjQwNjE5IDguODU4NDdWMi4zNzc4NUMyLjQyNTY4IDIuMTk3NTYgMi4zNTc0NyAyLjAyMjE1IDIuMjIxMDMgMS45MDAzM0wwLjg1MTgxNyAwLjI0ODUwNVYwSDUuMTA1NjRMOC4zODk4IDcuMjExNTJMMTEuMjc5MyAwLjAwNDg3MzEySDE1LjMzMzNWMC4yNDg1MDVaIiBmaWxsPSIjRjhGQUZCIi8+Cjwvc3ZnPgo="
    }, , function(n, t, e) {
        "use strict";
        e(197)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n.header-bar-mobile[data-v-40dd17ea] {\n  height: 54px;\n}\n.header-bar-mobile .nav-btn[data-v-40dd17ea] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  cursor: pointer;\n  -webkit-tap-highlight-color: transparent;\n  tap-highlight-color: transparent;\n}\n.header-bar-mobile .link-title[data-v-40dd17ea] {\n  width: 154px;\n  margin: 0 auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  margin-top: 60px;\n}\n.header-bar-mobile .link-title a[data-v-40dd17ea] {\n  background: #c8ced9;\n  border-radius: 60px;\n  width: 32px;\n  height: 32px;\n  padding: 1px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.header-bar-mobile .link-title a img[data-v-40dd17ea] {\n  width: 18px;\n}\n.header-bar-mobile .nav-btn-icon[data-v-40dd17ea] {\n  width: 16px;\n  height: 16px;\n}\n.header-bar-mobile .inner_screen[data-v-40dd17ea] {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  background: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, .72)), color-stop(74.86%, rgba(255, 255, 255, .9)));\n  background: linear-gradient(180deg, rgba(255, 255, 255, .72) 0%, rgba(255, 255, 255, .9) 74.86%);\n  -webkit-backdrop-filter: blur(24px);\n          backdrop-filter: blur(24px);\n  height: 0;\n  overflow: hidden;\n  z-index: 999;\n}\n.header-bar-mobile .inner_screen .inner_screen-page[data-v-40dd17ea] {\n  background: -webkit-gradient(linear, left top, left bottom, from(rgba(255, 255, 255, .72)), color-stop(74.86%, rgba(255, 255, 255, .9)));\n  background: linear-gradient(180deg, rgba(255, 255, 255, .72) 0%, rgba(255, 255, 255, .9) 74.86%);\n  height: 100%;\n}\n.header-bar-mobile .header-bar-content[data-v-40dd17ea] {\n  height: 54px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  background: #fff;\n  position: fixed;\n  -webkit-backdrop-filter: blur(20px);\n          backdrop-filter: blur(20px);\n  left: 0;\n  top: 0;\n  z-index: 99;\n}\n.header-bar-mobile .right[data-v-40dd17ea] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: end;\n      -ms-flex-pack: end;\n          justify-content: flex-end;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-right: 24px;\n  position: relative;\n}\n.header-bar-mobile .nav-screen[data-v-40dd17ea] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  width: 100%;\n  height: 54px;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.header-bar-mobile .curr-lang[data-v-40dd17ea] {\n  margin-right: 8px;\n  width: 18px;\n  height: 20px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.header-bar-mobile .nav-screen-show[data-v-40dd17ea] {\n  position: fixed;\n  height: 54px;\n  z-index: 9999;\n}\n.header-bar-mobile .nav-screen-show .inner_screen[data-v-40dd17ea] {\n  height: 100vh;\n  -webkit-backdrop-filter: blur(240px);\n          backdrop-filter: blur(240px);\n}\n.header-bar-mobile .download-header[data-v-40dd17ea] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  padding: 17px 24px;\n}\n.header-bar-mobile .download-header .logo[data-v-40dd17ea] {\n  width: 77px;\n  height: 24px;\n}\n.header-bar-mobile .close-btn[data-v-40dd17ea] {\n  position: absolute;\n  right: 0;\n  top: 0;\n  -webkit-tap-highlight-color: transparent;\n}\n.header-bar-mobile .close-btn > img[data-v-40dd17ea] {\n  position: absolute;\n  right: 5.3333vw;\n  top: 5.3333vw;\n  width: 3.4667vw;\n  height: 3.4667vw;\n}\n.header-bar-mobile .nav-items[data-v-40dd17ea] {\n  width: 100%;\n  margin-top: 7.49625187vh;\n  margin-right: auto;\n  margin-left: auto;\n  -webkit-tap-highlight-color: transparent;\n}\n.header-bar-mobile .nav-items .nuxt-link-exact-active[data-v-40dd17ea] {\n  color: #00b35d;\n  font-weight: 900;\n}\n.header-bar-mobile .nav-item[data-v-40dd17ea] {\n  text-decoration: none;\n  color: rgba(34, 51, 73, .95);\n  font-weight: 500;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  font-size: 16px;\n  line-height: 16px;\n  padding-top: 32px;\n  height: 13.3333vw;\n  -webkit-tap-highlight-color: transparent;\n  outline: none;\n  font-family: Roboto;\n}\n.header-bar-mobile .nav-8th[data-v-40dd17ea] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  text-decoration: none;\n}\n.header-bar-mobile .nav-8th img[data-v-40dd17ea] {\n  width: 30px;\n  height: 22px;\n  margin-right: 8px;\n}\n.header-bar-mobile .chinese[data-v-40dd17ea],\n.header-bar-mobile .english[data-v-40dd17ea] {\n  cursor: pointer;\n  -webkit-tap-highlight-color: transparent;\n}\n.header-bar-mobile .header_logo[data-v-40dd17ea] {\n  margin-left: 24px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.header-bar-mobile .header_logo img[data-v-40dd17ea] {\n  width: 83px;\n}\n@-webkit-keyframes form-bottom-top-menu-40dd17ea {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(148px);\n            transform: translateY(148px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n@keyframes form-bottom-top-menu-40dd17ea {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(148px);\n            transform: translateY(148px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n.languages-mobile[data-v-40dd17ea] {\n  position: fixed;\n  bottom: 0;\n  right: 0;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100vh;\n  z-index: 999;\n  background: rgba(0, 0, 0, .5);\n}\n.languages-mobile .languages-mobile-container[data-v-40dd17ea] {\n  background: #fff;\n  border-radius: 4px;\n  height: auto;\n  width: 100%;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  position: absolute;\n  bottom: -6px;\n  -webkit-animation: form-bottom-top-menu-40dd17ea 0.2s 0s ease forwards;\n          animation: form-bottom-top-menu-40dd17ea 0.2s 0s ease forwards;\n}\n.languages-mobile .languages-mobile-container .close-button[data-v-40dd17ea] {\n  background: #1fb75c;\n  border-radius: 4px;\n  height: 40px;\n  color: #fff;\n  text-align: center;\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 40px;\n  margin: 10px 16px 20px 16px;\n}\n.languages-mobile .languages-mobile-container .checked[data-v-40dd17ea] {\n  color: #1253fc;\n}\n.languages-mobile .languages-mobile-container a[data-v-40dd17ea] {\n  text-decoration: none;\n  color: inherit;\n}\n.languages-mobile .languages-mobile-container > .lan-selector[data-v-40dd17ea] {\n  position: relative;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  -webkit-transition: height 0.3s;\n  transition: height 0.3s;\n  padding: 0 0;\n  width: 100%;\n  overflow: hidden;\n  -webkit-tap-highlight-color: transparent;\n}\n.languages-mobile .languages-mobile-container > .lan-selector > .language-arrow[data-v-40dd17ea] {\n  position: absolute;\n  top: 10px;\n  right: 20px;\n  width: 20px;\n}\n.languages-mobile .languages-mobile-container > .lan-selector > .lan-item[data-v-40dd17ea] {\n  -webkit-tap-highlight-color: transparent;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: row;\n          flex-direction: row;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: left;\n      -ms-flex-pack: left;\n          justify-content: left;\n  padding-left: 20px;\n  font-size: 16px;\n  height: 54px;\n}\n.languages-mobile .languages-mobile-container > .lan-selector > .lan-item[data-v-40dd17ea]:first-child {\n  margin-top: 0;\n}\n.languages-mobile .languages-mobile-container > .lan-selector > .lan-item > .locale-flag[data-v-40dd17ea] {\n  width: 16px;\n  height: 16px;\n  margin-right: 8px;\n  border-radius: 50%;\n}\n', ""]), D.locals = {}, n.exports = D
    }, function(n, t, e) {
        "use strict";
        e(198)
    }, function(n, t, e) {
        var o = e(14),
            r = e(43),
            c = e(44),
            l = e(45),
            d = e(46),
            f = e(47),
            h = e(48),
            m = e(49),
            x = e(50),
            w = e(51),
            v = e(52),
            y = e(53),
            k = e(54),
            A = e(55),
            C = e(56),
            j = e(57),
            D = o((function(i) {
                return i[1]
            })),
            S = r(c),
            O = r(c, {
                hash: "?#iefix"
            }),
            M = r(l),
            T = r(d),
            I = r(f, {
                hash: "#PingFang-SC-Light"
            }),
            P = r(h),
            _ = r(h, {
                hash: "?#iefix"
            }),
            E = r(m),
            L = r(x),
            N = r(w, {
                hash: "#PingFang-SC-Semibold"
            }),
            B = r(v),
            R = r(v, {
                hash: "?#iefix"
            }),
            z = r(y),
            H = r(k),
            F = r(A, {
                hash: "#PingFang-SC-Regular"
            }),
            U = r(C),
            W = r(j);
        D.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + O + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + M + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + I + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + _ + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + E + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + N + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + B + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + H + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + F + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + W + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n.header_top {\n  height: 13.3333vw;\n}\n.not-found {\n  color: #000000;\n  height: 107.4667vw;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.not-found > .not-found-inner > .pissa {\n  width: 60.4vw;\n  height: 20.4vw;\n}\n.not-found > .not-found-inner > .not-found-detail {\n  margin-top: 7.8667vw;\n}\n.not-found > .not-found-inner > .not-found-detail > .desc {\n  font-size: 5.0667vw;\n  line-height: 7.0667vw;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav {\n  font-size: 4.8vw;\n  line-height: 6.6667vw;\n  margin-top: 6.6667vw;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav > .or {\n  color: #000000;\n  padding: 0 2vw;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav > .btn {\n  display: inline-block;\n  text-decoration: none;\n  color: #0155FF;\n}\n@media (min-width: 960px) {\n.header_top {\n    height: 100px;\n}\n.not-found {\n    min-height: 300px;\n    height: calc(100vh - 3.34028rem);\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n}\n.not-found > .not-found-inner {\n    -webkit-box-flex: 1;\n        -ms-flex: 1;\n            flex: 1;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n}\n.not-found > .not-found-inner > .pissa {\n    width: 324px;\n    height: 118px;\n}\n.not-found > .not-found-inner > .not-found-detail {\n    text-align: left;\n    margin-top: 0;\n    margin-left: 120px;\n    width: 480px;\n}\n.not-found > .not-found-inner > .not-found-detail > .desc {\n    font-size: 38px;\n    line-height: 53px;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav {\n    font-size: 18px;\n    line-height: 25px;\n    margin-top: 0;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav > .or {\n    color: #000000;\n    padding-left: 10px;\n    padding-right: 10px;\n}\n.not-found > .not-found-inner > .not-found-detail > .nav > .btn {\n    display: inline-block;\n    text-decoration: none;\n    color: #0155FF;\n}\n}\n', ""]), D.locals = {}, n.exports = D
    }, function(n, t, e) {
        "use strict";
        e(199)
    }, function(n, t, e) {
        var o = e(14)((function(i) {
            return i[1]
        }));
        o.push([n.i, "\n.nuxt-progress {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  height: 0.2667vw;\n  width: 0%;\n  opacity: 1;\n  -webkit-transition: width 0.1s, opacity 0.4s;\n  transition: width 0.1s, opacity 0.4s;\n  background-color: #0155ff;\n  z-index: 999999;\n}\n.nuxt-progress.nuxt-progress-notransition {\n  -webkit-transition: none;\n  transition: none;\n}\n.nuxt-progress-failed {\n  background-color: #0155ff;\n}\n", ""]), o.locals = {}, n.exports = o
    }, , , function(n, t, e) {
        var content = e(341);
        content.__esModule && (content = content.default), "string" == typeof content && (content = [
            [n.i, content, ""]
        ]), content.locals && (n.exports = content.locals);
        (0, e(15).default)("08b149c4", content, !0, {
            sourceMap: !1
        })
    }, function(n, t, e) {
        var o = e(14)((function(i) {
            return i[1]
        }));
        o.push([n.i, "/**\n * 通用 Mixins ，全局自动引用\n */\n", ""]), o.locals = {}, n.exports = o
    }, function(n, t, e) {
        n.exports = e.p + "img/warn.456d125.png"
    }, function(n, t, e) {
        "use strict";
        e(200)
    }, function(n, t, e) {
        var o = e(14)((function(i) {
            return i[1]
        }));
        o.push([n.i, ".mainland-tip[data-v-2b8ce2b8] {\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, .5);\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 999;\n}\n.mainland-tip .content[data-v-2b8ce2b8] {\n  width: 480px;\n  position: fixed;\n  left: 50%;\n  top: 50%;\n  background: #fff;\n  -webkit-box-shadow: 0px 0px 1px rgba(20, 40, 130, .2), 0px 10px 25px rgba(20, 40, 130, .05);\n          box-shadow: 0px 0px 1px rgba(20, 40, 130, .2), 0px 10px 25px rgba(20, 40, 130, .05);\n  border-radius: 4px;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  padding: 24px;\n  margin: 0 12px 12px 0;\n  text-align: center;\n}\n.mainland-tip .content .title[data-v-2b8ce2b8] {\n  font-weight: 500;\n  font-size: 20px;\n  line-height: 24px;\n  color: #0b121f;\n  margin-bottom: 24px;\n}\n.mainland-tip .content .container[data-v-2b8ce2b8] {\n  overflow-y: auto;\n  margin-bottom: 20px;\n}\n.mainland-tip .content .desc[data-v-2b8ce2b8] {\n  color: rgba(20, 24, 31, .8);\n  font-size: 16px;\n  line-height: 26px;\n}\n.mainland-tip .content .desc .logo-wrapper[data-v-2b8ce2b8] {\n  text-align: center;\n  margin: 12px;\n}\n.mainland-tip .content .desc .logo-wrapper .logo[data-v-2b8ce2b8] {\n  text-align: center;\n  height: 80px;\n}\n.mainland-tip .content .desc p[data-v-2b8ce2b8] {\n  margin: 0 36px 15px;\n  text-align: center;\n  padding: 0px;\n}\n.mainland-tip .content .button-content[data-v-2b8ce2b8] {\n  text-align: center;\n}\n.mainland-tip .content .button[data-v-2b8ce2b8] {\n  cursor: pointer;\n  display: inline-block;\n  background: #1fb75c;\n  border-radius: 6px;\n  min-width: 300px;\n  width: auto;\n  height: 40px;\n  padding: 0 24px;\n  margin: 0 auto;\n  color: #fff;\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 40px;\n  text-align: center;\n}\n.mainland-tip .content[data-v-2b8ce2b8] ::-webkit-scrollbar {\n  width: 0.5333vw;\n  height: 0.5333vw;\n  background-color: transparent;\n}\n.mainland-tip .content[data-v-2b8ce2b8] ::-webkit-scrollbar-thumb {\n  background: #e2e7ed;\n  border-radius: 5px;\n}\n@media screen and (max-width: 767px) {\n.mainland-tip .content[data-v-2b8ce2b8] {\n    width: calc(100% - 48px);\n}\n.mainland-tip .content .button[data-v-2b8ce2b8] {\n    width: 100%;\n}\n}\n", ""]), o.locals = {}, n.exports = o
    }, function(n, t, e) {
        "use strict";
        e(201)
    }, function(n, t, e) {
        var o = e(14)((function(i) {
            return i[1]
        }));
        o.push([n.i, "\nbody,\nhtml {\n    margin: 0;\n    padding: 0;\n    width: 100vw;\n    overflow-x: hidden;\n    background-color: #ffffff;\n}\nbody {\n    padding-bottom: constant(safe-area-inset-bottom);\n    padding-bottom: env(safe-area-inset-bottom);\n}\n* {\n    -webkit-box-sizing: border-box;\n            box-sizing: border-box;\n}\nh1,\nh2,\nh3 {\n    font-size: inherit;\n    font-weight: normal;\n    margin: 0;\n    -webkit-margin-before: 0;\n    -webkit-margin-after: 0;\n    -webkit-margin-start: 0;\n    -webkit-margin-end: 0;\n}\nul,\nmenu,\ndir {\n    display: block;\n    list-style-type: none;\n    -webkit-margin-before: 0em;\n    -webkit-margin-after: 0em;\n    -webkit-margin-start: 0px;\n    -webkit-margin-end: 0px;\n    -webkit-padding-start: 0px;\n}\n#app {\n    font-family: 'PingFang-SC-Light', Helvetica, Arial, sans-serif;\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n    text-align: center;\n    position: relative;\n    margin: 0 auto;\n    overflow: visible;\n    background-color: #ffffff;\n}\n/*.en {*/\n/*  font-family:  'Roboto-Condensed', sans-serif;*/\n/*}*/\n.main-body {\n    position: relative;\n    margin-left: auto;\n    margin-right: auto;\n    max-width: 1440px;\n}\n", ""]), o.locals = {}, n.exports = o
    }, function(n, t, e) {
        "use strict";
        e.r(t), e.d(t, "state", (function() {
            return o
        })), e.d(t, "mutations", (function() {
            return r
        }));
        var o = function() {
                return {
                    locales: ["en", "zh", "tw", "ja", "ko", "ru", "es", "vi", "id"],
                    locale: "en",
                    enableDownload: !0,
                    cookiesShow: !0
                }
            },
            r = {
                SET_LANG: function(n, t) {
                    -1 !== n.locales.indexOf(t) && (n.locale = t)
                },
                SET_COOKIES: function(n) {
                    n.cookiesShow = !1
                }
            }
    }, function(n, t, e) {
        "use strict";
        e.r(t), e.d(t, "deviceType", (function() {
            return o
        })), e.d(t, "state", (function() {
            return r
        })), e.d(t, "getters", (function() {
            return c
        })), e.d(t, "mutations", (function() {
            return l
        })), e.d(t, "actions", (function() {
            return d
        }));
        var o = {
                mobile: "mobile",
                pc: "pc",
                tablet: "tablet"
            },
            r = function() {
                return {
                    type: o.mobile
                }
            },
            c = {
                deviceType: function(n) {
                    return n.type
                }
            },
            l = {
                SET_DEVICE_TYPE: function(n, t) {
                    t && (n.type !== t && (n.type = t), window.localStorage.setItem("device", t))
                }
            },
            d = {}
    }, function(n) {
        n.exports = JSON.parse('{"404":"Sorry, the page you’re looking for cannot be found.","hbWallet":"iToken HD","hbDesc":"A Secure and Professional DeFi Wallet","hbDesc2":"Professional and Multi-chain","hbDesc3":"<span>Secure</span> <span>Multi-Chain Support</span> <span>DeFi’s Gateway</span>","iosDownload":"iOS","androidDownload":"Android Download","sec4Title":"Partners","helpCenter":"Help Center","contactUS":"Contact Us","aboutUS":"About Us","joinUS":"Join us","iosWallet":"Crypto Wallet for iOS","androidWallet":"Crypto Wallet for Android","scanQR":"Scan QR Code","help":"Help Center","homeMenu":"Features","notice":"Announcement","userSupport":"INFORMATION","walletTeam":"ITOKEN HD WALLET","faq":"FAQ","question1":{"description":"How to Create a Wallet","url":"https://support.huobiwallet.io/hc/en-us/articles/11960692300955-How-to-Create-a-Wallet-in-3-Steps-"},"question2":{"description":"How to Make a Transfer","url":"https://support.huobiwallet.io/hc/en-us/sections/4861914325019-Transfer-related"},"question3":{"description":"How to Buy Crypto","url":"https://support.huobiwallet.io/hc/en-us/articles/7062985559579-Buying-Crypto-with-Fiat-Currency"},"question4":{"description":"How to Withdraw Assets from Exchanges ","url":"https://support.huobiwallet.io/hc/en-us/articles/11961284263707-How-to-Withdraw-assets-from-Huobi-Global-to-iToken-Wallet"},"sub":"Subscribe","news":"Quickly obtain new information on iToken HD","answer":"FAQ","userProtocol":"User Agreement","goDown":"Download in App Store","huobi":"iToken HD","iToken":"iToken HD","aboutIToken":"About iToken HD","about1":"iToken HD is a professional multi-coin light wallet. iToken HD ensures asset security of global digital coin users from multiple dimensions, and provides simple, convenient, safe and reliable digital asset management services.","about2":"The new, upgraded version of iToken HD has a more professional user interface design. After opening the app, you can browse assets and make quick transfer payments all on the home screen. Users can add their favorite coins in addition to the top eight coins ( BTC, ETH, EOS, TRX, USDT,etc.) that are already included into the app. iToken HD supports the search of all ERC20 tokens, so that the management of assets is comprehensive and convenient.","about3":"iToken HD users have sole control over their own private keys and thus have full control over their assets. There are no third parties involved in management of private keys. Users can backup mnemonic phrases and export private keys for asset security purposes, and can also rename or hide wallet according to their personal preferences. iToken HD is designed for superior user experience.","about4":"iToken HD provides the option for quick exchange, which supports the exchange of different coins between chains. Users can easily and quickly do transactions using their favorite digital coins under the current exchange rate.","about5":"Alongside an upgraded security system made especially to protect your assets, the iToken HD team has created a specialized keyboard that ensures your information is protected. In addition to security isolation, data encryption, and other patent security technologies, the security of your assets is assured by iToken HD Security Team. ","about6":"Attentive design. Simple focus. Value circulation. The pursuit of excellence. The iToken HD team strives to move forward in order to provide quality and professional digital asset management services.","targetTitle":"Goal and Vision","targetDesc":"Optimize financial services. Liberate global wealth. Protect user privacy. ","joinWallet":"With iToken HD","challenge":"We redefine excellence together","whyHuobi":"Why Choose iToken HD?","jiaoYiLiang":"Global Trade Volume","touZiQiYe":"Investment Enterprises","fuGaiGuoJia":"Countries We Cover","developTitle":"Rapidly Developing Sector","developDesc":"Since its establishment in 2013, the cumulative trading volume of the iToken HD Platform has exceeded $1 trillion. At one point, it was the world\'s largest digital asset trading platform and accounted for 50% of the world\'s digital asset trading shares. The group won the real fund and received investment from Sequoia Capital. It has also completed the establishment of compliance service teams in Singapore, the United States, Japan, South Korea, Hong Kong, Thailand, Australia and other countries. They did this in order to provide secure and reliable digital asset transactions and asset management for millions of users in more than 130 countries around the world.","teamName":"iToken HD Team","teamDesc":"The team consists of graduates from Yale, Tsinghua, Peking University, Fudan, Hong Kong University of Science and Technology, Columbia University and the University of California- Berkeley. They are an elite group that has years of experience working for well-known Internet companies, including Google, Baidu, Tencent, and Xiaomi. ","joinMail":"Recruitment Mailbox","happy":"Laidback Atmosphere","happyDesc":"We come from the greatest galactic war squadron in the entire universe. We are the hot-blooded youth of blockchain. We are the hard working and enthusiastic youth. ","joinTitle":"Join our extraordinary team! ","howInstall":"How to install?","install1":"1. Click on the App Store icon ","install2":"2. Click the avatar icon in the top right corner of the \\"Today\\" section to enter the account page.","install3":"3. Once you have gotten to the account page, click to logout of your account. ","install4":"4. Fill in the App Store account and password (copy recommended), then enter and press Login","install5":"5. Once you have successfully logined in, type in \\"iToken HD\\" into the search bar and click to download the app. ","follow":"Follow us","day":"D","hour":"H","minute":"M","second":"S","returnHome":"Return home","findHelp":"Find Help","or":"OR","appStoreDownload":"App Store Download","homeTitle":"iToken HD | A Secure Multi-Chain DeFi Crypto Wallet. Your Gateway to Web 3.0","homeKeywords":"iToken HD,iToken HD,iToken HD,DApp,Bitcoin,Ethereum,EOS,TRON","homeDesc":"iToken HD is a professional multi-currency wallet. iToken HD supports the storage, transfer, and cross-chain exchange of BTC, ETH, EOS, TRX and other mainstream currencies. DApps are also supported.","aboutTitle":"About Us | iToken HD","aboutDesc":"iToken HD is a professional multi-currency wallet. iToken HD supports the storage, transfer, and cross-chain exchange of BTC, ETH, EOS, TRX and other mainstream currencies. DApps are also supported.","aboutKeywords":"iToken HD,iToken HD,DApp,Bitcoin,Ethereum,EOS,TRON","joinPageTitle":"Join us | iToken HD","joinDesc":"iToken HD is a professional multi-currency wallet. iToken HD supports the storage, transfer, and cross-chain exchange of BTC, ETH, EOS, TRX and other mainstream currencies. DApps are also supported.","joinKeywords":"iToken HD,iToken HD,DApp,Bitcoin,Ethereum,EOS,TRON","huobiOTC":"iToken HD OTC","downloadTitle":"Professional and Multi-chain","downloadIconTitle":"iToken HD","downloadStoreButton":"App Store Download","downloadAppButton":"Install in-house App","downloadAndroidButton":"Download","downloadStatement":"If you receive an \\"Untrusted Enterprise Developer\\" alert, you can go to \\"Settings -> General -> Profile & Device Management -> Select Profile -> Trust\\" to use the app.","comingSoon":"App is coming soon, Stay tuned.","downloadTwoTitle":"Installation Tutorial","downloadTwoStepOne":"1. This pop-up shows up when iToken HD is opened for the first time.","downloadTwoStepTwo":"2. Head over to Settings -> General -> Device Management to find the certification for iToken HD.","downloadTwoStepThree":"3. Click to trust the enterprise certificate to start using iToken HD.","downloadButton":"Download","downloadPageTitle":"iToken HD Download | Professional and Multi-chain","downloadKeywords":"iToken HD,iToken HD,iToken HD,iToken HD","assetUI":"Asset Page","androidDownloadText":"Android Download","iosDownloadText":"iOS Download","cloudWallet":"Cloud Wallet","androidLocalDownloadText":"Android Apk","appStoreDownloadText":"App Store","googlePlayDownloadText":"Download it on Google play","secDappTitle":"Our editors hand-pick DApps<br/>Enjoying the best experience","secDappSubTitle":"An open and win-win DApp ecosystem","secDappDesc":"Rich and diverse applications, smooth browsing environment<br/>Multiple access methods, complete DApp SDK documentation","activityAnnouncement":"Activity","productAnnouncement":"Product","otherAnnouncement":"Announcement","newsAnnouncement":"News","announcement":"Blog","announcementTitle":"iToken HD News | Official Announcement, Latest News, and Crypto Academy | DApp, DeFi, NFT, Web3","nav8th":"Carnival","wallet":"Wallet","close":"Close","home":{"warmPrompt":{"title":"Tips","desc":"To download the App Store version, you will need to have an Apple ID from an unrestricted area","buttonText":"I have already got one. Go to download.","linkTips":"How to I register an Apple ID from an unrestricted country/region?"},"ani1":{"title":"All-in-One App for Your <b>Digital Assets</b>","desc1":"Security Detection","desc2":"HD Wallet","desc3":"Browser for DApp","desc4":"Collect NFT","desc5":"Safely store 1M+ cryptocurrencies","desc6":"Real-time market data"},"ani2":{"block1":{"title":"An Innovative Crypto Wallet with <span>Multi-Chain Support</span>","desc1":"Simplest way to track, send, store, exchange & buy Cryptos, and invest in NFTs."},"block2":{"title":"<span>Your Key</span> to the World of Web 3.0","desc1":"Get the up-to-date market trends at our built-in TVL Ranking & DeFi Explorer & NFT Industry Data Aggregator.","desc2":"Find a latest overview of the DeFi\'s market cap, trending NFTs and top projects in one place.","desc3":"—NFT, DeFi, DAO, DApp, Cryptocurrency, GameFi, etc."},"block3":{"title":"Prioritize <span>User Asset Security</span> Above All","desc1":"- Enjoy full control over your assets with custody of your private keys.","desc2":"- Security Detection Functions to effectively detect the risks of your wallet.","desc3":"- Patented technologies in data isolation and encryption to safeguard mnemonics, private keys, and transaction security.","desc4":"- Our Customer Support is available 24/7 to answer any of your questions regarding iToken HD."},"block4":{"title":"Easiest Way to <span>Buy Cryptos</span> With a Bank Card","desc1":"Buy Cryptos through multiple ramps around the world with your Credit/Debit Cards.","desc2":"Make your first investment in Bitcoin, Ethereum, and many other cryptocurrencies. "}},"ani3":{"title":"Start Your Journey in <b>3 Steps</b>","desc1":"Download iToken HD","desc2":"Create Wallet","desc3":"Deposit Crypto","download":"Download Now"},"footer":{"title":"Download iToken HD to start your DeFi journey","desc":"Locally store private keys through multiple local encryption algorithms to ensure asset<br/>security. We cannot collect any personal information.","android":"Android Download","ios":"iOS","linkGroup":[{"title":"ITOKEN HD WALLET","link":["About Us","Crypto Wallet for iOS","Crypto Wallet for Android"],"url":["About","https://itokenwallet.onelink.me/KBT5/Site2AS2","https://play.google.com/store/apps/details?id=com.huobionchainwallet.itokenhd"]},{"title":"INFORMATION","link":["User Agreement"],"url":["/protocols/en.html"]}],"follow":{"title":"Follow us"},"downLoadTips":"Download iToken HD to start your DeFi journey","downLoadDesc":"Your private keys of wallet is the only way to keep your digital assets safe. We will never collect or access your private keys or mnemonics of your wallets."}},"iKnow":"Got it","iAgree":"我同意 / I Agree","joinNow":"Start your journey of blockchain now. Choices by 10 million of users worldwide.","bannerDesc":"A Global Crypto Wallet & Gateway to <span>Web 3.0</span>","globalCreateAccount":"","goDownload":"Download","android":"Android","iOS":"iOS","openCefiDefi":"Start the journey of one-click CeFi - DeFi","walletAdvantage":"Cloud Wallet Advantages","walletCharacteristic":"Secure, Convenient and Smooth","walletCourse":"View Tutorial","walletCreate":"How to Create a Cloud Wallet?","walletCreateAccount":"","walletInfo":"Built for entry-level users, no need to secure private keys","walletInfoDetail":"Participate with DeFi projects with one click","walletInfoH5":"Built for entry-level users, no need to secure private keys","walletKey":"Private keys protected","walletPlatform":"Multi-chain interaction","walletProject":"Display strictly selected projects","walletSafe":"Safe and Secure","walletSec":"Safeguarded assets by the security technology of iToken","whatWallet":"What is a Cloud Wallet?","androidTitle":"iToken HD  for Android ","iosTitle":"iToken HD  for iOS","androidTitleDes":"A Global Crypto Wallet & Gateway to Web 3.0","androidTitleSys":"System: Android <span> and above","iosTitleSys":"System: iOS <span> and above","updateTime":"Update time:","version":"Version:","size":"size:","warningTitle":"Only download apps from official stores like the App Store (for iOS) or Google Play Store (for Android) and review the permissions that are requested. Make sure they are genuinely necessary. iToken do not provide any third party download packages for any channels.","warningTitleShort":"Only download apps from official stores like the App Store (for iOS) or Google Play Store (for Android).","qrDownLoad":"Scan to Download","downTips":"Please download the app from the official website and check the latter\'s SSL certificate.","downTipsSafe":"Please keep your private keys and mnemonics safe.","checkAPK":"Verify APK File","howChekApk":"How to verify","GpgCheck":"GPG Verification","recommend":"Recommended","pubKey":"Public Key Fingerprint：","signKey":"Signature File：","pointDown":"Download","256Check":"SHA256 Verification","checkApkContent":"Please make sure the APK file downloaded from Google Play is developed by <span>「BlazekTech Internet Technology Service Limited」</span>","checkIosContent":"Please make sure the app downloaded from App Store is developed by <span>「BlazekTech Internet Technology Service Limited」</span>","checkApkContent2":"Please verify the authenticity of the APK file downloaded from the official website or any other channels."}')
    }, , , , function(n, t) {}],
    [
        [250, 65, 17, 66]
    ]
]);