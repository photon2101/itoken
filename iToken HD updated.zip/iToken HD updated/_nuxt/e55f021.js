(window.webpackJsonp = window.webpackJsonp || []).push([
    [10], {
        1074: function(n, t, e) {
            "use strict";
            e.r(t);
            var o = e(23),
                r = e(2),
                c = (e(31), e(25), e(24), e(16), e(147)),
                l = e(37),
                d = e(1),
                f = (e(243), e(17)),
                h = e(460),
                m = e.n(h),
                x = e(245);
            d.a.use(x);
            var w = {
                    name: "Header",
                    components: {
                        headerBar: c.a
                    },
                    mixins: [f.a],
                    props: ["appstore", "googlePlayAndroidDownload", "testflight", "newsList"],
                    data: function() {
                        return {
                            registerUrl: "https://www.yuque.com/docs/share/4fa4747b-0293-4841-b473-213573296f38?#",
                            qrImgUrl: "",
                            enableDownload: !0,
                            showVideo: !1,
                            videoStyle: {
                                width: "0px",
                                height: "0px"
                            },
                            smile: m.a,
                            playerOptions: {
                                autoplay: !1,
                                playbackRates: [.7, 1, 1.5, 2],
                                sources: [{
                                    type: "video/mp4",
                                    src: "https://static.huobiwallet.com/resources/videos/huobiwallet_introduction_video_720p.mp4"
                                }]
                            },
                            androidDownloadModalVisible: !1,
                            noticeList: "",
                            androidDownload: ""
                        }
                    },
                    created: function() {
                        this.getQrCode()
                    },
                    computed: {
                        isClient: function() {
                            return "undefined" != typeof window
                        },
                        isP: function() {
                            return window.innerWidth < window.innerHeight
                        },
                        isZH: function() {
                            return "zh" === this.$i18n.locale
                        },
                        isJA: function() {
                            return "ja" === this.$i18n.locale
                        },
                        isKO: function() {
                            return "ko" === this.$i18n.locale
                        },
                        isRU: function() {
                            return "ru" === this.$i18n.locale
                        },
                        isEN: function() {
                            return "en" === this.$i18n.locale
                        },
                        isTW: function() {
                            return "tw" === this.$i18n.locale
                        },
                        tabNews: function() {
                            return this.newsList ? this.newsList.news[this.$i18n.locale] ? this.newsList.news[this.$i18n.locale] : this.newsList.news.en || this.newsList.news.zh : {}
                        },
                        newsListData: function() {
                            return (this.tabNews.homeIndexNotice || []).filter((function(n, t) {
                                return !n.updateTime || (new Date).getTime() >= n.updateTime
                            }))
                        }
                    },
                    mounted: function() {
                        var n = this,
                            t = l.default.isMobile();
                        this.setSize(), this.onOrientationChange = function() {
                            n._onOrientationChange()
                        }, t ? (window.screen.orientation && window.screen.orientation.addEventListener("change", this.onOrientationChange), !window.screen.orientation && window.addEventListener("orientationchange", this.onOrientationChange)) : window.addEventListener("resize", this.onResize)
                    },
                    beforeDestroy: function() {
                        l.default.isMobile() ? (window.screen.orientation && window.screen.orientation.removeEventListener("change", this.onOrientationChange), !window.screen.orientation && window.removeEventListener("orientationchange", this.onOrientationChange)) : window.removeEventListener("resize", this.onResize)
                    },
                    methods: {
                        noticeLinkClick: function(text, n) {
                            this.reqBuriedData("PC_Notice", {
                                SelectContent: text,
                                Entrance: "产品公告"
                            }), window.open(n)
                        },
                        getQrCode: function() {
                            var n = this;
                            return Object(r.a)(regeneratorRuntime.mark((function t() {
                                var param;
                                return regeneratorRuntime.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return param = {
                                                key: "wallet_qrcode"
                                            }, t.next = 3, n.$axios.get("/dgg/index/property", {
                                                params: param
                                            }).then((function(data) {
                                                data = JSON.parse(data.data.data), Object.keys(data).length && (n.qrImgUrl = n.isZH ? data.zhCode : data.enCode, n.androidDownload = data.apkUrl)
                                            })).catch((function(n) {
                                                console.log("请求失败2")
                                            }));
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        },
                        getUrlAndTitle: function() {
                            var n = {
                                title: "",
                                url: ""
                            };
                            return this.newsListData && this.newsListData.length && (n.title = this.newsListData[0].title, n.url = this.newsListData[0].url), n
                        },
                        downloadGoogleStore: function(n) {
                            this.reqBuriedData("PC_DownloadResults", {
                                Entrance: "顶部导航下载按键",
                                BackupResult: !0,
                                DownloadMethod: "Google Play"
                            }), this.gtag_report_conversion(this.googlePlayAndroidDownload)
                        },
                        downloadAndroidAPK: function(n) {
                            this.reqBuriedData("PC_DownloadResults", {
                                Entrance: "顶部导航下载按键",
                                BackupResult: !0,
                                DownloadMethod: "AndroidApk"
                            }), location.href = this.androidDownload
                        },
                        _onOrientationChange: function() {
                            var n, t = this,
                                e = -90 === window.orientation || 90 === window.orientation;
                            if (e) this.$refs.videoCon.style.width = "100vw", this.$refs.videoCon.style.height = "100vh";
                            else {
                                setTimeout((function() {
                                    t.$refs.videoCon.style.width = "100vw";
                                    var n = t.$refs.videoCon.getBoundingClientRect().width;
                                    t.$refs.videoCon.style.height = 609 * n / 1082 + "px"
                                }), 200)
                            }
                            e && this.showVideo ? (n = this.$refs.videoCon).requestFullscreen ? n.requestFullscreen() : n.mozRequestFullScreen ? n.mozRequestFullScreen() : n.webkitRequestFullscreen ? n.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT) : n.msRequestFullscreen ? n.msRequestFullscreen() : n.webkitEnterFullscreen ? n.webkitEnterFullscreen() : console.log("no requestFullscreen functionality detected") : (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement) && function(n) {
                                document.cancelFullscreen ? document.cancelFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen ? document.msExitFullscreen() : n && n.webkitExitFullscreen ? n.webkitExitFullscreen() : console.log("no cancelFullscreen functionality detected")
                            }(this.$refs.videoCon)
                        },
                        setSize: function() {
                            var n = window.innerWidth,
                                t = window.innerHeight,
                                e = 1082,
                                o = 609,
                                r = n / t,
                                c = e / o;
                            if (n <= 960)
                                if (r > c) {
                                    var l = e * t / o;
                                    this.videoStyle = {
                                        height: "100vh",
                                        width: l + "px"
                                    }
                                } else {
                                    var d = o * n / e;
                                    this.videoStyle = {
                                        height: d + "px",
                                        width: "100vw"
                                    }
                                }
                            else if (r > c) {
                                var f = .8 * t,
                                    h = e * t * .8 / o;
                                this.videoStyle = {
                                    height: f + "px",
                                    width: h + "px"
                                }
                            } else {
                                var m = .8 * n,
                                    x = o * n * .8 / e;
                                this.videoStyle = {
                                    width: m + "px",
                                    height: x + "px"
                                }
                            }
                            this.$refs.videoCon && (this.$refs.videoCon.style.width = this.videoStyle.width, this.$refs.videoCon.style.height = this.videoStyle.height)
                        },
                        onIOSClick: function(n) {
                            this.reqBuriedData("PC_DownloadResults", {
                                Entrance: "顶部导航下载按键",
                                BackupResult: !1,
                                DownloadMethod: "App Store"
                            }), this.gtag_report_conversion(this.appstore)
                        },
                        downloadNow: function() {},
                        gtag_report_conversion: function(n) {
                            return gtag("event", "conversion", {
                                send_to: "AW-10826892364/pzK9CLSt37wDEMyI1aoo",
                                event_callback: function() {
                                    void 0 !== n && (window.location = n)
                                }
                            }), !1
                        },
                        onAndroidClick: function(n) {
                            void 0 !== n && window.innerWidth >= 960 || this.onAndroidHover()
                        },
                        onAndroidHover: function(n) {
                            var t = this;
                            void 0 !== n && window.innerWidth < 960 || (this.delayHover = setTimeout((function() {
                                t.$refs.androidDownloadList.style.display = "block", t.androidDownloadModalVisible = !0
                            }), 200))
                        },
                        hideHover: function() {
                            clearTimeout(this.delayHover)
                        },
                        onAndroidOut: function(n) {
                            var t = this;
                            void 0 !== n && window.innerWidth < 960 || (this.androidDownloadModalVisible = !1, setTimeout((function() {
                                t.$refs.androidDownloadList.style.display = "none"
                            }), 300))
                        },
                        closeAndroidDownloadModal: function() {
                            this.onAndroidOut()
                        }
                    }
                },
                y = (e(908), e(910), e(3)),
                v = Object(y.a)(w, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", {
                        staticStyle: {
                            position: "relative"
                        }
                    }, [t("header-bar"), n._v(" "), t("div", {
                        staticClass: "top-header top-header-pc",
                        class: n.isZH ? "" : "top-header-pc-new"
                    }, [t("div", {
                        staticClass: "top-header-content"
                    }, [t("div", {
                        staticClass: "left"
                    }, [t("div", {
                        staticClass: "title",
                        class: n.isZH || n.isTW ? "" : "title-en"
                    }, [n.isZH ? [t("span", {
                        staticClass: "wallet is-title-en",
                        domProps: {
                            innerHTML: n._s(n.$t("bannerDesc").replace("<span>", "<span class='smileCPositon'>"))
                        }
                    }), n._v(" "), t("p", {
                        staticClass: "wallet-desc",
                        domProps: {
                            innerHTML: n._s(n.$t("joinNow"))
                        }
                    })] : n.isTW ? [t("span", {
                        staticClass: "wallet",
                        class: n.isZH ? "" : "is-title-en",
                        domProps: {
                            innerHTML: n._s(n.$t("bannerDesc").replace("<span>", "<span class='smileTPositon'>"))
                        }
                    }), n._v(" "), t("p", {
                        staticClass: "wallet-desc",
                        domProps: {
                            innerHTML: n._s(n.$t("joinNow"))
                        }
                    })] : [t("span", {
                        staticClass: "wallet is-title-en",
                        domProps: {
                            innerHTML: n._s(n.$t("bannerDesc").replace("<span>", "<span class='smilePositon'>"))
                        }
                    }), n._v(" "), t("p", {
                        staticClass: "wallet-desc is-desc-en",
                        domProps: {
                            innerHTML: n._s(n.$t("joinNow"))
                        }
                    })]], 2), n._v(" "), t("div", {
                        staticClass: "download-info relative",
                        class: n.isZH ? "" : "download-info-new"
                    }, [t("router-link", {
                        staticClass: "download_btn ios_btn",
                        attrs: {
                            to: n.$i18n.path("install")
                        },
                        on: {
                            click: n.downloadNow
                        }
                    }, [t("img", {
                        staticClass: "ios_icon",
                        attrs: {
                            src: e(246)
                        }
                    }), n._v(" "), t("div", {
                        staticClass: "phone"
                    }, [n._v(n._s(n.$t("downloadAndroidButton")))])])], 1), n._v(" "), t("div", {
                        staticClass: "des-content-step1"
                    }, [t("img", {
                        staticClass: "des-content-step1-img",
                        attrs: {
                            src: e(467),
                            alt: "*"
                        }
                    }), n._v(" "), t("span", {
                        staticClass: "des-content-step1-text"
                    }, [n._v(n._s(n.$t("warningTitleShort")))])])]), n._v(" "), t("div", {
                        staticClass: "right banner-png"
                    }, [t("img", {
                        staticClass: "phone1",
                        class: n.isZH ? "" : "phone1-en",
                        attrs: {
                            alt: n.$t("assetUI"),
                            src: e(907)
                        }
                    })])])])], 1)
                }), [], !1, null, null, null).exports,
                A = e(468),
                k = e.n(A),
                M = e(668),
                C = e.n(M),
                I = e(669),
                S = e.n(I),
                j = e(670),
                z = e.n(j),
                T = e(671),
                _ = e.n(T),
                D = e(672),
                E = e.n(D),
                N = e(673),
                L = e.n(N),
                O = {
                    name: "Section1",
                    props: ["top"],
                    data: function() {
                        return {
                            selfTop: 0,
                            wh: 0,
                            isPlaying: !1,
                            playTimes: 0,
                            descList: [{
                                icon: C.a,
                                text: this.$t("home.ani1.desc1")
                            }, {
                                icon: S.a,
                                text: this.$t("home.ani1.desc2")
                            }, {
                                icon: z.a,
                                text: this.$t("home.ani1.desc3")
                            }],
                            descListTwo: [{
                                icon: _.a,
                                text: this.$t("home.ani1.desc4")
                            }, {
                                icon: E.a,
                                text: this.$t("home.ani1.desc5")
                            }, {
                                icon: L.a,
                                text: this.$t("home.ani1.desc6")
                            }],
                            scollCurr: !1
                        }
                    },
                    computed: {
                        isZH: function() {
                            return "zh" === this.$i18n.locale
                        }
                    },
                    mounted: function() {
                        var n = this;
                        this.onResize = function() {
                            n.transform()
                        }, window.addEventListener("resize", this.onResize), window.addEventListener("scroll", this.onScroll), this.transform(), this.onScroll()
                    },
                    beforeDestroy: function() {
                        window.removeEventListener("resize", this.onResize), window.removeEventListener("scroll", this.onScroll)
                    },
                    methods: {
                        onScroll: function() {
                            console.log(window.scrollY), window.scrollY > 300 && (this.scollCurr = !0)
                        },
                        transform: function() {
                            if (this.$refs.aniCon) {
                                var rect = this.$refs.aniCon.getBoundingClientRect(),
                                    n = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
                                (void 0 !== rect.top || void 0 !== rect.x) && (this.selfTop = rect.top + n), this.wh = window.innerHeight;
                                var t = 1;
                                window.innerWidth <= 960 && (t = window.innerWidth / 750), k()(this.$refs.aniCon, "transform", "scale(".concat(t, ")"))
                            }
                        }
                    }
                },
                P = (e(912), e(914), Object(y.a)(O, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", {
                        staticClass: "section1-con-pc",
                        class: n.isZH ? "" : "section1-con-pc-en",
                        attrs: {
                            id: "feature"
                        }
                    }, [t("div", {
                        staticClass: "content"
                    }, [t("h2", {
                        staticClass: "section1-title",
                        class: n.isZH ? "" : "section1-title-en",
                        domProps: {
                            innerHTML: n._s(n.$t("home.ani1.title"))
                        }
                    }), n._v(" "), t("div", {
                        staticClass: "desc-list",
                        class: [n.scollCurr ? "anmation-add" : "", n.isZH ? "" : "desc-list-en"]
                    }, [t("div", {
                        staticClass: "text-con"
                    }, n._l(n.descList, (function(e) {
                        return t("div", {
                            key: e.text
                        }, [t("img", {
                            attrs: {
                                src: e.icon,
                                alt: ""
                            }
                        }), n._v(" "), t("p", {
                            domProps: {
                                innerHTML: n._s(e.text)
                            }
                        })])
                    })), 0), n._v(" "), t("div", {
                        staticClass: "text-con text-padding"
                    }, n._l(n.descListTwo, (function(e) {
                        return t("div", {
                            key: e.text
                        }, [t("img", {
                            attrs: {
                                src: e.icon,
                                alt: ""
                            }
                        }), n._v(" "), t("p", {
                            domProps: {
                                innerHTML: n._s(e.text)
                            }
                        })])
                    })), 0)])])])
                }), [], !1, null, "8cfba5d2", null).exports),
                H = e(674),
                R = e.n(H),
                Y = e(675),
                Z = e.n(Y),
                B = e(676),
                U = e.n(B),
                F = (e(677), {
                    name: "Section2",
                    props: ["top"],
                    data: function() {
                        return {
                            selfTop: 0,
                            wh: 0,
                            isPlaying: !1,
                            playTimes: 0,
                            descList: [{
                                icon: R.a,
                                text: this.$t("home.ani2.block1.title"),
                                desc1: this.$t("home.ani2.block1.desc1"),
                                scollCurr: !1
                            }, {
                                icon: Z.a,
                                text: this.$t("home.ani2.block2.title"),
                                desc1: this.$t("home.ani2.block2.desc1"),
                                desc2: this.$t("home.ani2.block2.desc2"),
                                desc3: this.$t("home.ani2.block2.desc3"),
                                scollCurr: !1
                            }, {
                                icon: U.a,
                                text: this.$t("home.ani2.block3.title"),
                                desc1: this.$t("home.ani2.block3.desc1"),
                                desc2: this.$t("home.ani2.block3.desc2"),
                                desc3: this.$t("home.ani2.block3.desc3"),
                                desc4: this.$t("home.ani2.block3.desc4"),
                                scollCurr: !1
                            }]
                        }
                    },
                    computed: {
                        isZH: function() {
                            return "zh" === this.$i18n.locale
                        },
                        isEN: function() {
                            return "en" === this.$i18n.locale
                        }
                    },
                    mounted: function() {
                        var n = this;
                        this.onResize = function() {
                            n.transform()
                        }, window.addEventListener("resize", this.onResize), window.addEventListener("scroll", this.onScroll), this.transform()
                    },
                    beforeDestroy: function() {
                        window.removeEventListener("resize", this.onResize), window.removeEventListener("scroll", this.onScroll)
                    },
                    methods: {
                        onScroll: function() {
                            console.log(window.scrollY), window.scrollY > 730 && (this.descList[0].scollCurr = !0), window.scrollY > 1e3 && (this.descList[1].scollCurr = !0), window.scrollY > 1414 && (this.descList[2].scollCurr = !0), window.scrollY > 1800 && (this.descList[3].scollCurr = !0);
                            var n = this.selfTop - this.top;
                            if ((n < 0 || n >= this.wh) && (this.isPlaying = !1), n > 0 && n < .9 * this.wh && !this.isPlaying && this.playTimes < 1 && (this.isPlaying = !0, this.playTimes = this.playTimes + 1, "undefined" != typeof HaikuComponentEmbed_tsinrong_walletmotion2)) HaikuComponentEmbed_tsinrong_walletmotion2(this.$refs.aniCon, {
                                loop: !1
                            })
                        },
                        transform: function() {
                            if (this.$refs.aniCon) {
                                var n = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0,
                                    rect = this.$refs.aniCon.getBoundingClientRect();
                                (void 0 !== rect.top || void 0 !== rect.x) && (this.selfTop = rect.top + n), this.wh = window.innerHeight;
                                var t = 1;
                                window.innerWidth <= 960 && (t = window.innerWidth / 750), k()(this.$refs.aniCon, "transform", "scale(".concat(t, ")"))
                            }
                        }
                    }
                }),
                Q = (e(916), e(918), Object(y.a)(F, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", {
                        staticClass: "section2-con-pc"
                    }, [t("div", {
                        staticClass: "content"
                    }, n._l(n.descList, (function(e, o) {
                        return t("div", {
                            key: e.text,
                            staticClass: "desc-list"
                        }, [t("img", {
                            class: e.scollCurr ? "anmation-add" : "",
                            attrs: {
                                src: e.icon,
                                alt: ""
                            }
                        }), n._v(" "), t("div", {
                            staticClass: "text-con"
                        }, [t("h2", {
                            staticClass: "section2-title",
                            class: [n.isZH ? "" : "section2-title-en"],
                            domProps: {
                                innerHTML: n._s(e.text)
                            }
                        }), n._v(" "), t("div", {
                            staticClass: "desc"
                        }, [t("span", {
                            domProps: {
                                innerHTML: n._s(e.desc1)
                            }
                        }), n._v(" "), t("span", {
                            domProps: {
                                innerHTML: n._s(e.desc2)
                            }
                        }), n._v(" "), t("span", {
                            domProps: {
                                innerHTML: n._s(e.desc3)
                            }
                        }), n._v(" "), t("span", {
                            domProps: {
                                innerHTML: n._s(e.desc4)
                            }
                        }), n._v(" "), t("span", {
                            domProps: {
                                innerHTML: n._s(e.desc5)
                            }
                        })])])])
                    })), 0)])
                }), [], !1, null, "5d2ef18f", null).exports),
                $ = [function() {
                    var n = this._self._c;
                    return n("div", {
                        staticClass: "shares"
                    }, [n("a", {
                        attrs: {
                            "data-event": "C_Twitter",
                            href: "https://twitter.com/iTokenWallet",
                            target: "_blank"
                        }
                    }, [n("img", {
                        staticClass: "contact-items",
                        attrs: {
                            src: e(678)
                        }
                    })]), this._v(" "), n("a", {
                        attrs: {
                            "data-event": "C_Facebook",
                            href: "https://medium.com/@iTokenWalletOfficial",
                            target: "_blank"
                        }
                    }, [n("img", {
                        staticClass: "contact-items",
                        attrs: {
                            src: e(679)
                        }
                    })])])
                }],
                W = e(680),
                G = e.n(W),
                V = e(681),
                J = e.n(V),
                K = e(682),
                X = e.n(K),
                nn = e(683),
                tn = e.n(nn),
                en = e(684),
                on = e.n(en),
                an = e(685),
                sn = e.n(an),
                rn = e(686),
                cn = e.n(rn),
                ln = e(687),
                pn = e.n(ln),
                dn = e(688),
                fn = e.n(dn),
                hn = e(689),
                mn = e.n(hn),
                gn = e(690),
                un = e.n(gn),
                xn = {
                    name: "Section3",
                    props: ["top"],
                    data: function() {
                        return {
                            scollCurr: !1,
                            selfTop: 0,
                            wh: 0,
                            isPlaying: !1,
                            playTimes: 0,
                            list: [{
                                icon: G.a
                            }, {
                                icon: J.a
                            }, {
                                icon: X.a
                            }, {
                                icon: tn.a
                            }, {
                                icon: on.a
                            }, {
                                icon: sn.a
                            }, {
                                icon: cn.a
                            }, {
                                icon: pn.a
                            }, {
                                icon: fn.a
                            }, {
                                icon: mn.a
                            }, {
                                icon: un.a
                            }]
                        }
                    },
                    mounted: function() {
                        var n = this;
                        this.onResize = function() {
                            n.transform()
                        }, window.addEventListener("resize", this.onResize), window.addEventListener("scroll", this.onScroll), this.transform()
                    },
                    beforeDestroy: function() {
                        window.removeEventListener("resize", this.onResize), window.removeEventListener("scroll", this.onScroll)
                    },
                    methods: {
                        onScroll: function() {
                            window.scrollY > 2185 && (this.scollCurr = !0);
                            var n = this.selfTop - this.top;
                            if ((n < 0 || n >= this.wh) && (this.isPlaying = !1), n > 0 && n < .9 * this.wh && !this.isPlaying && this.playTimes < 1 && (this.isPlaying = !0, this.playTimes = this.playTimes + 1, "undefined" != typeof HaikuComponentEmbed_tsinrong_walletmotion3)) HaikuComponentEmbed_tsinrong_walletmotion3(this.$refs.aniCon, {
                                loop: !1
                            })
                        },
                        transform: function() {
                            if (this.$refs.aniCon) {
                                var rect = this.$refs.aniCon.getBoundingClientRect(),
                                    n = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
                                (void 0 !== rect.top || void 0 !== rect.x) && (this.selfTop = rect.top + n), this.wh = window.innerHeight;
                                var t = 1;
                                window.innerWidth <= 960 && (t = window.innerWidth / 750), k()(this.$refs.aniCon, "transform", "scale(".concat(t, ")"))
                            }
                        }
                    }
                },
                wn = (e(920), Object(y.a)(xn, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", {
                        staticClass: "section3-con-pc"
                    }, [t("div", {
                        staticClass: "content"
                    }, [t("h1", [n._v(n._s(n.$t("sec4Title")))]), n._v(" "), t("div", {
                        staticClass: "p-list"
                    }, n._l(n.list, (function(n) {
                        return t("span", {
                            key: n.icon
                        }, [t("img", {
                            attrs: {
                                alt: "",
                                src: n.icon
                            }
                        })])
                    })), 0), n._v(" "), n._m(0)])])
                }), $, !1, null, "3b186e90", null).exports),
                bn = e(488),
                yn = e.n(bn),
                vn = e(489),
                An = e.n(vn),
                kn = e(490),
                Mn = e.n(kn),
                Cn = {
                    name: "Section1",
                    props: ["top"],
                    data: function() {
                        return {
                            selfTop: 0,
                            wh: 0,
                            isPlaying: !1,
                            playTimes: 0,
                            descList: [{
                                icon: yn.a,
                                text: this.$t("home.ani3.desc1")
                            }, {
                                icon: An.a,
                                text: this.$t("home.ani3.desc2")
                            }, {
                                icon: Mn.a,
                                text: this.$t("home.ani3.desc3")
                            }],
                            scollCurr: !1
                        }
                    },
                    computed: {
                        isZH: function() {
                            return "zh" === this.$i18n.locale
                        }
                    },
                    mounted: function() {
                        var n = this;
                        this.onResize = function() {
                            n.transform()
                        }, window.addEventListener("resize", this.onResize), window.addEventListener("scroll", this.onScroll), this.transform(), this.onScroll()
                    },
                    beforeDestroy: function() {
                        window.removeEventListener("resize", this.onResize), window.removeEventListener("scroll", this.onScroll)
                    },
                    methods: {
                        onScroll: function() {
                            console.log(window.scrollY), window.scrollY > 300 && (this.scollCurr = !0)
                        },
                        transform: function() {
                            if (this.$refs.aniCon) {
                                var rect = this.$refs.aniCon.getBoundingClientRect(),
                                    n = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
                                (void 0 !== rect.top || void 0 !== rect.x) && (this.selfTop = rect.top + n), this.wh = window.innerHeight;
                                var t = 1;
                                window.innerWidth <= 960 && (t = window.innerWidth / 750), k()(this.$refs.aniCon, "transform", "scale(".concat(t, ")"))
                            }
                        },
                        goTop: function() {
                            window.scrollTo(0, 0)
                        }
                    }
                },
                In = (e(923), e(925), Object(y.a)(Cn, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", {
                        staticClass: "section1-con-pc",
                        class: n.isZH ? "" : "section1-con-pc-en"
                    }, [t("div", {
                        staticClass: "content"
                    }, [t("h2", {
                        staticClass: "section1-title",
                        class: n.isZH ? "" : "section1-title-en",
                        domProps: {
                            innerHTML: n._s(n.$t("home.ani3.title"))
                        }
                    }), n._v(" "), t("div", {
                        staticClass: "desc-list",
                        class: [n.scollCurr ? "anmation-add" : "", n.isZH ? "" : "desc-list-en"]
                    }, [t("div", {
                        staticClass: "text-con"
                    }, n._l(n.descList, (function(e, o) {
                        return t("div", {
                            key: e.text
                        }, [t("img", {
                            attrs: {
                                src: e.icon,
                                alt: ""
                            }
                        }), n._v(" "), o !== n.descList.length - 1 ? t("div", {
                            staticClass: "next"
                        }) : n._e(), n._v(" "), t("p", {
                            domProps: {
                                innerHTML: n._s(e.text)
                            }
                        })])
                    })), 0)]), n._v(" "), t("router-link", {
                        staticClass: "button",
                        attrs: {
                            to: n.$i18n.path("install")
                        }
                    }, [n._v("\n            " + n._s(n.$t("home.ani3.download")) + "\n        ")])], 1)])
                }), [], !1, null, "f329e83e", null).exports),
                Sn = e(148),
                jn = e(114),
                zn = e(462),
                Tn = e(454),
                _n = {
                    name: "Home",
                    asyncData: function() {
                        return Object(r.a)(regeneratorRuntime.mark((function n() {
                            var t, e;
                            return regeneratorRuntime.wrap((function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        return n.next = 2, l.default.getConfig();
                                    case 2:
                                        return t = n.sent, n.next = 5, l.default.getConfig("announcement/announcement.json");
                                    case 5:
                                        return e = n.sent, n.abrupt("return", {
                                            androidDownload: t.android,
                                            appstore: t.appstore,
                                            googlePlayAndroidDownload: t.googlePlay,
                                            testflight: t.testflight,
                                            newsList: e
                                        });
                                    case 7:
                                    case "end":
                                        return n.stop()
                                }
                            }), n)
                        })))()
                    },
                    data: function() {
                        return {
                            top: 0,
                            tipShow: !1,
                            cookiesShow: !0,
                            deviceType: {
                                mobile: "mobile",
                                pc: "pc",
                                tablet: "tablet"
                            },
                            allWidth: {
                                tablet: 960,
                                pc: 1240,
                                mobile: 960
                            },
                            device: ""
                        }
                    },
                    head: function() {
                        return {
                            htmlAttrs: {
                                lang: this.$i18n.locale
                            },
                            title: this.$t("homeTitle"),
                            meta: [{
                                name: "description",
                                content: this.$t("homeDesc")
                            }, {
                                name: "keywords",
                                content: this.$t("homeKeywords")
                            }, {
                                name: "Language",
                                content: l.default.language(this.$i18n.locale)
                            }, {
                                property: "og:title",
                                content: this.$t("homeTitle")
                            }, {
                                property: "og:description",
                                content: this.$t("homeDesc")
                            }, {
                                property: "og:url",
                                content: "https://www.itoken.com"
                            }, {
                                property: "og:locale",
                                content: l.default.language(this.$i18n.locale)
                            }, {
                                property: "og:image",
                                content: "https://www.itoken.com/thumbnail.png"
                            }, {
                                property: "og:type",
                                content: "website"
                            }, {
                                property: "og:site_name",
                                content: this.$t("hbWallet")
                            }],
                            link: [].concat(Object(o.a)(l.default.hrefLang("", this.$route.path)), [{
                                href: "/index_bundle.css",
                                type: "text/css",
                                rel: "stylesheet"
                            }]),
                            script: [].concat(Object(o.a)(jn.a.script), [{
                                type: "text/javascript",
                                body: !0,
                                src: "/js/optimized/ani-all.js"
                            }])
                        }
                    },
                    components: {
                        TopHeader: v,
                        Section1: P,
                        Section2: Q,
                        Section3: wn,
                        Section5: In,
                        Footer: Sn.a,
                        WXTip: zn.a,
                        CookiesTip: Tn.a
                    },
                    created: function() {
                        l.default.initWeixinShare(this.$t("homeTitle"), this.$t("homeDesc"))
                    },
                    mounted: function() {
                        var n = this;
                        return Object(r.a)(regeneratorRuntime.mark((function t() {
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        document.body.scrollTop = document.documentElement.scrollTop = 0, window.addEventListener("scroll", (function() {
                                            var t = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
                                            n.top = t
                                        }));
                                    case 2:
                                    case "end":
                                        return t.stop()
                                }
                            }), t)
                        })))()
                    },
                    methods: {
                        tipClick: function() {
                            this.tipShow = !1
                        },
                        onDownloadClick: function(n) {
                            l.default.isWeixin() && (n.preventDefault(), n.stopPropagation(), this.tipShow = !0)
                        }
                    }
                },
                Dn = Object(y.a)(_n, (function() {
                    var n = this,
                        t = n._self._c;
                    return t("div", [t("div", {
                        class: [this.$i18n.locale]
                    }, [t("TopHeader", {
                        attrs: {
                            "news-list": n.newsList,
                            "android-download": n.androidDownload,
                            appstore: n.appstore,
                            "google-play-android-download": n.googlePlayAndroidDownload,
                            testflight: n.testflight
                        },
                        on: {
                            onDownloadClick: n.onDownloadClick
                        }
                    }), n._v(" "), t("Section1", {
                        attrs: {
                            top: n.top
                        }
                    }), n._v(" "), t("Section2", {
                        attrs: {
                            top: n.top
                        }
                    }), n._v(" "), t("Section5", {
                        attrs: {
                            top: n.top
                        }
                    }), n._v(" "), t("Section3"), n._v(" "), t("Footer", {
                        attrs: {
                            androidDownload: n.androidDownload,
                            appstore: n.appstore,
                            googlePlayAndroidDownload: n.googlePlayAndroidDownload,
                            testflight: n.testflight
                        }
                    }), n._v(" "), t("div", {
                        class: [this.$i18n.locale, "main-body"]
                    }, [t("WXTip", {
                        attrs: {
                            show: n.tipShow
                        },
                        on: {
                            tipClick: n.tipClick
                        }
                    })], 1)], 1)])
                }), [], !1, null, null, null);
            t.default = Dn.exports
        },
        453: function(n, t, e) {
            var content = e(456);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("e7c2d878", content, !0, {
                sourceMap: !1
            })
        },
        454: function(n, t, e) {
            "use strict";
            var o = {
                    name: "CookiesTip",
                    data: function() {
                        return {
                            cookiesShow: !1
                        }
                    },
                    methods: {
                        cookiesAgree: function() {
                            sa.track("Agree_Cookie", {}), this.cookiesShow = !1, this.$store.commit("SET_COOKIES")
                        },
                        cookiesColse: function() {
                            this.$store.commit("SET_COOKIES"), this.cookiesShow = !1
                        }
                    }
                },
                r = (e(455), e(3)),
                component = Object(r.a)(o, (function() {
                    var n = this,
                        t = n._self._c;
                    return n.cookiesShow ? t("div", {
                        staticClass: "bottomContainer"
                    }, [t("div", {
                        staticClass: "bottom bbbb1"
                    }, [t("div", {
                        staticClass: "container"
                    }, [t("div", {
                        staticClass: "contentContainer"
                    }, [t("div", {
                        staticClass: "title"
                    }, [n._v(n._s(n.$t("cookiesTitle")))]), n._v(" "), t("div", {
                        staticClass: "content"
                    }, [n._v("\n          " + n._s(n.$t("cookiesContent")) + "\n          "), t("a", {
                        staticClass: "protocol",
                        attrs: {
                            href: "/protocols/".concat(this.$i18n.locale, ".html"),
                            target: "_blank"
                        }
                    }, [n._v(n._s(n.$t("privateProtocol")))])])]), n._v(" "), t("div", {
                        staticClass: "button_container"
                    }, [t("span", {
                        staticClass: "close",
                        on: {
                            click: n.cookiesColse
                        }
                    }, [n._v(n._s(n.$t("close")))]), n._v(" "), t("span", {
                        staticClass: "agree",
                        on: {
                            click: n.cookiesAgree
                        }
                    }, [n._v(n._s(n.$t("agree")))])])])])]) : n._e()
                }), [], !1, null, "f26d4538", null);
            t.a = component.exports
        },
        455: function(n, t, e) {
            "use strict";
            e(453)
        },
        456: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = o((function(i) {
                    return i[1]
                })),
                S = r(c),
                j = r(c, {
                    hash: "?#iefix"
                }),
                z = r(l),
                T = r(d),
                _ = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                D = r(h),
                E = r(h, {
                    hash: "?#iefix"
                }),
                N = r(m),
                L = r(x),
                O = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                P = r(y),
                H = r(y, {
                    hash: "?#iefix"
                }),
                R = r(v),
                Y = r(A),
                Z = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                B = r(M),
                U = r(C);
            I.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + j + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + _ + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + D + ");\n  /* IE9 */\n  src: url(" + E + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + N + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + O + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + H + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + R + ') format("woff"), /* chrome、firefox */ url(' + Y + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + Z + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + B + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + U + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n.bottomContainer[data-v-f26d4538] {\n  position: fixed;\n  left: 0;\n  bottom: 0;\n  z-index: 1000;\n  width: 100%;\n  background-color: #ffffff;\n  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .07);\n          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .07);\n}\n.bottom[data-v-f26d4538] {\n  padding-top: 5.3333vw;\n  padding-bottom: 4vw;\n}\n.contentContainer[data-v-f26d4538] {\n  text-align: left;\n  margin-left: 4.8vw;\n}\n.title[data-v-f26d4538] {\n  font-size: 3.7333vw;\n  color: #0b121f;\n  overflow: hidden;\n  font-family: PingFangSC-Regular;\n}\n.content[data-v-f26d4538] {\n  font-size: 3.2vw;\n  color: rgba(11, 18, 31, .5);\n  margin-top: 2.6667vw;\n  font-family: PingFangSC-Regular;\n}\n.protocol[data-v-f26d4538] {\n  color: #1235fc;\n  font-size: 3.2vw;\n  text-decoration: none;\n  font-family: PingFangSC-Regular;\n}\n.button_container[data-v-f26d4538] {\n  margin-top: 2.6667vw;\n  text-align: right;\n  margin-right: 4.8vw;\n}\n.close[data-v-f26d4538] {\n  font-size: 3.2vw;\n  color: #0b121f;\n  padding-top: 2.4vw;\n  padding-bottom: 2.4vw;\n  margin-right: 3.3333vw;\n  font-family: PingFangSC-Regular;\n  padding-top: 1.8667vw;\n  padding-bottom: 1.8667vw;\n  padding-left: 6.6667vw;\n  padding-right: 6.6667vw;\n  cursor: pointer;\n}\n.agree[data-v-f26d4538] {\n  font-size: 3.2vw;\n  color: #1235fc;\n  border: 0.2667vw solid #1235fc;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  border-radius: 6.6667vw;\n  padding-top: 1.8667vw;\n  padding-bottom: 1.8667vw;\n  padding-left: 6.6667vw;\n  padding-right: 6.6667vw;\n  margin-left: 3.3333vw;\n  font-family: PingFangSC-Regular;\n  cursor: pointer;\n}\n@media (min-width: 960px) {\n.bottom[data-v-f26d4538] {\n    margin: 0 auto;\n    width: 90%;\n    padding-top: 22px;\n    padding-bottom: 22px;\n}\n.container[data-v-f26d4538] {\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: justify;\n        -ms-flex-pack: justify;\n            justify-content: space-between;\n}\n.title[data-v-f26d4538] {\n    font-size: 15px;\n    color: #0b121f;\n    overflow: hidden;\n}\n.content[data-v-f26d4538] {\n    font-size: 12px;\n    color: rgba(11, 18, 31, .5);\n    margin-top: 10px;\n}\n.protocol[data-v-f26d4538] {\n    color: #1235fc;\n    font-size: 12px;\n    text-decoration: none;\n}\n.button_container[data-v-f26d4538] {\n    margin-top: 0px;\n    margin-right: 0px;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: reverse;\n        -ms-flex-direction: row-reverse;\n            flex-direction: row-reverse;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n}\n.close[data-v-f26d4538] {\n    font-size: 14px;\n    line-height: 14px;\n    color: #0b121f;\n    padding-top: 12px;\n    padding-bottom: 12px;\n    margin-right: 0px;\n    margin-left: 0px;\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-pack: center;\n        -ms-flex-pack: center;\n            justify-content: center;\n    -webkit-box-align: center;\n        -ms-flex-align: center;\n            align-items: center;\n    padding-top: 10px;\n    padding-bottom: 10px;\n    padding-left: 20px;\n    padding-right: 20px;\n    text-align: center;\n    white-space: nowrap;\n}\n.agree[data-v-f26d4538] {\n    font-size: 14px;\n    line-height: 14px;\n    font-weight: 600;\n    color: #1235fc;\n    border: 2px solid #1235fc;\n    text-align: center;\n    border-radius: 50px;\n    padding-top: 10px;\n    padding-bottom: 10px;\n    padding-left: 20px;\n    padding-right: 20px;\n    margin-left: 20px;\n    white-space: nowrap;\n}\n}\n', ""]), I.locals = {}, n.exports = I
        },
        459: function(n, t, e) {
            var content = e(466);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("133d7064", content, !0, {
                sourceMap: !1
            })
        },
        460: function(n, t) {
            n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDMiIGhlaWdodD0iMTMiIHZpZXdCb3g9IjAgMCA0MyAxMyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTQwLjUyNDkgM0MzNS4zMTM1IDcuMzY5MjEgMjguNTk1MiAxMCAyMS4yNjI1IDEwQzEzLjkyOTcgMTAgNy4yMTE0NiA3LjM2OTIxIDIgMyIgc3Ryb2tlPSIjMUZCNzVDIiBzdHJva2Utd2lkdGg9IjYiLz4KPC9zdmc+Cg=="
        },
        462: function(n, t, e) {
            "use strict";
            var o = {
                    name: "WXTip",
                    props: ["show"],
                    methods: {
                        empty: function() {}
                    }
                },
                r = (e(465), e(3)),
                component = Object(r.a)(o, (function() {
                    var n = this,
                        t = n._self._c;
                    return n.show ? t("div", {
                        staticClass: "wx-tip-con",
                        on: {
                            touchmove: function(t) {
                                return t.stopPropagation(), t.preventDefault(), n.empty.apply(null, arguments)
                            },
                            click: function(t) {
                                return n.$emit("tipClick")
                            }
                        }
                    }, ["zh" === this.$i18n.locale ? t("img", {
                        staticClass: "tip",
                        attrs: {
                            src: e(463)
                        }
                    }) : t("img", {
                        staticClass: "tip",
                        attrs: {
                            src: e(464)
                        }
                    })]) : n._e()
                }), [], !1, null, "0b26e040", null);
            t.a = component.exports
        },
        463: function(n, t, e) {
            n.exports = e.p + "img/wx-tip-zh.584a424.png"
        },
        464: function(n, t, e) {
            n.exports = e.p + "img/wx-tip-en.1dc0ab0.png"
        },
        465: function(n, t, e) {
            "use strict";
            e(459)
        },
        466: function(n, t, e) {
            var o = e(14)((function(i) {
                return i[1]
            }));
            o.push([n.i, "\n.wx-tip-con[data-v-0b26e040]{\n  position: fixed;\n  z-index: 100;\n  left: 0;\n  top: 0;\n  width: 100%;\n  height: 100%;\n  -webkit-tap-highlight-color: transparent;\n}\n.tip[data-v-0b26e040] {\n  position: absolute;\n  right: 3.3333vw;\n  top: 2vw;\n  width: 53.3333vw;\n  height: 24.6667vw;\n}\n", ""]), o.locals = {}, n.exports = o
        },
        467: function(n, t) {
            n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAIjSURBVHgB7VXtTeNAEJ2xN0F3x51MB6EDSggd3FVw4R8SRoQKQirASAbxj9ABHcQlpAPcQSI+pWi9y0zwhsUk3o2Af3lSlIwz+8YzevMWYI01vgnok/QUx0MNEGml9jYvLkaLcsb7+60NIa40Yj4Nw+OtJJnUcQbgwF0c/6Wibfq5EwTB6bK8ZhgOZ3lad4SUOw5ad+FCiIy+Zm/PxE8HB91qzsPhYQcQW2U4ocK5i9dZmEemAM5MTKPsjbvdyMQ8YlSqZx05+3F5mbt4nYUZUogEtc7LMGpKOe96o9E4Mt1yzq80PfHh9BIX4z6O2/SWQxNPpdzm76YQt+ZZKb6BD593YcYDqRtfhcYHM81TQOyY+Gea7vpyCVgBJK6+KTxTML69N0q5ByvgQ8c8UijJFyHU+r9+U/ArCXVeIF4vOyOlHGxVBPeuMKuVhDOGr8dkKsS2bSqLVD2Br0dUffBh1M+0l7Q+HViCgEYNlVGTW+WqZtSE7HeaZrWF68BmYa+PDTKZ3Sp5HbwMxKBBl8A8QByQsjMThgA9WAHeHbMfk3rnhYPSQJQ1gQLg3580vfHh8+7Y9mNd+jF/aMR985xW7dT28U8Xfozjnu3HoZSJ+Y99HMwmUI7t458qzIKiDudkSuu+ffvwbpJ19q0jRz5dOwsLIVpY7iF3u+gS2Dw/TyyhRTSRtovXWZhGOaKOrpkYi2L5JaDUMeWMOM9XYGus8S14AcSo4kA6IyLcAAAAAElFTkSuQmCC"
        },
        468: function(n, t, e) {
            var o = e(663),
                r = e(664),
                c = {
                    float: "cssFloat"
                },
                l = e(667);

            function style(element, n, t) {
                var e = c[n];
                if (void 0 === e && (e = function(n) {
                        var t = r(n),
                            e = o(t);
                        return c[t] = c[n] = c[e] = e, e
                    }(n)), e) {
                    if (void 0 === t) return element.style[e];
                    element.style[e] = l(e, t)
                }
            }

            function d() {
                2 === arguments.length ? "string" == typeof arguments[1] ? arguments[0].style.cssText = arguments[1] : function(element, n) {
                    for (var t in n) n.hasOwnProperty(t) && style(element, t, n[t])
                }(arguments[0], arguments[1]) : style(arguments[0], arguments[1], arguments[2])
            }
            n.exports = d, n.exports.set = d, n.exports.get = function(element, n) {
                return Array.isArray(n) ? n.reduce((function(n, t) {
                    return n[t] = style(element, t || ""), n
                }), {}) : style(element, n || "")
            }
        },
        488: function(n, t, e) {
            n.exports = e.p + "img/step-1.80ef638.png"
        },
        489: function(n, t, e) {
            n.exports = e.p + "img/step-2.9453b7a.png"
        },
        490: function(n, t, e) {
            n.exports = e.p + "img/step-3.e2e2c53.png"
        },
        663: function(n, t) {
            var div = null,
                e = ["Webkit", "Moz", "O", "ms"];
            n.exports = function(n) {
                div || (div = document.createElement("div"));
                var style = div.style;
                if (n in style) return n;
                for (var t = n.charAt(0).toUpperCase() + n.slice(1), i = e.length; i >= 0; i--) {
                    var o = e[i] + t;
                    if (o in style) return o
                }
                return !1
            }
        },
        664: function(n, t, e) {
            var o = e(665);
            n.exports = function(n) {
                return o(n).replace(/\s(\w)/g, (function(n, t) {
                    return t.toUpperCase()
                }))
            }
        },
        665: function(n, t, e) {
            var o = e(666);
            n.exports = function(n) {
                return o(n).replace(/[\W_]+(.|$)/g, (function(n, t) {
                    return t ? " " + t : ""
                })).trim()
            }
        },
        666: function(n, t) {
            n.exports = function(n) {
                return e.test(n) ? n.toLowerCase() : o.test(n) ? (function(n) {
                    return n.replace(c, (function(n, t) {
                        return t ? " " + t : ""
                    }))
                }(n) || n).toLowerCase() : r.test(n) ? function(n) {
                    return n.replace(l, (function(n, t, e) {
                        return t + " " + e.toLowerCase().split("").join(" ")
                    }))
                }(n).toLowerCase() : n.toLowerCase()
            };
            var e = /\s/,
                o = /(_|-|\.|:)/,
                r = /([a-z][A-Z]|[A-Z][a-z])/;
            var c = /[\W_]+(.|$)/g;
            var l = /(.)([A-Z]+)/g
        },
        667: function(n, t) {
            var e = {
                animationIterationCount: !0,
                boxFlex: !0,
                boxFlexGroup: !0,
                boxOrdinalGroup: !0,
                columnCount: !0,
                flex: !0,
                flexGrow: !0,
                flexPositive: !0,
                flexShrink: !0,
                flexNegative: !0,
                flexOrder: !0,
                gridRow: !0,
                gridColumn: !0,
                fontWeight: !0,
                lineClamp: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                tabSize: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0,
                fillOpacity: !0,
                stopOpacity: !0,
                strokeDashoffset: !0,
                strokeOpacity: !0,
                strokeWidth: !0
            };
            n.exports = function(n, t) {
                return "number" != typeof t || e[n] ? t : t + "px"
            }
        },
        668: function(n, t) {
            n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJUSURBVHgB7d2xMgNBHMfxf4zRMQZVqjSMB1AopeUh6BV4ArwBhZ4nQafwAIYmCldhDBWFs3fcMJOI3Iaz+7vvZ+bIRGPmm7vd27skZgAAAAAAAAAAAAAAAAAAAAAAAABQXsN8na+vWpruuUeThsE1rON+7NjCwZFVYMR8vaY7RtzyUmt97BiV8A/ccP8ofFW2Y/gHRhQILI7A4ggsjsDiCCyOwOIILI7A4kYNwWk2m2mv55MkKX3tQH4Pbo1N51tdSQfOwh7Pb+RbXSPLBi7iFntwXSNLBu4VtK6RhQ/R3fOROkaWDNx5ubP2xZ77fd/1t7pFlt2Difwu6PPgpfFZt83ZME6fLq01vdj1fBG5fbGfvxhUBR54zraby/ZX6hC59kuV6odr1qJNOzKBP6hGDnoMPnETJEusUksTs3Z4qzMeBx74Kt/gj0O0OAKLI7C4oMfgtZnFyme12cROadwPe5L1eOVOXVZc5CmrTGJSgYM+RPe7YIDBBD8GE3k4UUyyiOwvmttmi8jH85vfjsmHd2d2/TzciyBfPRMS1X3RP0XOrh+3b7Sv75YV3Xkwd2qUE+VCB5EHF+1KVv+Jl/+nQ6mJeqmyV+Ts8ftzjMOZ6Neiv0YmbjeJdxcWkYvH+CTz9lHC9sblQnEEFkdgcQQWR2BxBBZHYHEEFkdgcQQWN0zgB4Of/JtXquEfOLUtt3UMZT3Yq+1aRbgyHiA+qxIDI7A4AosjsDgCiyOwuH+7J+u7UwH8LvZgcQQWR2BxBBZHYAAAAAAAAAAAAAAAAAAAAACxewPQrtsqb2bvawAAAABJRU5ErkJggg=="
        },
        669: function(n, t, e) {
            n.exports = e.p + "img/home-desc-2.663e84e.png"
        },
        670: function(n, t, e) {
            n.exports = e.p + "img/home-desc-3.092627a.png"
        },
        671: function(n, t, e) {
            n.exports = e.p + "img/home-desc-4.0428368.png"
        },
        672: function(n, t, e) {
            n.exports = e.p + "img/home-desc-5.5d96579.png"
        },
        673: function(n, t) {
            n.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFfSURBVHgB7d2xTcNQFIbRa8QAjECDKGjDPPSkYoOwAU3omYe0FIgmI2SCPCxESUHMI0r+nCMlslxZ/nRl6dmyqwAAAAAAAAAAAAAAAAAAgGMxVG+r+V219jRuXRS/N9R6/FvUbPlSHZ1Vb9u2KHF31+ryezC66h94GA+UqboPRv/AHBSBwwkcTuBwAocTOJzA4QQOJ3A4gcMJHE7gcOd1Atps+eP+YTWvdCY4nMDhBA4ncDiBwwkcTuBwAocTONxJrGRNlbACZoLDCRxO4HBHdQ0+5btCU5ngcAKHEzicwOEEDidwOIHDCRxO4HAChxM4XP8Xob3et2K62+euTUxwOIHDCRxO4HAChxM4nMDhBA4ncDiBwwkcTuBw/xF4U0zz9eWVvvoHbvUw/tbFrja1rccCAAAAJuv/2OwfXd1cH/Vjtx9v7wd1Tq1FhxM4nMDhBA4nMAAAAAAAAAAA7NUnRMMlerKU1eIAAAAASUVORK5CYII="
        },
        674: function(n, t, e) {
            n.exports = e.p + "img/section2-1.1b67c04.png"
        },
        675: function(n, t, e) {
            n.exports = e.p + "img/section2-2.ceb5d1c.png"
        },
        676: function(n, t, e) {
            n.exports = e.p + "img/section2-3.be3a4fe.png"
        },
        677: function(n, t, e) {
            n.exports = e.p + "img/section2-4.d7f0ba9.png"
        },
        678: function(n, t, e) {
            n.exports = e.p + "img/twitter-pc-s-2.64c60d1.svg"
        },
        679: function(n, t) {
            n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3QgeD0iMC41IiB5PSIwLjUiIHdpZHRoPSIzMSIgaGVpZ2h0PSIzMSIgcng9IjE1LjUiIHN0cm9rZT0iIzAwQ0I2QSIvPgo8cGF0aCBkPSJNMjMuMzMzMyAxMC4yNDg1TDIyLjE2MzkgMTEuMzY5MkMyMi4wNjE2IDExLjQ0NzIgMjIuMDEyOCAxMS41NzM5IDIyLjAzMjMgMTEuNjk1N1YxOS45NDUxQzIyLjAxMjggMjAuMDcxOCAyMi4wNjE2IDIwLjE5ODQgMjIuMTYzOSAyMC4yNzE1TDIzLjMwOSAyMS4zOTIyVjIxLjY0MDhIMTcuNTU5MlYyMS40MDJMMTguNzQzMyAyMC4yNTJDMTguODYwMiAyMC4xMzUxIDE4Ljg2MDIgMjAuMTAxIDE4Ljg2MDIgMTkuOTI1NlYxMy4yNTQ5TDE1LjU2NjMgMjEuNjE2NEgxNS4xMjI5TDExLjI4ODEgMTMuMjU0OVYxOC44NTg1QzExLjI1NCAxOS4wOTI0IDExLjMzNjkgMTkuMzMxMSAxMS41MDI1IDE5LjUwMTdMMTMuMDQyMyAyMS4zNjc5VjIxLjYxNjRIOC42NjY2NlYyMS4zNjc5TDEwLjIwNjQgMTkuNTAxN0MxMC4zNzIxIDE5LjMzMTEgMTAuNDQ1MiAxOS4wOTI0IDEwLjQwNjIgMTguODU4NVYxMi4zNzc5QzEwLjQyNTcgMTIuMTk3NiAxMC4zNTc1IDEyLjAyMjEgMTAuMjIxIDExLjkwMDNMOC44NTE4MiAxMC4yNDg1VjEwSDEzLjEwNTZMMTYuMzg5OCAxNy4yMTE1TDE5LjI3OTMgMTAuMDA0OUgyMy4zMzMzVjEwLjI0ODVaIiBmaWxsPSIjMDBDQjZBIi8+Cjwvc3ZnPgo="
        },
        680: function(n, t, e) {
            n.exports = e.p + "img/p-1.f4d1f66.svg"
        },
        681: function(n, t, e) {
            n.exports = e.p + "img/p-2.21663c1.svg"
        },
        682: function(n, t, e) {
            n.exports = e.p + "img/p-3.37563a5.svg"
        },
        683: function(n, t, e) {
            n.exports = e.p + "img/p-4.c5e78c8.svg"
        },
        684: function(n, t, e) {
            n.exports = e.p + "img/p-5.e69c607.svg"
        },
        685: function(n, t) {
            n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iNTAiIHZpZXdCb3g9IjAgMCA1MCA1MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yNSA1MEMzOC44MDcxIDUwIDUwIDM4LjgwNzEgNTAgMjVDNTAgMTEuMTkyOSAzOC44MDcxIDAgMjUgMEMxMS4xOTI5IDAgMCAxMS4xOTI5IDAgMjVDMCAzOC44MDcxIDExLjE5MjkgNTAgMjUgNTBaIiBmaWxsPSJ3aGl0ZSIvPgo8ZyBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6bXVsdGlwbHkiPgo8Y2lyY2xlIGN4PSIyNS4wMDQ2IiBjeT0iMTYuOTU2NiIgcj0iNi40NTY2MSIgZmlsbD0iIzg4QkRGMyIvPgo8L2c+CjxnIHN0eWxlPSJtaXgtYmxlbmQtbW9kZTptdWx0aXBseSI+CjxjaXJjbGUgY3g9IjMyLjc1MjQiIGN5PSIyNC43MDQ3IiByPSI2LjQ1NjYxIiBmaWxsPSIjNTc5NUYxIi8+CjwvZz4KPGcgc3R5bGU9Im1peC1ibGVuZC1tb2RlOm11bHRpcGx5Ij4KPGNpcmNsZSBjeD0iMjUuMDA0NiIgY3k9IjMyLjQ1MjUiIHI9IjYuNDU2NjEiIGZpbGw9IiMzMDc1RUUiLz4KPC9nPgo8ZyBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6bXVsdGlwbHkiPgo8Y2lyY2xlIGN4PSIxNy4yNTY3IiBjeT0iMjQuNzA0NyIgcj0iNi40NTY2MSIgZmlsbD0iIzIwNUZFQyIvPgo8L2c+Cjwvc3ZnPgo="
        },
        686: function(n, t, e) {
            n.exports = e.p + "img/p-7.b37a4b5.svg"
        },
        687: function(n, t, e) {
            n.exports = e.p + "img/p-8.37634b6.svg"
        },
        688: function(n, t, e) {
            n.exports = e.p + "img/p-9.f7a6055.svg"
        },
        689: function(n, t, e) {
            n.exports = e.p + "img/p-10.2d551e6.svg"
        },
        690: function(n, t, e) {
            n.exports = e.p + "img/p-11.83cca18.svg"
        },
        777: function(n, t, e) {
            var content = e(909);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("53014378", content, !0, {
                sourceMap: !1
            })
        },
        778: function(n, t, e) {
            var content = e(911);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("51478fda", content, !0, {
                sourceMap: !1
            })
        },
        779: function(n, t, e) {
            var content = e(913);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("21ad9712", content, !0, {
                sourceMap: !1
            })
        },
        780: function(n, t, e) {
            var content = e(915);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("3e4f31f8", content, !0, {
                sourceMap: !1
            })
        },
        781: function(n, t, e) {
            var content = e(917);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("09be8542", content, !0, {
                sourceMap: !1
            })
        },
        782: function(n, t, e) {
            var content = e(919);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("594c3c36", content, !0, {
                sourceMap: !1
            })
        },
        783: function(n, t, e) {
            var content = e(921);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("5c4ba896", content, !0, {
                sourceMap: !1
            })
        },
        784: function(n, t, e) {
            var content = e(924);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("a2f2ffac", content, !0, {
                sourceMap: !1
            })
        },
        785: function(n, t, e) {
            var content = e(926);
            content.__esModule && (content = content.default), "string" == typeof content && (content = [
                [n.i, content, ""]
            ]), content.locals && (n.exports = content.locals);
            (0, e(15).default)("2b844b18", content, !0, {
                sourceMap: !1
            })
        },
        907: function(n, t, e) {
            n.exports = e.p + "img/home-banner-cn.0f9cae2.png"
        },
        908: function(n, t, e) {
            "use strict";
            e(777)
        },
        909: function(n, t, e) {
            var o = e(14)((function(i) {
                return i[1]
            }));
            o.push([n.i, "\n.top-header-pc .top-header-content .left .title span {\n    /* margin-right: 32pc; */\n    font-weight: 800;\n    color: #1fb75c;\n    margin-right: 0;\n}\n.des-content-step1 {\n    display: -webkit-box;\n    display: -ms-flexbox;\n    display: flex;\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n        -ms-flex-direction: row;\n            flex-direction: row;\n    margin-top: 15px;\n.des-content-step1-img {\n        width: 10px;\n        height: 10px;\n        background-color: transparent;\n        margin-top: 5px;\n}\n.des-content-step1-text {\n        font-family: 'PingFang SC';\n        font-style: normal;\n        font-weight: 400;\n        font-size: 14px;\n        line-height: 20px;\n        color: rgba(37, 43, 39, .6);\n        text-align: left;\n        margin-left: 6px;\n        width: 500px;\n}\n}\n", ""]), o.locals = {}, n.exports = o
        },
        910: function(n, t, e) {
            "use strict";
            e(778)
        },
        911: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = e(460),
                S = o((function(i) {
                    return i[1]
                })),
                j = r(c),
                z = r(c, {
                    hash: "?#iefix"
                }),
                T = r(l),
                _ = r(d),
                D = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                E = r(h),
                N = r(h, {
                    hash: "?#iefix"
                }),
                L = r(m),
                O = r(x),
                P = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                H = r(y),
                R = r(y, {
                    hash: "?#iefix"
                }),
                Y = r(v),
                Z = r(A),
                B = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                U = r(M),
                F = r(C),
                Q = r(I);
            S.push([n.i, '.vjs-custom-skin {\n}\n.vjs-custom-skin > .video-js {\n  width: 100%;\n  height: 100%;\n  font-family: "PingFang SC","Helvetica Neue","Hiragino Sans GB","Segoe UI","Microsoft YaHei","微软雅黑",sans-serif;\n}\n.vjs-custom-skin > .video-js .vjs-tech{\n  /*object-fit: fill!important;*/\n}\n.vjs-custom-skin > .video-js .vjs-controls-disabled .vjs-big-play-button {\n  display: none!important\n}\n.vjs-paused.vjs-has-started.vjs-custom-skin > .video-js .vjs-big-play-button,.video-js.vjs-ended .vjs-big-play-button,.video-js.vjs-paused .vjs-big-play-button {\n  display: block\n}\n.vjs-custom-skin > .video-js .vjs-load-progress div,.vjs-seeking .vjs-big-play-button,.vjs-waiting .vjs-big-play-button {\n  display: none!important\n}\n.vjs-custom-skin > .video-js.vjs-paused {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n}\n.vjs-custom-skin > .video-js .vjs-big-play-button {\n  top: 50%;\n  left: 50%;\n  margin-left: -42px; /*stay px*/\n  margin-top: -42px; /*stay px*/\n  width: 84px; /*stay px*/\n  height: 84px; /*stay px*/\n  background-color: #E6E6E6;\n  border-radius: 50%;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  line-height: 84px; /*stay px*/\n  border: 0;\n  outline-color: transparent;\n  outline-style: none;\n  -webkit-outline-color: transparent;\n  -webkit-outline-style: none;\n}\n@media (max-width: 960px) {\n.vjs-custom-skin > .video-js .vjs-big-play-button {\n    margin-left: -21px; /*stay px*/\n    margin-top: -21px; /*stay px*/\n    width: 42px; /*stay px*/\n    height: 42px; /*stay px*/\n    line-height: 42px; /*stay px*/\n}\n}\n.vjs-custom-skin > .video-js .vjs-big-play-button  .vjs-icon-placeholder{\n  color: #000;\n}\n@font-face {\n  font-family: \'PingFangSC-Light\';\n  src: url(' + j + ");\n  /* IE9 */\n  src: url(" + z + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + T + ') format("woff"), /* chrome、firefox */ url(' + _ + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + D + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + E + ");\n  /* IE9 */\n  src: url(" + N + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + L + ') format("woff"), /* chrome、firefox */ url(' + O + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + P + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + H + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + Y + ') format("woff"), /* chrome、firefox */ url(' + Z + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + B + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + F + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n.top-header-pc {\n  height: 620px;\n  background: linear-gradient(87.42deg, #dcf5e2 18.1%, rgba(224, 255, 232, .62) 85.39%);\n}\n.top-header-pc .vue-typer {\n  line-height: 1;\n}\n.top-header-pc .vue-typer .custom.caret {\n  position: relative;\n  color: #0155ff;\n  height: 1em;\n  width: 1px !important;\n  margin-left: 0.2em;\n  font-size: 56px;\n  font-weight: 600;\n  background-color: #3f51b5;\n}\n.top-header-pc .tips-bar .float {\n  margin: 16px 15px 0;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  height: 80px;\n  background: #5810f1;\n  border-radius: 8px;\n  font-weight: 500;\n  font-size: 16px;\n  line-height: 20px;\n  position: fixed;\n  left: 0;\n  right: 0;\n  top: 94px;\n  z-index: 100;\n}\n.top-header-pc .tips-bar .float .tips-bar-icon {\n  width: 54px;\n  height: 54px;\n}\n.top-header-pc .tips-bar .float .txt1 {\n  color: #ffffff;\n  margin: 0 8px 0 12px;\n}\n.top-header-pc .tips-bar .float .txt2 {\n  color: #ff7f37;\n}\n.top-header-pc .custom-typer {\n  max-width: 570px;\n  overflow: hidden;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  line-height: 72px;\n  margin-top: 10px;\n  height: 96px;\n}\n.top-header-pc .top-header {\n  min-width: 1440px;\n  overflow: visible;\n}\n.top-header-pc .top-header .count-down-con {\n  color: #000;\n}\n.top-header-pc .top-header .count-down-con > .count-down-title {\n  margin-top: 47px;\n  font-size: 18px;\n  line-height: 25px;\n}\n.top-header-pc .top-header .count-down-con > .count-down-items {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  margin-top: 6px;\n}\n.top-header-pc .top-header .count-down-con > .count-down-items > .count-down-item {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: end;\n      -ms-flex-align: end;\n          align-items: flex-end;\n  margin-right: 24px;\n}\n.top-header-pc .top-header .count-down-con > .count-down-items > .count-down-item .count-down-number {\n  font-size: 36px;\n  line-height: 50px;\n}\n.top-header-pc .top-header .count-down-con > .count-down-items > .count-down-item .count-down-unit {\n  position: relative;\n  top: -7px;\n  font-size: 18px;\n  line-height: 25px;\n}\n.top-header-pc .is-en {\n  font-size: 40px;\n  line-height: 48px;\n  margin-top: 14px;\n}\n.top-header-pc .download_btn {\n  width: 180px;\n  height: 48px;\n  border-radius: 2px;\n  font-size: 14px;\n  background: #252b27;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  color: #fff;\n  text-decoration: none;\n  margin-bottom: 15px;\n  cursor: pointer;\n}\n.top-header-pc .download_btn img {\n  margin-right: 10px;\n}\n.top-header-pc .download_btn:last-child {\n  margin-bottom: 0;\n}\n.top-header-pc .download_btn:last-child img {\n  width: 14px;\n  height: 16px;\n  margin-right: 10px;\n}\n.top-header-pc .download_btn:last-child:hover {\n  background: #1fb75c;\n}\n.top-header-pc .ios_btn {\n  left: 0;\n}\n.top-header-pc .ios_btn img {\n  width: 17px;\n  height: 20px;\n}\n.top-header-pc .ios_btn:hover {\n  background: #1fb75c;\n}\n.top-header-pc .android_btn {\n  left: 0px;\n  top: 74px;\n  margin-left: 18px;\n}\n.top-header-pc .android_btn img {\n  width: 18px;\n  height: 20px;\n}\n.top-header-pc .phone {\n  font-style: normal;\n  font-weight: 700;\n  font-size: 14px;\n  line-height: 16px;\n  color: #fffefd;\n}\n.top-header-pc .top-header {\n  height: 675px;\n  background: -webkit-gradient(linear, left top, left bottom, color-stop(35.34%, rgba(249, 251, 253, 0)), to(#dbe5ff));\n  background: linear-gradient(180deg, rgba(249, 251, 253, 0) 35.34%, #dbe5ff 100%);\n  padding-top: 80px;\n}\n.top-header-pc .top-header-content {\n  width: 1440px;\n  margin: 0 auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  position: relative;\n}\n.top-header-pc .top-header-content .right {\n  width: 100%;\n  height: 571px;\n  overflow: hidden;\n}\n.top-header-pc .top-header-content .right img {\n  width: 100%;\n  pointer-events: none;\n}\n.top-header-pc .top-header-content .right .phone1 {\n  position: absolute;\n  right: 0;\n  bottom: -49px;\n  z-index: 1;\n}\n.top-header-pc .top-header-content .right .phone1-en {\n  bottom: -68px;\n}\n.top-header-pc .top-header-content .left {\n  margin-left: 120px;\n  z-index: 2;\n}\n.top-header-pc .top-header-content .left .title-en {\n  position: relative;\n  margin-top: 125px !important;\n  width: 590px !important;\n}\n.top-header-pc .top-header-content .left .title {\n  margin: 163px auto 0 0;\n  font-size: 48px;\n  font-weight: 600;\n  line-height: 66px;\n  width: 460px;\n  text-align: left;\n}\n.top-header-pc .top-header-content .left .title .smilePositon {\n  position: relative;\n  display: inline-block;\n}\n.top-header-pc .top-header-content .left .title .smilePositon::after {\n  content: url(' + Q + ");\n  position: absolute;\n  top: 0;\n  margin: auto;\n  bottom: 14px;\n  height: 1px;\n  left: 150px;\n}\n.top-header-pc .top-header-content .left .title .smileCPositon {\n  position: relative;\n}\n.top-header-pc .top-header-content .left .title .smileCPositon::after {\n  content: url(" + Q + ");\n  position: absolute;\n  top: 0;\n  margin: auto;\n  bottom: 24px;\n  height: 1px;\n  right: 18px;\n}\n.top-header-pc .top-header-content .left .title .smileTPositon {\n  position: relative;\n}\n.top-header-pc .top-header-content .left .title .smileTPositon::after {\n  content: url(" + Q + ");\n  position: absolute;\n  top: 0;\n  margin: auto;\n  bottom: 24px;\n  height: 1px;\n  right: 33px;\n}\n.top-header-pc .top-header-content .left .title .smile {\n  position: relative;\n  right: -17px;\n  bottom: 43px;\n}\n.top-header-pc .top-header-content .left .title .smile-tw {\n  position: relative;\n  right: 15px;\n  bottom: 46px;\n}\n.top-header-pc .top-header-content .left .title .wallet {\n  color: #252b27;\n  font-size: 48px;\n  height: 66px;\n}\n.top-header-pc .top-header-content .left .title .wallet .webTitle {\n  font-weight: 800;\n  color: #1fb75c;\n  margin-right: 0;\n}\n.top-header-pc .top-header-content .left .title .is-title-en {\n  font-size: 56px;\n  font-weight: bold;\n}\n.top-header-pc .top-header-content .left .title .vue-typer span {\n  font-size: 56px;\n  line-height: 78px;\n}\n.top-header-pc .top-header-content .left .title .is-en span {\n  font-size: 37px;\n}\n.top-header-pc .top-header-content .left .title .wallet-desc {\n  font-size: 16px;\n  line-height: 30px;\n  font-weight: 400;\n  color: rgba(37, 43, 39, .5);\n  margin-top: 12px;\n}\n.top-header-pc .top-header-content .left .title .is-desc-en {\n  font-size: 20px;\n}\n.top-header-pc .top-header-content .left .download-info {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  -webkit-box-align: start;\n      -ms-flex-align: start;\n          align-items: flex-start;\n  margin-top: 40px;\n}\n.top-header-pc .top-header-content .left .download-info .btn_con {\n  -webkit-box-pack: start;\n      -ms-flex-pack: start;\n          justify-content: flex-start;\n  padding: 8px;\n  width: 196px;\n  position: relative;\n}\n.top-header-pc .top-header-content .left .download-info .qr_con {\n  margin-left: 19px;\n}\n.top-header-pc .top-header-content .left .download-info .qr_con .temp_pos {\n  width: 46px;\n  height: 46px;\n  border: 2px solid #1a1a1a;\n  border-radius: 2px;\n  padding: 6.5px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  position: relative;\n}\n.top-header-pc .top-header-content .left .download-info .qr_con .temp_pos:hover .real_qr {\n  width: 112px;\n  height: 112px;\n  border-radius: 2px;\n  background: #fff;\n  padding: 8px;\n  left: -3px;\n  top: -3px;\n  display: block;\n  position: absolute;\n}\n.top-header-pc .top-header-content .left .download-info .qr_con > .scan_text {\n  text-align: center;\n  font-size: 12px;\n  line-height: 12px;\n  white-space: nowrap;\n  color: #99a5b8;\n  margin-top: 8px;\n}\n.top-header-pc .top-header-content .left .download-info .qr_con .real_qr {\n  display: none;\n}\n.top-header-pc .top-header-content .left .relative {\n  position: relative;\n}\n.top-header-pc .android_download_list {\n  display: none;\n  position: absolute;\n  left: 0;\n  top: 0;\n  z-index: 2;\n  -webkit-transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in;\n  transition: opacity 0.3s ease-in, transform 0.3s ease-in, -webkit-transform 0.3s ease-in;\n  -webkit-transform-origin: center;\n          transform-origin: center;\n  opacity: 0;\n}\n.top-header-pc .android_download_list.visible {\n  opacity: 1;\n}\n.top-header-pc .android_download_list .close-btn {\n  display: none;\n}\n.top-header-pc .android_download_list .android_download_title {\n  display: none;\n}\n.top-header-pc .android_download_list .download_btn {\n  width: 180px;\n}\n.top-header-pc .android_download_list .download_btn:hover {\n  background: #1fb75c;\n}\n.top-header-pc .android_download_list .android_download_con {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  border-radius: 2px;\n}\n.top-header-pc .android_download_list .site_download img {\n  margin-right: 8px;\n  width: 17px;\n  height: 20px;\n}\n.top-header-pc .android_download_list .google_play_download {\n  margin-left: 18px;\n}\n.top-header-pc .android_download_list .google_play_download img {\n  margin-right: 8px;\n  width: 14px;\n  height: 16px;\n}\n.top-header-pc-new {\n  height: 640px;\n}\n.warm-prompt-pc {\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, .5);\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: 999;\n}\n.warm-prompt-pc .content {\n  width: 400px;\n  height: auto;\n  position: fixed;\n  left: 50%;\n  top: 50%;\n  background: #fff;\n  border-radius: 16px;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  padding-bottom: 40px;\n}\n.warm-prompt-pc .content .title {\n  /* 文字/黑 */\n  color: #212d43;\n  font-size: 18px;\n  line-height: 18px;\n  text-align: center;\n  display: block;\n  line-height: 80px;\n}\n.warm-prompt-pc .content .desc {\n  color: #212d43;\n  font-size: 14px;\n  line-height: 20px;\n  margin-bottom: 40px;\n  width: 300px;\n  margin: 0 auto;\n  text-align: left;\n}\n.warm-prompt-pc .content .close {\n  position: absolute;\n  right: 32px;\n  top: 24px;\n  cursor: pointer;\n}\n.warm-prompt-pc .content .close img {\n  width: 16px;\n  height: 16px;\n}\n.warm-prompt-pc .content .button {\n  text-decoration: none;\n  display: block;\n  cursor: pointer;\n  background: #1fb75c;\n  border-radius: 8px;\n  width: 300px;\n  height: 44px;\n  margin: 0 auto;\n  color: #fff;\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 44px;\n  margin-top: 24px;\n}\n.warm-prompt-pc .content .tips {\n  display: block;\n  color: #1fb75c;\n  font-size: 14px;\n  line-height: 14px;\n  margin-top: 16px;\n  text-decoration: none;\n}\n.notify-info-pc {\n  height: 56px;\n  background: rgba(31, 183, 92, .04);\n  -webkit-backdrop-filter: blur(100px);\n          backdrop-filter: blur(100px);\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  cursor: pointer;\n  width: 100%;\n  position: absolute;\n  bottom: 0;\n  pointer-events: auto;\n}\n.notify-info-pc .content {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  font-size: 14px;\n  font-weight: normal;\n  text-decoration: none;\n  margin-left: 120px;\n}\n.notify-info-pc .content .text-icon {\n  /* 主题色/蓝 */\n  border: 1px solid rgba(17, 111, 252, .2);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  border-radius: 2.4vw;\n  height: 18px;\n  line-height: 18px;\n  padding: 0 8px;\n  color: #116ffc;\n  margin-right: 6px;\n  font-size: 12px;\n}\n.notify-info-pc .content .nofify-text {\n  margin-left: 13px;\n  height: 17px;\n  font-family: 'Lato';\n  font-style: normal;\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 17px;\n  color: #252b27;\n}\n", ""]), S.locals = {}, n.exports = S
        },
        912: function(n, t, e) {
            "use strict";
            e(779)
        },
        913: function(n, t, e) {
            var o = e(14)((function(i) {
                return i[1]
            }));
            o.push([n.i, "\n.section1-con-pc .section1-title b {\n    color: #1fb75c !important;\n}\n.section1-con-pc .text-con p span {\n    font-weight: 700;\n}\n", ""]), o.locals = {}, n.exports = o
        },
        914: function(n, t, e) {
            "use strict";
            e(780)
        },
        915: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = o((function(i) {
                    return i[1]
                })),
                S = r(c),
                j = r(c, {
                    hash: "?#iefix"
                }),
                z = r(l),
                T = r(d),
                _ = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                D = r(h),
                E = r(h, {
                    hash: "?#iefix"
                }),
                N = r(m),
                L = r(x),
                O = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                P = r(y),
                H = r(y, {
                    hash: "?#iefix"
                }),
                R = r(v),
                Y = r(A),
                Z = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                B = r(M),
                U = r(C);
            I.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + j + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + _ + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + D + ");\n  /* IE9 */\n  src: url(" + E + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + N + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + O + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + H + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + R + ') format("woff"), /* chrome、firefox */ url(' + Y + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + Z + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + B + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + U + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n@-webkit-keyframes form-bottom-top-8cfba5d2 {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n@keyframes form-bottom-top-8cfba5d2 {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n.anmation-add[data-v-8cfba5d2] {\n  opacity: 1;\n  -webkit-animation: form-bottom-top-8cfba5d2 300ms 0s ease forwards;\n          animation: form-bottom-top-8cfba5d2 300ms 0s ease forwards;\n}\n.section1-con-pc[data-v-8cfba5d2] {\n  position: relative;\n  height: 582px;\n  width: 100%;\n  overflow: hidden;\n  background: #fff;\n  border-radius: 24px;\n}\n.section1-con-pc .content[data-v-8cfba5d2] {\n  width: 800px;\n  margin: 0 auto;\n  height: 382px;\n}\n.section1-con-pc .section1-title[data-v-8cfba5d2] {\n  font-size: 40px;\n  line-height: 56px;\n  font-weight: 600;\n  margin-top: 100px;\n  text-align: center;\n  color: #1a1a1a;\n}\n.section1-con-pc .desc-list[data-v-8cfba5d2] {\n  opacity: 0;\n  margin-top: 80px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.section1-con-pc .text-con[data-v-8cfba5d2] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.section1-con-pc .text-con img[data-v-8cfba5d2] {\n  width: 60px;\n  height: 60px;\n}\n.section1-con-pc .text-con p[data-v-8cfba5d2] {\n  font-style: normal;\n  width: 200px;\n  font-weight: 400;\n  font-size: 14px;\n  line-height: 17px;\n  color: #252b27;\n}\n.section1-con-pc .text-padding[data-v-8cfba5d2] {\n  margin-top: 60px;\n}\n.section1-con-pc-en[data-v-8cfba5d2] {\n  height: 592px;\n}\n.section1-con-pc-en .content[data-v-8cfba5d2] {\n  height: 419px;\n}\n.section1-con-pc-en .desc-list-en[data-v-8cfba5d2] {\n  margin-top: 60px;\n}\n.section1-con-pc-en .section1-title[data-v-8cfba5d2] {\n  margin-top: 120px;\n  line-height: 48px;\n}\n', ""]), I.locals = {}, n.exports = I
        },
        916: function(n, t, e) {
            "use strict";
            e(781)
        },
        917: function(n, t, e) {
            var o = e(14)((function(i) {
                return i[1]
            }));
            o.push([n.i, "\n.section2-con-pc .section2-title span {\n    color: #1fb75c !important;\n}\n", ""]), o.locals = {}, n.exports = o
        },
        918: function(n, t, e) {
            "use strict";
            e(782)
        },
        919: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = o((function(i) {
                    return i[1]
                })),
                S = r(c),
                j = r(c, {
                    hash: "?#iefix"
                }),
                z = r(l),
                T = r(d),
                _ = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                D = r(h),
                E = r(h, {
                    hash: "?#iefix"
                }),
                N = r(m),
                L = r(x),
                O = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                P = r(y),
                H = r(y, {
                    hash: "?#iefix"
                }),
                R = r(v),
                Y = r(A),
                Z = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                B = r(M),
                U = r(C);
            I.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + j + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + _ + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + D + ");\n  /* IE9 */\n  src: url(" + E + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + N + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + O + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + H + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + R + ') format("woff"), /* chrome、firefox */ url(' + Y + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + Z + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + B + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + U + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n@-webkit-keyframes form-bottom-top-5d2ef18f {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n@keyframes form-bottom-top-5d2ef18f {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n.anmation-add[data-v-5d2ef18f] {\n  opacity: 1;\n  -webkit-animation: form-bottom-top-5d2ef18f 300ms 0s ease forwards;\n          animation: form-bottom-top-5d2ef18f 300ms 0s ease forwards;\n}\n.section2-con-pc[data-v-5d2ef18f] {\n  background: #f5fdf9;\n  padding-bottom: 87px;\n}\n.section2-con-pc .content[data-v-5d2ef18f] {\n  width: 1120px;\n  margin: 0 auto;\n}\n.section2-con-pc .content .desc-list[data-v-5d2ef18f] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n}\n.section2-con-pc .content .desc-list img[data-v-5d2ef18f] {\n  opacity: 0;\n  width: 380px;\n  height: 380px;\n}\n.section2-con-pc .content .desc-list .text-con[data-v-5d2ef18f] {\n  width: 560px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n}\n.section2-con-pc .content .desc-list .text-con .section2-title[data-v-5d2ef18f],\n.section2-con-pc .content .desc-list .text-con .sub-title[data-v-5d2ef18f] {\n  font-weight: 600;\n  font-size: 40px;\n  line-height: 56px;\n  text-align: left;\n}\n.section2-con-pc .content .desc-list .text-con .section2-title[data-v-5d2ef18f] {\n  color: #252b27;\n  padding-bottom: 16px;\n}\n.section2-con-pc .content .desc-list .text-con .section2-title-en[data-v-5d2ef18f] {\n  line-height: 48px;\n}\n.section2-con-pc .content .desc-list .text-con .sub-title[data-v-5d2ef18f] {\n  color: #212d43;\n  margin-bottom: 40px;\n}\n.section2-con-pc .content .desc-list .text-con .desc[data-v-5d2ef18f] {\n  text-align: left;\n  color: #6b788e;\n  font-size: 16px;\n  font-weight: 400;\n  line-height: 22px;\n  margin-bottom: 16px;\n}\n.section2-con-pc .content .desc-list .text-con .desc span[data-v-5d2ef18f] {\n  display: block;\n}\n.section2-con-pc .content .desc-list .text-con .desc[data-v-5d2ef18f]:last-child {\n  margin-bottom: 0;\n}\n.section2-con-pc .content .desc-list[data-v-5d2ef18f]:nth-child(2n + 1) {\n  margin-bottom: 0;\n}\n.section2-con-pc .content .desc-list:nth-child(2n + 1) img[data-v-5d2ef18f] {\n  -webkit-box-ordinal-group: 3;\n      -ms-flex-order: 2;\n          order: 2;\n  width: 380px;\n  height: 380px;\n}\n', ""]), I.locals = {}, n.exports = I
        },
        920: function(n, t, e) {
            "use strict";
            e(783)
        },
        921: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = e(922),
                S = o((function(i) {
                    return i[1]
                })),
                j = r(c),
                z = r(c, {
                    hash: "?#iefix"
                }),
                T = r(l),
                _ = r(d),
                D = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                E = r(h),
                N = r(h, {
                    hash: "?#iefix"
                }),
                L = r(m),
                O = r(x),
                P = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                H = r(y),
                R = r(y, {
                    hash: "?#iefix"
                }),
                Y = r(v),
                Z = r(A),
                B = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                U = r(M),
                F = r(C),
                Q = r(I);
            S.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + j + ");\n  /* IE9 */\n  src: url(" + z + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + T + ') format("woff"), /* chrome、firefox */ url(' + _ + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + D + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + E + ");\n  /* IE9 */\n  src: url(" + N + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + L + ') format("woff"), /* chrome、firefox */ url(' + O + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + P + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + H + ");\n  /* IE9 */\n  src: url(" + R + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + Y + ') format("woff"), /* chrome、firefox */ url(' + Z + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + B + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + U + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + F + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n@-webkit-keyframes form-bottom-top-3b186e90 {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n@keyframes form-bottom-top-3b186e90 {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n.anmation-add[data-v-3b186e90] {\n  opacity: 1;\n  -webkit-animation: form-bottom-top-3b186e90 300ms 0s ease forwards;\n          animation: form-bottom-top-3b186e90 300ms 0s ease forwards;\n}\n.section3-con-pc[data-v-3b186e90] {\n  height: 532px;\n  background: #f5fdf9;\n  background-image: url(' + Q + ");\n  background-size: cover;\n}\n.section3-con-pc .content[data-v-3b186e90] {\n  width: 1440px;\n  margin: 0 auto;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.section3-con-pc .content h1[data-v-3b186e90] {\n  padding-top: 80px;\n  color: rgba(34, 51, 73, .95);\n  font-weight: 600;\n  font-size: 40px;\n  line-height: 56px;\n}\n.section3-con-pc .content .p-list[data-v-3b186e90] {\n  width: 740px;\n  margin-top: 36px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -ms-flex-wrap: wrap;\n      flex-wrap: wrap;\n}\n.section3-con-pc .content .p-list span[data-v-3b186e90] {\n  margin-right: 65px;\n}\n.section3-con-pc .content .p-list span img[data-v-3b186e90] {\n  width: 50px;\n  height: 50px;\n  -webkit-box-shadow: 0 4px 16px rgba(0, 0, 0, .08);\n          box-shadow: 0 4px 16px rgba(0, 0, 0, .08);\n  border-radius: 50%;\n}\n.section3-con-pc .content .p-list span[data-v-3b186e90]:nth-child(7) {\n  margin-right: 0;\n}\n.section3-con-pc .content .p-list span[data-v-3b186e90]:nth-child(8),\n.section3-con-pc .content .p-list span[data-v-3b186e90]:nth-child(9),\n.section3-con-pc .content .p-list span[data-v-3b186e90]:nth-child(10),\n.section3-con-pc .content .p-list span[data-v-3b186e90]:nth-child(11) {\n  margin-top: 45px;\n}\n.section3-con-pc .content .shares[data-v-3b186e90] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  margin-top: 83px;\n}\n.section3-con-pc .content .shares a[data-v-3b186e90] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  border-radius: 60px;\n  width: 32px;\n  height: 32px;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n      -ms-flex-pack: center;\n          justify-content: center;\n  color: #fff;\n  margin-right: 24px;\n}\n.section3-con-pc .content .shares a[data-v-3b186e90]:last-child {\n  margin-right: 0;\n}\n.section3-con-pc .content .shares img[data-v-3b186e90] {\n  width: 32px;\n  height: 32px;\n}\n", ""]), S.locals = {}, n.exports = S
        },
        922: function(n, t) {
            n.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQ0MCIgaGVpZ2h0PSI0NTAiIHZpZXdCb3g9IjAgMCAxNDQwIDQ1MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggb3BhY2l0eT0iMC4xNSIgZD0iTTMgLTFDOTMuNzUwMyAxNjEuODg1IDI1Mi44MjcgNDAyLjM3MSA0MzIuNzQzIDEzMC42N0M2NjggLTIyNC42MDMgODc3LjU1NCA0NTUuMDUxIDEwNTIuNjMgMjU3LjU4N0MxMjE3LjUgNzEuNjM1MyAxNDQzIDE0MS42MDMgMTQ0MyAxNDEuNjAzIiBzdHJva2U9IiMxRkI3NUMiIHN0cm9rZS13aWR0aD0iMC44Ii8+CjxwYXRoIG9wYWNpdHk9IjAuMTUiIGQ9Ik0zIDQzLjYyNTdDOTMuNzUwMyAyMDYuNTEgMjE3LjI4NSA0MjIuNTg2IDQzMi43NDMgMTc1LjI5NkM2NzkgLTEwNy4zNDIgOTA3LjUxMyA1MjAuNDc5IDEwNTIuNjMgMzAyLjIxM0MxMTc1IDExOC4xNiAxNDQzIDE4Ni4yMjkgMTQ0MyAxODYuMjI5IiBzdHJva2U9IiMxRkI3NUMiIHN0cm9rZS13aWR0aD0iMC44Ii8+CjxwYXRoIG9wYWNpdHk9IjAuMTUiIGQ9Ik0wIDEyMi40MzNDOTAuNzUwMyAyODUuMzE3IDE0MC4wNyA0MTkuNSA0MjkuNzQzIDI1NC4xMDNDNzQxIDc2LjM4MjggMTAxMS4zOSA2MzYuNTcxIDEwNDkuNjMgMzgxLjAyQzEwODIuNSAxNjEuMzYxIDE0NDAgMjY1LjAzNiAxNDQwIDI2NS4wMzYiIHN0cm9rZT0iIzFGQjc1QyIgc3Ryb2tlLXdpZHRoPSIwLjgiLz4KPC9zdmc+Cg=="
        },
        923: function(n, t, e) {
            "use strict";
            e(784)
        },
        924: function(n, t, e) {
            var o = e(14)((function(i) {
                return i[1]
            }));
            o.push([n.i, "\n.section1-con-pc .section1-title b {\n    color: #1fb75c !important;\n}\n.section1-con-pc .text-con p span {\n    font-weight: 700;\n}\n", ""]), o.locals = {}, n.exports = o
        },
        925: function(n, t, e) {
            "use strict";
            e(785)
        },
        926: function(n, t, e) {
            var o = e(14),
                r = e(43),
                c = e(44),
                l = e(45),
                d = e(46),
                f = e(47),
                h = e(48),
                m = e(49),
                x = e(50),
                w = e(51),
                y = e(52),
                v = e(53),
                A = e(54),
                k = e(55),
                M = e(56),
                C = e(57),
                I = o((function(i) {
                    return i[1]
                })),
                S = r(c),
                j = r(c, {
                    hash: "?#iefix"
                }),
                z = r(l),
                T = r(d),
                _ = r(f, {
                    hash: "#PingFang-SC-Light"
                }),
                D = r(h),
                E = r(h, {
                    hash: "?#iefix"
                }),
                N = r(m),
                L = r(x),
                O = r(w, {
                    hash: "#PingFang-SC-Semibold"
                }),
                P = r(y),
                H = r(y, {
                    hash: "?#iefix"
                }),
                R = r(v),
                Y = r(A),
                Z = r(k, {
                    hash: "#PingFang-SC-Regular"
                }),
                B = r(M),
                U = r(C);
            I.push([n.i, "@font-face {\n  font-family: 'PingFangSC-Light';\n  src: url(" + S + ");\n  /* IE9 */\n  src: url(" + j + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + z + ') format("woff"), /* chrome、firefox */ url(' + T + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + _ + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Semibold';\n  src: url(" + D + ");\n  /* IE9 */\n  src: url(" + E + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + N + ') format("woff"), /* chrome、firefox */ url(' + L + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + O + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'PingFangSC-Regular';\n  src: url(" + P + ");\n  /* IE9 */\n  src: url(" + H + ') format("embedded-opentype"), /* IE6-IE8 */ url(' + R + ') format("woff"), /* chrome、firefox */ url(' + Y + ') format("truetype"), /* chrome、firefox、opera、Safari, Android, iOS 4.2+ */ url(' + Z + ") format(\"svg\");\n  /* iOS 4.1- */\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Light';\n  src: url(" + B + ");\n  font-style: normal;\n  font-weight: normal;\n}\n@font-face {\n  font-family: 'Roboto-Condensed';\n  src: url(" + U + ') format("truetype");\n  font-style: normal;\n  font-weight: normal;\n}\n@-webkit-keyframes form-bottom-top-f329e83e {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n@keyframes form-bottom-top-f329e83e {\n0% {\n    opacity: 0;\n    -webkit-transform: translateY(100px);\n            transform: translateY(100px);\n}\n100% {\n    opacity: 1;\n    -webkit-transform: translateY(0px);\n            transform: translateY(0px);\n}\n}\n.anmation-add[data-v-f329e83e] {\n  opacity: 1;\n  -webkit-animation: form-bottom-top-f329e83e 300ms 0s ease forwards;\n          animation: form-bottom-top-f329e83e 300ms 0s ease forwards;\n}\n.section1-con-pc[data-v-f329e83e] {\n  position: relative;\n  height: 633px;\n  width: 100%;\n  overflow: hidden;\n  background: #fff;\n  border-radius: 24px;\n}\n.section1-con-pc .content[data-v-f329e83e] {\n  width: 900px;\n  margin: 0 auto;\n  height: 388px;\n}\n.section1-con-pc .section1-title[data-v-f329e83e] {\n  font-size: 40px;\n  line-height: 56px;\n  font-weight: 600;\n  margin-top: 125px;\n  text-align: center;\n  color: #1a1a1a;\n}\n.section1-con-pc .desc-list[data-v-f329e83e] {\n  opacity: 0;\n  margin-top: 72px;\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-orient: vertical;\n  -webkit-box-direction: normal;\n      -ms-flex-direction: column;\n          flex-direction: column;\n}\n.section1-con-pc .text-con[data-v-f329e83e] {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-pack: justify;\n      -ms-flex-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n.section1-con-pc .text-con img[data-v-f329e83e] {\n  width: 114px;\n  height: 114px;\n}\n.section1-con-pc .text-con .next[data-v-f329e83e] {\n  position: relative;\n  left: 252px;\n  bottom: 57px;\n  width: 94.5px;\n  height: 0;\n  border: 1px dashed #868987;\n}\n.section1-con-pc .text-con p[data-v-f329e83e] {\n  font-style: normal;\n  width: 300px;\n  font-weight: 400;\n  font-size: 16px;\n  line-height: 19px;\n  color: #252b27;\n}\n.section1-con-pc .text-con .text-special[data-v-f329e83e] {\n  margin-left: 33px;\n}\n.section1-con-pc .button[data-v-f329e83e] {\n  text-decoration: none;\n  display: block;\n  cursor: pointer;\n  background: #00cb6a;\n  border-radius: 4px;\n  width: 160px;\n  height: 48px;\n  margin: 0 auto;\n  color: #fff;\n  font-weight: 700;\n  font-size: 14px;\n  line-height: 48px;\n  margin-top: 60px;\n}\n.section1-con-pc-en[data-v-f329e83e] {\n  height: 592px;\n}\n.section1-con-pc-en .content[data-v-f329e83e] {\n  height: 419px;\n}\n.section1-con-pc-en .desc-list-en[data-v-f329e83e] {\n  margin-top: 60px;\n}\n.section1-con-pc-en .section1-title[data-v-f329e83e] {\n  margin-top: 120px;\n  line-height: 48px;\n}\n', ""]), I.locals = {}, n.exports = I
        }
    }
]);